<?php $__env->startSection('isi'); ?>
    <div class="row">
        <div class="col-md-12 m project-list">
            <div class="card">
                <div class="row">
                    <div class="col-md-6 p-0 d-flex mt-2">
                        <h4><?php echo e($title); ?></h4>
                    </div>
                    <div class="col-md-6 p-0">
                        <a href="<?php echo e(url('/lokasi-kantor')); ?>" class="btn btn-danger btn-sm ms-2">Back</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">

                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="mytable" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Nama Lokasi</th>
                                    <th>Latitude</th>
                                    <th>Longitude</th>
                                    <th>Radius (Meter)</th>
                                    <th>Keterangan</th>
                                    <th>Status</th>
                                    <th>Created By</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data_lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration ?? '-'); ?></td>
                                        <td><?php echo e($dl->nama_lokasi ?? '-'); ?></td>
                                        <td><?php echo e($dl->lat_kantor ?? '-'); ?></td>
                                        <td><?php echo e($dl->long_kantor ?? '-'); ?></td>
                                        <td><?php echo e($dl->radius ?? '-'); ?></td>
                                        <td><?php echo e($dl->keterangan ?? '-'); ?></td>
                                        <td><?php echo e($dl->status ?? '-'); ?></td>
                                        <td><?php echo e($dl->CreatedBy->name ?? '-'); ?></td>
                                        <td>
                                            <ul class="action">
                                                <li>
                                                    <form action="<?php echo e(url('/lokasi-kantor/update-pending-location/'.$dl->id)); ?>" method="post" class="d-inline">
                                                        <?php echo method_field('put'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="status" value="approved">
                                                        <button class="border-0" style="background-color: transparent;" title="Approve" onClick="return confirm('Are You Sure To Approve?')"><i style="color: blue" class="fa fa fa-check-circle"></i></button>
                                                    </form>
                                                </li>
                                                <li class="delete">
                                                    <form action="<?php echo e(url('/lokasi-kantor/update-pending-location/'.$dl->id)); ?>" method="post" class="d-inline">
                                                        <?php echo method_field('put'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="status" value="rejected">
                                                        <button  class="border-0" style="background-color: transparent;" title="Reject" onClick="return confirm('Are You Sure To Reject?')"><i class="fa fa-times-circle"></i></button>
                                                    </form>
                                                </li>
                                            </ul>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-end me-4 mt-4">
                        <?php echo e($data_lokasi->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\absensi\resources\views/lokasi/indexpending.blade.php ENDPATH**/ ?>