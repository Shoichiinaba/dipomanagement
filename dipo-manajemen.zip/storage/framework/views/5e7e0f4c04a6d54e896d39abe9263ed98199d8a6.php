
<?php $__env->startSection('container'); ?>
    <div class="card-secton transfer-section">
        <div class="tf-container">
            <div class="tf-balance-box">
                <div class="tf-spacing-16"></div>

                <div class="bill-content">
                    <form action="<?php echo e(url('/notifications')); ?>">
                        <div class="row">
                            <div class="col-10">
                                <?php
                                    $filter = [
                                        [
                                            "filter" => "read",
                                        ],
                                        [
                                            "filter" => "unread",
                                        ],
                                    ];
                                ?>
                                <select name="filter" id="filter" data-live-search="true">
                                <?php $__currentLoopData = $filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(request('filter') == $fil['filter']): ?>
                                        <option value="<?php echo e($fil['filter']); ?>"selected><?php echo e($fil['filter']); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($fil['filter']); ?>"><?php echo e($fil['filter']); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </div>
                            <div class="col-2">
                                <button type="submit" class="btn"><i class="fa fa-search"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="tf-spacing-16"></div>
            </div>
        </div>
    </div>
    <div id="app-wrap">
        <div class="bill-content">
            <div class="tf-container">
                <ul class="mt-3 mb-5">
                    
                    <?php $__currentLoopData = $inboxs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inbox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $user = App\Models\User::find($inbox->data['user_id']);
                        ?>
                        <li class="list-card-invoice tf-topbar d-flex justify-content-between align-iteinbox-center p-2" style="<?php echo e(!$inbox->read_at ? 'background-color: rgb(231, 231, 231)' : 'background-color: rgb(251, 251, 251)'); ?>">
                            <div class="user-info">
                                <?php if($user->foto_karyawan == null): ?>
                                    <img src="<?php echo e(url('/assets/img/foto_default.jpg')); ?>" alt="image">
                                <?php else: ?>
                                    <img src="<?php echo e(url('/storage/'.$user->foto_karyawan)); ?>" alt="image">
                                <?php endif; ?>
                            </div>
                            <div class="content-right">
                                <h4><a href="<?php echo !$inbox->read_at ? url('/notifications/read-message/'.$inbox->id) : url($inbox->data['action']); ?>"><?php echo e($user->name); ?> <span><?php echo e($inbox->status_pengajuan); ?></span></a></h4>
                                <p><a style="color: rgb(141, 141, 141)" href="<?php echo !$inbox->read_at ? url('/notifications/read-message/'.$inbox->id) : url($inbox->data['action']); ?>"><?php echo e($inbox->data['message']); ?> <span><?php echo e(date('d M Y H:i:s',strtotime($inbox->created_at))); ?></span></a></p>
                                <p><a style="color: rgb(141, 141, 141)" href="<?php echo !$inbox->read_at ? url('/notifications/read-message/'.$inbox->id) : url($inbox->data['action']); ?>"><?php echo e($inbox->deskripsi); ?></a></p>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex justify-content-end me-4 mt-4">
                        <?php echo e($inboxs->links()); ?>

                    </div>
                </ul>

            </div>
        </div>
    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dipo-manajemen\resources\views/notifications/index.blade.php ENDPATH**/ ?>