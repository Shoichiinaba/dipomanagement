
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, viewport-fit=cover">
    <title><?php echo e($title); ?></title>
    <!-- Favicon and Touch Icons  -->
    <link rel="shortcut icon" href="<?php echo e(url('/myhr/images/logo.png')); ?>" />
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(url('/myhr/images/logo.png')); ?>" />
    <!-- Font -->
    <link rel="stylesheet" href="<?php echo e(url('/myhr/fonts/fonts.css')); ?>" />
    <!-- Icons -->
    <link rel="stylesheet" href="<?php echo e(url('/myhr/fonts/icons-alipay.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('/myhr/styles/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('/myhr/styles/swiper-bundle.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/myhr/styles/styles.css')); ?>" />
    <link rel="manifest" href="<?php echo e(url('/myhr/_manifest.json')); ?>" data-pwa-version="set_in_manifest_and_pwa_js">
    <link rel="apple-touch-icon" sizes="192x192" href="<?php echo e(url('/myhr/app/icons/icon-192x192.png')); ?>">
</head>

<body>
       <!-- preloade -->
       <div class="preload preload-container">
        <div class="preload-logo">
          <div class="spinner"></div>
        </div>
      </div>
    <!-- /preload -->
    <div class="header is-fixed">
        <div class="tf-container">
            <div class="tf-statusbar d-flex justify-content-center align-items-center">
                <a href="#" class="back-btn"> <i class="icon-left"></i> </a>
                <h3><?php echo e($title); ?></h3>
            </div>
        </div>
    </div>
    <div id="app-wrap" class="style1">
        <div class="tf-container">
            <div class="tf-tab">
                <ul class="menu-tabs tabs-food-new">
                    <li class="nav-tab active">Pekerjaan Baru</li>
                    <li class="nav-tab">Dalam Proses</li>
                    <li class="nav-tab">Pekerjaan Selesai</li>
                </ul>
                <div class="content-tab pt-tab-space mb-5">
                    <div id="tab-gift-item-new app-wrap">
                        <div class="bill-content">
                            <div class="tf-container">
                                <ul class="mt-3 mb-5">

                                </ul>

                            </div>
                        </div>
                    </div>

                    <div id="tab-gift-item-2 app-wrap">
                        <div class="bill-content">
                            <div class="tf-container">
                                <ul class="mt-3 mb-5">

                                </ul>

                            </div>
                        </div>
                    </div>

                    <div id="tab-gift-item-3 app-wrap">
                        <div class="bill-content">
                            <div class="tf-container">
                                <ul class="mt-3 mb-5">

                                </ul>

                            </div>
                        </div>
                    </div>

                </div>
            </div>


        </div>
    </div>

    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/swiper-bundle.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/swiper.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/main.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\laragon\www\absensi\resources\views/penugasan/penugasanUser.blade.php ENDPATH**/ ?>