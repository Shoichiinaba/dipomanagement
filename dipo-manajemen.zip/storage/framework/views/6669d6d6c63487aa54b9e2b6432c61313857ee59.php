
<?php $__env->startSection('container'); ?>
    <div class="card-secton transfer-section">
        <div class="tf-container">
            <div class="tf-balance-box">
                <form action="<?php echo e(url('/kasbon')); ?>">
                    <?php
                        $status = array(
                        [
                            "status" => "PENDING",
                        ],
                        [
                            "status" => "ACC",
                        ]);
                    ?>
                    <div class="row">
                        <div class="col-4">
                            <input type="datetime" name="tanggal" placeholder="Tanggal" id="tanggal" value="<?php echo e(request('tanggal')); ?>">
                        </div>
                        <div class="col-4">
                            <select name="status" id="status" data-live-search="true">
                                <option value=""selected>Status</option>
                                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(request('status') == $stat['status']): ?>
                                        <option value="<?php echo e($stat['status']); ?>"selected><?php echo e($stat['status']); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($stat['status']); ?>"><?php echo e($stat['status']); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-4">
                            <button type="submit" id="search" class="form-control btn" style="border-radius: 10px; width:40px"><i class="fas fa-search"></i></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="tf-spacing-20"></div>
    <a href="<?php echo e(url('/kasbon/tambah')); ?>" class="btn btn-sm btn-primary ms-4" style="border-radius: 10px">+ Tambah</a>
    <div class="tf-spacing-20"></div>
    <div class="transfer-content">
        <div class="tf-container">
            <table id="tablePayroll" class="table table-striped">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Nama</th>
                            <th>Total</th>
                            <th>Keperluan</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($d->User->name); ?></td>
                                <td>Rp <?php echo e(number_format($d->nominal)); ?></td>
                                <td><?php echo e($d->keperluan); ?></td>
                                <td>
                                    <?php if($d->status == 'ACC'): ?>
                                        <?php echo e($d->status); ?>

                                    <?php else: ?>
                                        <?php echo e($d->status); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(auth()->user()->is_admin == 'admin'): ?>
                                        <?php if($d->status !== 'ACC'): ?>
                                            <a href="<?php echo e(url('/kasbon/edit/'.$d->id)); ?>" class="btn btn-sm btn-warning"><i class="fa fa-solid fa-edit"></i></a>
                                        <?php endif; ?>
                                        <form action="<?php echo e(url('/kasbon/delete/'.$d->id)); ?>" method="post" class="d-inline">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-danger btn-sm btn-circle" onClick="return confirm('Are You Sure')"><i class="fa fa-solid fa-trash"></i></button>
                                        </form>
                                    <?php else: ?>
                                        <?php if($d->status !== 'ACC'): ?>
                                            <a href="<?php echo e(url('/kasbon/edit/'.$d->id)); ?>" class="btn btn-sm btn-warning"><i class="fa fa-solid fa-edit"></i></a>
                                            <form action="<?php echo e(url('/kasbon/delete/'.$d->id)); ?>" method="post" class="d-inline">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button class="btn btn-danger btn-sm btn-circle" style="width: 40px" onClick="return confirm('Are You Sure')"><i class="fa fa-solid fa-trash"></i></button>
                                            </form>
                                        <?php else: ?>
                                        -
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
        </div>
        <div class="d-flex justify-content-end mr-4">
            <?php echo e($data->links()); ?>

        </div>
    </div>
    <br>
    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\absensi\resources\views/kasbon/indexuser.blade.php ENDPATH**/ ?>