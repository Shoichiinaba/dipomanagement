<?php $__env->startSection('container'); ?>
    <div class="card-secton transfer-section">
        <div class="tf-container">
            <div class="tf-balance-box">
                <form  method="post" class="tf-form p-2"  action="<?php echo e(url('/exit/update/'.$pegawai_keluar->id)); ?>" enctype="multipart/form-data">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="group-input">
                        <label for="user" class="float-left">user</label>
                        <input type="text" class="<?php $__errorArgs = ['user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="user" name="user" value="<?php echo e(old('user', $pegawai_keluar->user->name ?? '')); ?>" readonly>
                        <?php $__errorArgs = ['user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <input type="hidden" name="user_id" value="<?php echo e(old('user_id', $pegawai_keluar->user_id)); ?>">
                    </div>

                    <div class="group-input">
                        <label for="jenis" style="z-index: 100">Jenis Keberhentian</label>
                        <select name="jenis" id="jenis" class="<?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> selectpicker" data-live-search="true">
                            <option value="">-- Pilih Jenis Keberhentian --</option>
                            <option value="PHK" <?php echo e('PHK' == old('jenis', $pegawai_keluar->jenis) ? 'selected="selected"' : ''); ?>>PHK</option>
                            <option value="Mengundurkan Diri" <?php echo e('Mengundurkan Diri' == old('jenis', $pegawai_keluar->jenis) ? 'selected="selected"' : ''); ?>>Mengundurkan Diri</option>
                            <option value="Meninggal Dunia" <?php echo e('Meninggal Dunia' == old('jenis', $pegawai_keluar->jenis) ? 'selected="selected"' : ''); ?>>Meninggal Dunia</option>
                            <option value="Pensiun" <?php echo e('Pensiun' == old('jenis', $pegawai_keluar->jenis) ? 'selected="selected"' : ''); ?>>Pensiun</option>
                        </select>
                        <?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="group-input">
                        <label for="alasan" class="form-label">alasan</label>
                        <textarea name="alasan" id="alasan" class="<?php $__errorArgs = ['alasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30" rows="10"><?php echo e(old('alasan', $pegawai_keluar->alasan)); ?></textarea>
                        <?php $__errorArgs = ['alasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="group-input">
                        <label for="tanggal" class="float-left">Tanggal</label>
                        <input type="datetime" style="background-color: white" class="<?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tanggal" name="tanggal" value="<?php echo e(old('tanggal', $pegawai_keluar->tanggal)); ?>">
                        <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <label for="pegawai_keluar_file_path" class="float-left">File</label>
                    <div class="group-input">
                        <input type="file" class="form-control <?php $__errorArgs = ['pegawai_keluar_file_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pegawai_keluar_file_path" name="pegawai_keluar_file_path" value="<?php echo e(old('pegawai_keluar_file_path')); ?>">
                        <?php $__errorArgs = ['pegawai_keluar_file_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php if($pegawai_keluar->pegawai_keluar_file_path): ?>
                            <a href="<?php echo e(url('/storage/'.$pegawai_keluar->pegawai_keluar_file_path)); ?>" style="font-size: 10px; color:blue"><i class="fa fa-download"></i> <?php echo e($pegawai_keluar->pegawai_keluar_file_name); ?></a>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="btn btn-primary float-right">Submit</button>
                </form>

            </div>
        </div>
    </div>
    <br>
    <br>
    <br>
    <br>
     <?php $__env->startPush('script'); ?>
        <script>
            $('select').select2();
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\absensi\resources\views/pegawai-keluar/editUser.blade.php ENDPATH**/ ?>