
<?php $__env->startSection('container'); ?>
   <div class="card-secton transfer-section">
        <div class="tf-container">
            <div class="tf-balance-box">
                <div class="tf-spacing-16"></div>

                <div class="bill-content">
                    <form action="<?php echo e(url('/pegawai')); ?>">
                        <div class="row">
                            <div class="col-10">
                                <div class="input-field">
                                    <span class="icon-search"></span>
                                    <input required class="search-field value_input" placeholder="Search" name="search" type="text" value="<?php echo e(request('search')); ?>">
                                    <span class="icon-clear"></span>
                                </div>
                            </div>
                            <div class="col-2">

                                <button type="submit" class="btn"><i class="fa fa-search"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="tf-spacing-16"></div>
            </div>
        </div>
    </div>
    <div class="transfer-content"></div>
    <div class="repicient-content">
       <div class="tf-container">
        <div class="box-user mt-5 text-center">
            <div class="box-avatar">
                <?php if($user->foto_karyawan == null): ?>
                    <img src="<?php echo e(url('/assets/img/foto_default.jpg')); ?>" alt="image">
                <?php else: ?>
                    <img src="<?php echo e(url('/storage/'.$user->foto_karyawan)); ?>" alt="image">
                <?php endif; ?>
            </div>
            <h3 class="fw_8 mt-3"><?php echo e(strtoupper($user->name)); ?></h3>
            <p><?php echo e(strtoupper($user->Jabatan->nama_jabatan) ?? '-'); ?></p>
  
        </div>
        <ul class="mt-7">
            <?php
                $tgl_lahir = new DateTime($user->tgl_lahir);
                $tgl_join = new DateTime($user->tgl_join);
            ?>
            <li class="list-user-info"><span class="icon-user"></span><?php echo e($user->username); ?></li>
            <li class="list-user-info"><span class="fa fa-user-secret"></span><?php echo e($user->Jabatan->nama_jabatan ?? '-'); ?></li>
            <li class="list-user-info"><span class="fa fa-building"></span><?php echo e($user->Lokasi->nama_lokasi ?? '-'); ?></li>
			<li class="list-user-info"><span class="fa fa-venus-mars"></span><?php echo e($user->gender); ?></li>
			<li class="list-user-info"><span class="fa fa-ring"></span><?php echo e($user->status_nikah); ?></li>
			<li class="list-user-info"><span class="icon-phone"></span><a href="https://wa.me/<?php echo e($user->whatsapp($user->telepon)); ?>"><?php echo e($user->telepon); ?></a></li>
			<li class="list-user-info"><span class="icon-email"></span><a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a></li>
            <li class="mt-4"><span class="fa fa-baby me-3" style="font-size: 20px; color:black"></span> <span style="color:black; font-size:14px"><?php echo e($tgl_lahir->format('d M Y')); ?></span> <span style="font-style: italic; font-size:12px; color:rgb(139, 139, 139); float:right"> Tanggal Lahir</span></li><hr style="color: rgb(204, 204, 204)">
            <li class="mt-2"><span class="fa fa-sign-in-alt me-3" style="font-size: 20px; color:black"></span> <span style="color:black; font-size:14px"><?php echo e($tgl_join->format('d M Y')); ?></span> <span style="font-style: italic; font-size:12px; color:rgb(139, 139, 139); float:right"> Tanggal Join</span></li><hr style="color: rgb(204, 204, 204)">
        </ul>
       </div>
     
    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\absensi\resources\views/karyawan/show.blade.php ENDPATH**/ ?>