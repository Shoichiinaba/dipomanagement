
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, viewport-fit=cover">
    <title><?php echo e($title); ?></title>
    <!-- Favicon and Touch Icons  -->
    <link rel="shortcut icon" href="<?php echo e(url('/myhr/images/logo.png')); ?>" />
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(url('/myhr/images/logo.png')); ?>" />
    <!-- Font -->
    <link rel="stylesheet" href="<?php echo e(url('/myhr/fonts/fonts.css')); ?>" />
    <!-- Icons -->
    <link rel="stylesheet" href="<?php echo e(url('/myhr/fonts/icons-alipay.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('/myhr/styles/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('/myhr/styles/swiper-bundle.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('adminlte/plugins/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/myhr/styles/styles.css')); ?>" />
    <link rel="manifest" href="<?php echo e(url('/myhr/_manifest.json')); ?>" data-pwa-version="set_in_manifest_and_pwa_js">
    <link rel="apple-touch-icon" sizes="192x192" href="<?php echo e(url('/myhr/app/icons/icon-192x192.png')); ?>">
    <style>
        .hidden {
            display: none;
        }
        .content-tab .active-content {
            display: block;
        }
    </style>
</head>

<body>
       <!-- preloade -->
       <div class="preload preload-container">
            <div class="preload-logo">
                <div class="spinner"></div>
            </div>
        </div>
        <div class="header is-fixed">
            <div class="tf-container">
                <div class="tf-statusbar d-flex justify-content-center align-items-center">
                    <a href="#" class="back-btn"> <i class="icon-left"></i> </a>
                    <h3><?php echo e($title); ?></h3>
                </div>
            </div>
        </div>
    <div id="app-wrap" class="style1">
        <div class="tf-container">
            <div class="tf-tab">


                <div class="content-tab pt-tab-space mb-5">
                    <div id="tab-gift-item-1 app-wrap" class="app-wrap">
                        <div class="bill-content">
                            <div class="tf-container">
                                <ul class="mb-5">
                                    <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                        <div class="content-right">
                                            <h5><div class="float-start">Periode</div> <div class="float-end"><?php echo e($target_kinerja->tanggal_awal); ?> s/d <?php echo e($target_kinerja->tanggal_akhir); ?></div></h5>
                                        </div>
                                    </li>
                                    <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                        <div class="content-right">
                                            <h5><div class="float-start">Target Team</div> <div class="float-end">Rp <?php echo e(number_format($target_kinerja->target_team)); ?></div></h5>
                                        </div>
                                    </li>
                                    <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                        <div class="content-right">
                                            <h5><div class="float-start">Total Penjualan</div> <div class="float-end">Rp <?php echo e(number_format($sum_jumlah)); ?></div></h5>
                                        </div>
                                    </li>
                                    <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                        <div class="content-right">
                                            <h5><div class="float-start">Sisa Target Team</div> <div class="float-end">Rp <?php echo e(number_format($target_kinerja->target_team - $sum_jumlah)); ?></div></h5>
                                        </div>
                                    </li>
                                    <br>
                                    <?php $__currentLoopData = $target_kinerja_team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tkt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                            <div class="content-right">
                                                <h4><a href="<?php echo e(url('/target-kinerja/show/'.$tkt->id.'/'.$target_kinerja->id)); ?>"><?php echo e($tkt->user->name ?? '-'); ?><span class="primary_color">Lihat</span></a></h4>
                                                <p>Target Pribadi : Rp <?php echo e(number_format($tkt->target_pribadi)); ?></p>
                                                <p>Jumlah Penjualan: Rp <?php echo e(number_format($tkt->jumlah)); ?></p>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>

    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/swiper-bundle.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/swiper.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/main.js')); ?>"></script>

    <script>
        $(document).ready(function () {
            $('.menu-tabs .nav-tab').click(function () {
                $('.menu-tabs .nav-tab').removeClass('active');
                $('.content-tab > div').removeClass('active-content').addClass('hidden');

                $(this).addClass('active');

                let tabIndex = $(this).index();

                $('.content-tab > div').eq(tabIndex).removeClass('hidden').addClass('active-content');
            });

            $('.menu-tabs .nav-tab.active').trigger('click');
        });
    </script>

    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\absensi\resources\views/target-kinerja/list.blade.php ENDPATH**/ ?>