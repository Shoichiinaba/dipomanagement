<!DOCTYPE html>
<html lang="en">
  <head>
    <?php
        $settings = App\Models\settings::first();
    ?>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="author" content="pixelstrap">
    <link rel="shortcut icon" href="<?php echo e(url('/storage/'.$settings->logo)); ?>" />
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(url('/storage/'.$settings->logo)); ?>" />
    <title><?php echo e($title); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/html/assets/css/vendors/font-awesome.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/html/assets/css/vendors/icofont.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/html/assets/css/vendors/themify.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/html/assets/css/vendors/flag-icon.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/html/assets/css/vendors/feather-icon.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/html/assets/css/vendors/scrollbar.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/html/assets/css/vendors/animate.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/html/assets/css/vendors/chartist.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/html/assets/css/vendors/slick.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/html/assets/css/vendors/slick-theme.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/html/assets/css/vendors/prism.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/html/assets/css/vendors/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/html/assets/css/style.css')); ?>">
    <link id="color" rel="stylesheet" href="<?php echo e(url('/html/assets/css/color-1.css" media="screen')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/html/assets/css/responsive.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/html/assets/css/vendors/calendar.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/html/assets/css/vendors/datatables.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('adminlte/plugins/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/html/assets/css/vendors/select2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('https://unpkg.com/leaflet@1.8.0/dist/leaflet.css')); ?>" integrity="sha512-hoalWLoI8r4UszCkZ5kL8vayOGVae1oxXe/2A4AO6J9+580uKHDO3JdHb7NzwwzK5xr/Fs0W40kiNHxM9vyTtQ==" crossorigin=""/>
    <script src="<?php echo e(url('https://unpkg.com/leaflet@1.8.0/dist/leaflet.js')); ?>" integrity="sha512-BB3hKbKWOc9Ez/TAwyWxNXeoV9c1v6FIeYiBieIWkpLjauysF18NzgR1MBNBXf8/KABdlkX68nAhlwcDFLGPCQ==" crossorigin=""></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('clock/dist/bootstrap-clockpicker.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/trix@2.0.8/dist/trix.css">
    <script type="text/javascript" src="https://unpkg.com/trix@2.0.8/dist/trix.umd.min.js"></script>
    <style>
        .btn-grey {
            background-color: #6c757d;
            border-color: #6c757d;
            color: white;
        }

        .btn-grey:hover {
            background-color: #5a6268;
            border-color: #545b62;
        }

        .btn {
            border-radius: 10px
        }

        .borderi {
            border-color:rgb(201, 201, 201)
        }

        .select2-container--default .select2-selection--single {
            border-color: rgb(201, 201, 201) !important;
        }

        trix-toolbar [data-trix-button-group="file-tools"] {
            display: none;
        }
    </style>


    <?php echo $__env->yieldPushContent('style'); ?>
  </head>
  <body>
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <div class="loader-wrapper">
      <div class="loader"></div>
    </div>
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
      <div class="page-header">
        <div class="header-wrapper row m-0">
          <form class="form-inline search-full col" action="#" method="get">
            <div class="form-group w-100">
              <div class="Typeahead Typeahead--twitterUsers">
                <div class="u-posRelative">
                  <input class="demo-input Typeahead-input form-control-plaintext w-100" type="text" placeholder="Search In Enzo .." name="q" title="" autofocus>
                  <div class="spinner-border Typeahead-spinner" role="status"><span class="sr-only">Loading...</span></div><i class="close-search" data-feather="x"></i>
                </div>
                <div class="Typeahead-menu"></div>
              </div>
            </div>
          </form>
          <div class="header-logo-wrapper col-auto p-0">
            <div class="logo-wrapper"><a href="<?php echo e(url('/dashboard')); ?>"><img class="img-fluid" src="<?php echo e(url('/html/assets/images/logo/login.png')); ?>" alt=""></a></div>
            <div class="toggle-sidebar"><i class="status_toggle middle sidebar-toggle" data-feather="align-center"></i></div>
          </div>

          <div class="left-header col horizontal-wrapper ps-0">
            <a href="<?php echo e(url('/switch/user')); ?>" class="btn btn-warning" onclick="return confirm('Are You Sure ?')">Dashboard User</a>
          </div>

          <div class="nav-right col-8 pull-right right-header p-0">
            <ul class="nav-menus">
              <li>
                <a class="notification-box" href="<?php echo e(url('/notifications')); ?>"><i class="fa fa-bell"></i>
                  <?php if(auth()->user()->notifications()->whereNull('read_at')->count() > 0): ?>
                    <span class="badge rounded-pill badge-danger"><?php echo e(auth()->user()->notifications()->whereNull('read_at')->count()); ?></span>
                  <?php endif; ?>
                </a>
              </li>
              <li class="profile-nav onhover-dropdown p-0 me-0">
                <div class="d-flex profile-media">
                  <?php if(auth()->user()->foto_karyawan): ?>
                    <img class="b-r-50" src="<?php echo e(url('/storage/'.auth()->user()->foto_karyawan)); ?>" alt="" style="width: 50px">
                  <?php else: ?>
                    <img class="b-r-50" src="<?php echo e(url('/html/assets/images/dashboard/profile.jpg')); ?>" alt="">
                  <?php endif; ?>
                  <div class="flex-grow-1"><span><?php echo e(auth()->user()->name); ?></span>
                    <p class="mb-0 font-roboto"><?php echo e(auth()->user()->Jabatan->nama_jabatan); ?> <i class="middle fa fa-angle-down"></i></p>
                  </div>
                </div>
                <ul class="profile-dropdown onhover-show-div">
                  <li><a href="<?php echo e(url('/my-profile')); ?>"><i data-feather="user"></i><span>Account </span></a></li>
                  <li><a href="<?php echo e(url('/my-profile/edit-password')); ?>"><i data-feather="file-text"></i><span>Change Password</span></a></li>
                  <li><a href="<?php echo e(url('/logout')); ?>" onclick="return confirm('Are you sure?')"><i data-feather="log-out"> </i><span>Log Out</span></a></li>
                </ul>
              </li>
            </ul>
          </div>
          <script class="result-template" type="text/x-handlebars-template">
            <div class="ProfileCard u-cf">
            <div class="ProfileCard-avatar"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-airplay m-0"><path d="M5 17H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-1"></path><polygon points="12 15 17 21 7 21 12 15"></polygon></svg></div>
            <div class="ProfileCard-details">
            <div class="ProfileCard-realName"></div>
            </div>
            </div>
          </script>
          <script class="empty-template" type="text/x-handlebars-template"><div class="EmptyMessage">Your search turned up 0 results. This most likely means the backend is down, yikes!</div></script>
        </div>
      </div>
      <div class="page-body-wrapper">
        <div class="sidebar-wrapper">
          <div>
            <div class="logo-wrapper"><a href="<?php echo e(url('/dashboard')); ?>"><img class="img-fluid for-light" src="<?php echo e(asset('/storage/'.$settings->logo)); ?>" style="width: 50px" alt=""></a><div style="font-size: 20px; color:white; display:inline"><?php echo e($settings->name); ?></div>
              <div class="back-btn"><i class="fa fa-angle-left"></i></div>
              <div class="toggle-sidebar"><i class="fa fa-cog status_toggle middle sidebar-toggle"> </i></div>
            </div>
            <div class="logo-icon-wrapper"><a href="<?php echo e(url('/dashboard')); ?>"><img class="img-fluid" src="<?php echo e(url('/html/assets/images/logo/logo-icon1.png')); ?>" alt=""></a></div>
            <nav class="sidebar-main">
              <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
              <div id="sidebar-menu">
                <ul class="sidebar-links" id="simple-bar">
                  <li class="back-btn"><a href="<?php echo e(url('/dashboard')); ?>"><img class="img-fluid" src="<?php echo e(url('/html/assets/images/logo/logo-icon.png')); ?>" alt=""></a>
                    <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
                  </li>
                  <li class="sidebar-main-title">
                    <h6 class="lan-1">General </h6>
                  </li>
                  <li class="menu-box">
                    <ul>

                      <li class="sidebar-list">
                        <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(url('/dashboard')); ?>"><i data-feather="home"> </i><span>Dashboard</span></a>
                      </li>

                      <li class="sidebar-list">
                        <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(url('/notifications')); ?>"><i data-feather="bell"></i>
                          <span>Notifications</span>
                          <?php if(auth()->user()->notifications()->whereNull('read_at')->count() > 0): ?>
                            <span class="badge rounded-pill badge-danger"><?php echo e(auth()->user()->notifications()->whereNull('read_at')->count()); ?></span>
                          <?php endif; ?>
                        </a>
                      </li>

                      <li class="sidebar-list">
                        <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(url('/my-profile')); ?>"><i data-feather="user-check"> </i><span>My Profile</span></a>
                      </li>

                      <?php if(auth()->user()->hasRole('admin') || auth()->user()->hasRole('hrd') || auth()->user()->hasRole('general_manager')): ?>
                        <li class="sidebar-list">
                            <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(url('/pegawai')); ?>"><i data-feather="users"> </i><span>Pegawai</span></a>
                        </li>
                      <?php endif; ?>

                      <?php if(auth()->user()->hasRole('admin')): ?>
                        <li class="sidebar-list">
                            <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(url('/role')); ?>"><i data-feather="airplay"> </i><span>Role</span></a>
                        </li>
                      <?php endif; ?>

                      <?php if(auth()->user()->hasRole('admin') || auth()->user()->hasRole('hrd') || auth()->user()->hasRole('general_manager')): ?>
                        <li class="sidebar-list">
                            <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(url('/kontrak')); ?>"><i data-feather="trending-up"> </i><span>Kontrak</span></a>
                        </li>

                        <li class="sidebar-list">
                          <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(url('/exit')); ?>"><i data-feather="user-minus"> </i><span>Pegawai Keluar</span></a>
                        </li>

                        <li class="sidebar-list">
                          <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(url('/shift')); ?>"><i data-feather="git-pull-request"> </i><span>Shift</span></a>
                        </li>



                        <li class="sidebar-list">
                            <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(url('/jabatan')); ?>"><i data-feather="package"> </i><span>Divisi</span></a>
                        </li>
                      <?php endif; ?>

                      <?php if(auth()->user()->hasRole('admin') || auth()->user()->hasRole('kepala_cabang') || auth()->user()->hasRole('hrd') || auth()->user()->hasRole('general_manager')): ?>
                        <li class="sidebar-list">
                            <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(url('/lokasi-kantor')); ?>"><i data-feather="map-pin"> </i><span>Lokasi</span></a>
                        </li>
                      <?php endif; ?>

                      <?php if(auth()->user()->hasRole('admin') || auth()->user()->hasRole('general_manager') || auth()->user()->hasRole('finance')): ?>
                        <li class="sidebar-list">
                            <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(url('/rekap-data')); ?>"><i data-feather="credit-card"> </i><span>Rekap Data</span></a>
                        </li>
                      <?php endif; ?>

                      <?php if(auth()->user()->hasRole('admin') || auth()->user()->hasRole('general_manager') || auth()->user()->hasRole('hrd')): ?>
                        <li class="sidebar-list">
                            <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(url('/data-cuti')); ?>"><i data-feather="shuffle"> </i><span>Cuti</span></a>
                        </li>
                      <?php endif; ?>

                      <li class="sidebar-list"><a class="sidebar-link sidebar-title" href="javascript:void(0)"><i data-feather="clock"></i><span>Absensi</span></a>
                          <ul class="sidebar-submenu">
                          <li><a href="<?php echo e(url('/absen')); ?>">Absen</a></li>
                          <li><a href="<?php echo e(url('/data-absen')); ?>">Data Absen</a></li>
                          <li><a href="<?php echo e(url('/dinas-luar')); ?>">Absen Dinas Luar</a></li>
                          <li><a href="<?php echo e(url('/data-dinas-luar')); ?>">Data Dinas Luar</a></li>
                          </ul>
                      </li>

                      <li class="sidebar-list"><a class="sidebar-link sidebar-title" href="javascript:void(0)"><i data-feather="film"></i><span>Overtime</span></a>
                          <ul class="sidebar-submenu">
                          <li><a href="<?php echo e(url('/lembur')); ?>">Lembur</a></li>
                          <li><a href="<?php echo e(url('/data-lembur')); ?>">Data Lembur</a></li>
                          </ul>
                      </li>

                      <?php if(auth()->user()->hasRole('admin') || auth()->user()->hasRole('hrd') || auth()->user()->hasRole('general_manager')): ?>

                        <li class="sidebar-list"><a class="sidebar-link sidebar-title" href="javascript:void(0)"><i data-feather="map"></i><span>Patroli</span></a>
                            <ul class="sidebar-submenu">
                            <li><a href="<?php echo e(url('/patroli')); ?>">Patroli</a></li>
                            <li><a href="<?php echo e(url('/data-patroli')); ?>">Data Patroli</a></li>
                            </ul>
                        </li>

                        <li class="sidebar-list">
                            <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(url('/kunjungan')); ?>"><i data-feather="navigation"> </i><span>Kunjungan</span></a>
                        </li>

                        <li class="sidebar-list">
                            <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(url('/penugasan')); ?>"><i data-feather="award"> </i><span>Penugasan</span></a>
                        </li>

                        <li class="sidebar-list">
                            <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(url('/rapat')); ?>"><i data-feather="monitor"> </i><span>Rapat</span></a>
                        </li>

                        <li class="sidebar-list"><a class="sidebar-link sidebar-title" href="javascript:void(0)"><i data-feather="wind"></i><span>Kinerja Pegawai</span></a>
                            <ul class="sidebar-submenu">
                              <li><a href="<?php echo e(url('/jenis-kinerja')); ?>">Jenis Kinerja</a></li>
                              <li><a href="<?php echo e(url('/laporan-kinerja')); ?>">Laporan Kinerja</a></li>
                              <li><a href="<?php echo e(url('/kinerja-pegawai')); ?>">Kinerja Pegawai</a></li>
                            </ul>
                        </li>

                        <li class="sidebar-list">
                            <a class="sidebar-link sidebar-title link-nav <?php echo e(Request::is('laporan-kerja*') ? 'active' : ''); ?>" href="<?php echo e(url('/laporan-kerja')); ?>"><i data-feather="message-square"> </i><span>Laporan Kerja</span></a>
                        </li>
                      <?php endif; ?>

                      <li class="sidebar-list">
                        <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(url('/inventory')); ?>"><i data-feather="git-merge"> </i><span>Inventory</span></a>
                      </li>

                      <?php if(auth()->user()->hasRole('admin') || auth()->user()->hasRole('general_manager') || auth()->user()->hasRole('finance') || auth()->user()->hasRole('regional_manager')): ?>
                        <li class="sidebar-list"><a class="sidebar-link sidebar-title" href="javascript:void(0)"><i data-feather="dollar-sign"></i><span>Keuangan</span></a>
                            <ul class="sidebar-submenu">
                            <li><a href="<?php echo e(url('/payroll')); ?>">Payroll</a></li>
                            <li><a href="<?php echo e(url('/kasbon')); ?>">Kasbon</a></li>
                            <li><a href="<?php echo e(url('/reimbursement')); ?>">Reimbursement</a></li>
                            <li><a href="<?php echo e(url('/kategori')); ?>">Kategori Reimbursement</a></li>
                            <li><a href="<?php echo e(url('/list-pengajuan-keuangan')); ?>">Pengajuan Keuangan</a></li>
                            </ul>
                        </li>

                        <li class="sidebar-list"><a class="sidebar-link sidebar-title" href="javascript:void(0)"><i data-feather="sunrise"></i><span>Target</span></a>
                          <ul class="sidebar-submenu">
                            <li><a href="<?php echo e(url('/target-kinerja')); ?>">Target Kinerja</a></li>
                            <li><a href="<?php echo e(url('/detail-target-kinerja')); ?>">Detail Target</a></li>
                          </ul>
                        </li>
                      <?php endif; ?>


                      <li class="sidebar-list">
                        <a class="sidebar-link sidebar-title link-nav <?php echo e(Request::is('dokumen*') ? 'active' : ''); ?>" href="<?php echo e(url('/dokumen')); ?>"><i data-feather="folder"> </i><span>Dokumen Pegawai</span></a>
                      </li>

                      <?php if(auth()->user()->hasRole('admin')): ?>
                        <li class="sidebar-list">
                            <a class="sidebar-link sidebar-title link-nav <?php echo e(Request::is('berita*') ? 'active' : ''); ?>" href="<?php echo e(url('/berita')); ?>"><i data-feather="star"> </i><span>Berita & Informasi</span></a>
                        </li>

                        <li class="sidebar-list">
                            <a class="sidebar-link sidebar-title link-nav <?php echo e(Request::is('settings*') ? 'active' : ''); ?>" href="<?php echo e(url('/settings')); ?>"><i data-feather="settings"> </i><span>Settings</span></a>
                        </li>
                      <?php endif; ?>

                    </ul>
                  </li>

                </ul>
              </div>
              <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
            </nav>
          </div>
        </div>
        <div class="page-body">
          <div class="container-fluid default-dash">
            <?php echo $__env->yieldContent('isi'); ?>
          </div>
        </div>
        <footer class="footer">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-6 p-0 footer-left">
                <p class="mb-0">Copyright © 2023 Ricky. All rights reserved.</p>
              </div>

            </div>
          </div>
        </footer>
      </div>
    </div>
    <script src="<?php echo e(url('/html/assets/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/icons/feather-icon/feather.min.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/icons/feather-icon/feather-icon.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/scrollbar/simplebar.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/scrollbar/custom.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/config.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/sidebar-menu.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/chart/chartist/chartist.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/chart/chartist/chartist-plugin-tooltip.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/chart/knob/knob.min.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/chart/knob/knob-chart.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/chart/apex-chart/apex-chart.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/chart/apex-chart/stock-prices.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/prism/prism.min.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/clipboard/clipboard.min.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/custom-card/custom-card.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/notify/bootstrap-notify.min.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/dashboard/default.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/notify/index.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/slick-slider/slick.min.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/slick-slider/slick-theme.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/typeahead/handlebars.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/typeahead/typeahead.bundle.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/typeahead/typeahead.custom.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/typeahead-search/handlebars.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/typeahead-search/typeahead-custom.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/script.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/theme-customizer/customizer.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/calendar/fullcalendar.min.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/datatable/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/datatable/datatables/datatable.custom.js')); ?>"></script>
    <script src="<?php echo e(url('/html/assets/js/select2/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(url('https://cdn.jsdelivr.net/npm/flatpickr')); ?>"></script>
    <script src="<?php echo e(url('accounting.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/clock/dist/bootstrap-clockpicker.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo e(url('/push/bin/push.js')); ?>"></script>
    <script src="<?php echo e(url('/js/app.js')); ?>"></script>
    <script>
        window.Echo.channel("messages").listen("NotifApproval", (event) => {
            var user_id = <?php echo e(auth()->user()->id); ?>;
            if (event.user_id == user_id) {
                if (event.type == "Approved") {
                    Swal.fire({
                        icon: "success",
                        title: "Approved",
                        text: event.notif,
                        footer: "<a href=" + event.url + ">View Application</a>",
                    });
                } else if (event.type == "Approval" || event.type == "Info") {
                    Swal.fire({
                        icon: "info",
                        title: "",
                        text: event.notif,
                        footer: "<a href=" + event.url + ">View Application</a>",
                    });
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Rejected",
                        text: event.notif,
                        footer: "<a href=" + event.url + ">View Application</a>",
                    });
                }
                Push.create(event.notif);
            }
        });
    </script>
    <script>
      function getLocation() {
          if (navigator.geolocation) {
              navigator.geolocation.getCurrentPosition(showPosition);
          } else {
              x.innerHTML = "Geolocation is not supported by this browser.";
          }
      }

      function showPosition(position) {
          $('#lat').val(position.coords.latitude);
          $('#lat2').val(position.coords.latitude);
          $('#long').val(position.coords.longitude);
          $('#long2').val(position.coords.longitude);
      }

      setInterval(getLocation, 1000);
    </script>
    <script>
      $(function(){
          $('form').on('submit', function(){
              $(':input[type="submit"]').prop('disabled', true);
          })
      })
      $(function () {
        $('.selectpicker').select2();
        $('#mytable').DataTable( {
            "responsive": true,
            "paging": false,
            "info": false,
            "scrollCollapse": true,
            "autoWidth": false,
            'searching': false
        });
      });
    </script>
    <script>
      config = {
          enableTime: true,
          noCalendar: true,
          dateFormat: "H:i",
          time_24hr: true,
      }

      flatpickr("input[type=datetime-local]", config)
      flatpickr("input[type=datetime]", {})
    </script>
    <?php echo $__env->yieldPushContent('script'); ?>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html>
<?php /**PATH C:\laragon\www\absensi\resources\views/templates/dashboard.blade.php ENDPATH**/ ?>