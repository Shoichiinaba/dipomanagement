<?php $__env->startSection('container'); ?>
    <div class="tf-spacing-20"></div>
    <div class="tf-spacing-20"></div>
    <div class="tf-spacing-20"></div>
    <div class="tf-spacing-20"></div>
    <div class="tf-spacing-20"></div>
    <div class="tf-spacing-20"></div>
    <div class="tf-spacing-20"></div>
    <div class="card-secton transfer-section">
        <div class="tf-container">
            <div class="tf-balance-box">
                <form method="post" class="tf-form" action="<?php echo e(url('/cuti/proses-edit/'.$data_cuti_user->id)); ?>" enctype="multipart/form-data">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="group-input">
                        <label for="user_id" style="z-index: 1000">Nama Karyawan</label>
                        <select id="user_id" name="user_id" id="">
                            <option value="<?php echo e($data_cuti_user->User->id); ?>"><?php echo e($data_cuti_user->User->name); ?></option>
                        </select>
                    </div>
                    <div class="group-input">
                        <?php
                            $izin_cuti = $data_cuti_user->User->izin_cuti;
                            $izin_lainnya = $data_cuti_user->User->izin_lainnya;
                            $izin_telat = $data_cuti_user->User->izin_telat;
                            $izin_pulang_cepat = $data_cuti_user->User->izin_pulang_cepat;

                            $data_cuti = array(
                                [
                                    'nama' => 'Cuti',
                                    'nama_cuti' => 'Cuti ('.$izin_cuti.')'
                                ],
                                [
                                    'nama' => 'Izin Masuk',
                                    'nama_cuti' => 'Izin Masuk ('.$izin_lainnya.')'
                                ],
                                [
                                    'nama' => 'Izin Telat',
                                    'nama_cuti' => 'Izin Telat ('.$izin_telat.')'
                                ],
                                [
                                    'nama' => 'Izin Pulang Cepat',
                                    'nama_cuti' => 'Izin Pulang Cepat ('.$izin_pulang_cepat.')'
                                ],
                                [
                                    'nama' => 'Sakit',
                                    'nama_cuti' => 'Sakit'
                                ],
                            );
                        ?>
                        <label for="nama_cuti"  style="z-index: 1000">Nama Cuti</label>
                        <select class="<?php $__errorArgs = ['nama_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_cuti" name="nama_cuti" data-live-search="true">
                            <option value="">Pilih Cuti</option>
                            <?php $__currentLoopData = $data_cuti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(old('nama_cuti', $data_cuti_user->nama_cuti) == $dc["nama"]): ?>
                            <option value="<?php echo e($dc["nama"]); ?>" selected><?php echo e($dc["nama_cuti"]); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($dc["nama"]); ?>"><?php echo e($dc["nama_cuti"]); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['nama_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="group-input">
                        <label for="tanggal">Tanggal</label>
                        <input type="datetime" class="<?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tanggal" id="tanggal" value="<?php echo e(old('tanggal', $data_cuti_user->tanggal)); ?>">
                        <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="group-input">
                        <input type="file" name="foto_cuti" id="foto_cuti" class="form-control <?php $__errorArgs = ['foto_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['foto_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <input type="hidden" name="foto_cuti_lama" value="<?php echo e($data_cuti_user->foto_cuti); ?>">
                    </div>
                    <div class="group-input">
                        <label for="alasan_cuti">Alasan Cuti</label>
                        <input type="text" class="<?php $__errorArgs = ['alasan_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alasan_cuti" name="alasan_cuti" value="<?php echo e(old('alasan_cuti', $data_cuti_user->alasan_cuti)); ?>">
                        <?php $__errorArgs = ['alasan_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
    <br>
    <br>
    <br>
    <br>
    <?php $__env->startPush('script'); ?>
        <script>
            $('select').select2();
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\absensi\resources\views/cuti/edituser.blade.php ENDPATH**/ ?>