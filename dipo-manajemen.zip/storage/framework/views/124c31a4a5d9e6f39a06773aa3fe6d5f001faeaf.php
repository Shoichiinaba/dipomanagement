
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, viewport-fit=cover">
    <title><?php echo e($title); ?></title>
    <!-- Favicon and Touch Icons  -->
    <link rel="shortcut icon" href="<?php echo e(url('/myhr/images/logo.png')); ?>" />
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(url('/myhr/images/logo.png')); ?>" />
    <!-- Font -->
    <link rel="stylesheet" href="<?php echo e(url('/myhr/fonts/fonts.css')); ?>" />
    <!-- Icons -->
    <link rel="stylesheet" href="<?php echo e(url('/myhr/fonts/icons-alipay.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('/myhr/styles/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('/myhr/styles/swiper-bundle.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/myhr/styles/styles.css')); ?>" />
    <link rel="manifest" href="<?php echo e(url('/myhr/_manifest.json')); ?>" data-pwa-version="set_in_manifest_and_pwa_js">
    <link rel="apple-touch-icon" sizes="192x192" href="<?php echo e(url('/myhr/app/icons/icon-192x192.png')); ?>">

    <style>
        .hidden {
            display: none;
        }
        .content-tab .active-content {
            display: block;
        }
    </style>
</head>

<body>
       <!-- preloade -->
       <div class="preload preload-container">
        <div class="preload-logo">
          <div class="spinner"></div>
        </div>
      </div>
    <!-- /preload -->
    <div class="header is-fixed">
        <div class="tf-container">
            <div class="tf-statusbar d-flex justify-content-center align-items-center">
                <a href="#" class="back-btn"> <i class="icon-left"></i> </a>
                <h3><?php echo e($title); ?></h3>
            </div>
        </div>
    </div>
    <div id="app-wrap" class="style1">
        <div class="tf-container">
            <div class="tf-tab">
                <ul class="menu-tabs tabs-food-new">
                    <li class="nav-tab <?php echo e($active_tab == 'detail' ? 'active' : ''); ?>">Detail</li>
                    <li class="nav-tab <?php echo e($active_tab == 'hadir' ? 'active' : ''); ?>">Peserta</li>
                    <li class="nav-tab <?php echo e($active_tab == 'notulen' ? 'active' : ''); ?>">Notulen</li>
                </ul>
                <div class="content-tab pt-tab-space mb-5">
                    <div id="tab-gift-item-1 app-wrap" class="app-wrap <?php echo e($active_tab == 'detail' ? 'active-content' : 'hidden'); ?>">
                        <div class="bill-content">
                            <div class="tf-container">
                                <ul>
                                    <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                        <div class="content-right">
                                            <p>
                                               Mulai Acara
                                            </p>
                                            <h5>
                                                <?php if($rapat->tanggal): ?>
                                                    <?php
                                                        Carbon\Carbon::setLocale('id');
                                                        $tanggal = Carbon\Carbon::createFromFormat('Y-m-d', $rapat->tanggal);
                                                        $new_tanggal = $tanggal->translatedFormat('l, d F Y');
                                                    ?>
                                                <?php else: ?>
                                                    <?php
                                                        $new_tanggal = '-';
                                                    ?>
                                                <?php endif; ?>
                                                <?php echo e($new_tanggal); ?> <?php echo e($rapat->jam_mulai); ?>

                                            </h5>
                                        </div>
                                    </li>
                                    <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                        <div class="content-right">
                                            <p>
                                               Selesai Acara
                                            </p>
                                            <h5>
                                                <?php echo e($new_tanggal); ?> <?php echo e($rapat->jam_selesai); ?>

                                            </h5>
                                        </div>
                                    </li>
                                    <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                        <div class="content-right">
                                            <p>
                                               Jenis Pertemuan
                                            </p>
                                            <h5>
                                                <?php echo e($rapat->jenis); ?>

                                            </h5>
                                        </div>
                                    </li>
                                    <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                        <div class="content-right">
                                            <p>
                                               Lokasi Pertemuan
                                            </p>
                                            <h5>
                                                <?php echo e($rapat->lokasi); ?>

                                            </h5>
                                        </div>
                                    </li>
                                    <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                        <div class="content-right">
                                            <p>
                                                Jumlah Peserta
                                            </p>
                                            <h5>
                                                <?php echo e(count($rapat->pegawai)); ?>

                                            </h5>
                                        </div>
                                    </li>
                                    <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                        <div class="content-right">
                                            <p>
                                                Peserta Hadir
                                            </p>
                                            <h5>
                                                <?php echo e(count($rapat->pegawai->where('status', 'Hadir'))); ?>

                                            </h5>
                                        </div>
                                    </li>
                                    <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                        <div class="content-right">
                                            <p>
                                                Peserta Tidak Hadir
                                            </p>
                                            <h5>
                                                <?php echo e(count($rapat->pegawai->where('status', 'Tidak Hadir'))); ?>

                                            </h5>
                                        </div>
                                    </li>
                                    <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                        <div class="content-right">
                                            <p>
                                                Detail Pertemuan
                                            </p>
                                            <h5>
                                                <?php echo $rapat->detail ? nl2br(e($rapat->detail)) : '-'; ?>

                                            </h5>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div id="tab-gift-item-2 app-wrap" class="app-wrap <?php echo e($active_tab == 'hadir' ? 'active-content' : 'hidden'); ?>">
                        <div class="bill-content">
                            <div class="tf-container">
                                <ul>
                                    <?php $__currentLoopData = $rapat->pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                            <div class="user-info">
                                                <?php if($pegawai->user): ?>
                                                    <?php if($pegawai->user->foto_karyawan): ?>
                                                        <img src="<?php echo e(url('/storage/'.$pegawai->user->foto_karyawan)); ?>" alt="image">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(url('/assets/img/foto_default.jpg')); ?>" alt="image">
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <img src="<?php echo e(url('/assets/img/foto_default.jpg')); ?>" alt="image">
                                                <?php endif; ?>
                                            </div>
                                            <div class="content-right">
                                                <h4>
                                                    <a href="#">
                                                        <?php echo e($pegawai->user->name ?? '-'); ?>

                                                        <?php if($pegawai->status == 'Hadir'): ?>
                                                            <div class="float-end badge" style="color: rgba(20, 78, 7, 0.889); background-color:rgb(186, 238, 162); border-radius:10px;"><?php echo e($pegawai->status ?? '-'); ?></div>
                                                        <?php else: ?>
                                                            <div class="float-end badge" style="color: rgba(78, 26, 26, 0.889); background-color:rgb(242, 170, 170); border-radius:10px;"><?php echo e($pegawai->status ?? '-'); ?></div>
                                                        <?php endif; ?>
                                                    </a>
                                                </h4>
                                                <p style="color: rgb(173, 173, 173); font-size:10px;">
                                                    <?php if($pegawai->hadir): ?>
                                                        <?php
                                                            Carbon\Carbon::setLocale('id');
                                                            $hadir = Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $pegawai->hadir);
                                                            $new_hadir = $hadir->translatedFormat('l, d F Y H:i:s');
                                                        ?>
                                                        <?php echo e($new_hadir); ?>

                                                    <?php else: ?>
                                                        -
                                                    <?php endif; ?>
                                                </p>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div id="tab-gift-item-3 app-wrap" class="app-wrap <?php echo e($active_tab == 'notulen' ? 'active-content' : 'hidden'); ?>">
                        <div class="bill-content">
                            <div class="tf-container">
                                <ul class="mt-3 mb-5">
                                    <?php $__currentLoopData = $rapat->notulen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notulen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                            <div class="user-info">
                                                <span class="badge" style="border-radius:15px; background-color:blue"><?php echo e($loop->iteration); ?></span>
                                            </div>
                                            <div class="content-right">
                                                <h4>
                                                    <?php echo e($notulen->notulen); ?>

                                                </h4>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

    <div class="bottom-navigation-bar st1 bottom-btn-fixed">
        <div class="tf-container">
            <div class="row">
                <?php if($mypegawai->status == 'Tidak Hadir'): ?>
                    <div class="col">
                        <a href="<?php echo e(url('/rapat-kerja/hadir/'.$rapat->id)); ?>" class="tf-btn accent large" onclick="return confirm('Anda Sudah Di Lokasi Rapat?')">Hadir</a>
                    </div>
                <?php endif; ?>
                <div class="col">
                    <a href="#" id="btn-popup-down" class="tf-btn success large">Notulen</a>
                </div>
            </div>
        </div>
    </div>

    <div class="tf-panel down">
        <div class="panel_overlay"></div>
        <div class="panel-box panel-down">
            <div class="header">
                <div class="tf-container">
                    <div class="tf-statusbar d-flex justify-content-center align-items-center">
                        <a href="#" class="clear-panel"> <i class="icon-close1"></i> </a>
                        <h3>Notulen</h3>
                    </div>

                </div>
            </div>

            <div class="mt-5">
                <div class="tf-container">
                    <form class="tf-form-verify" action="<?php echo e(url('/rapat-kerja/notulen/'.$rapat->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="group-input">
                            <input type="text" class="<?php $__errorArgs = ['notulen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="notulen" value="<?php echo e(old('notulen')); ?>" />
                            <?php $__errorArgs = ['notulen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mt-7 mb-6">
                            <button type="submit" class="tf-btn success">Submit</button>
                        </div>
                </form>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/swiper-bundle.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/swiper.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/main.js')); ?>"></script>

    <script>
        $(document).ready(function () {
            $('.menu-tabs .nav-tab').click(function () {
                $('.menu-tabs .nav-tab').removeClass('active');
                $('.content-tab > div').removeClass('active-content').addClass('hidden');

                $(this).addClass('active');

                let tabIndex = $(this).index();

                $('.content-tab > div').eq(tabIndex).removeClass('hidden').addClass('active-content');
            });

            $('.menu-tabs .nav-tab.active').trigger('click');
        });
    </script>

    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\absensi\resources\views/rapat/rapatKerjaShow.blade.php ENDPATH**/ ?>