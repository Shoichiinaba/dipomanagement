<?php $__env->startSection('isi'); ?>
    <div class="row">
        <div class="col-md-12 m project-list">
            <div class="card">
                <div class="row">
                    <div class="col-md-6 p-0 d-flex mt-2">
                        <h4><?php echo e($title); ?></h4>
                    </div>
                    <div class="col-md-6 p-0">
                        <a href="<?php echo e(url('/target-kinerja')); ?>" class="btn btn-danger btn-sm ms-2">Back</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <form method="post" class="p-4" action="<?php echo e(url('/target-kinerja/update/'.$target_kinerja->id)); ?>">
                        <?php echo method_field("PUT"); ?>
                        <?php echo csrf_field(); ?>
                        <div class="row mb-3">
                            <div class="col">
                                <label for="nomor" class="float-left">Nomor Target Kinerja</label>
                                <input type="text" class="form-control borderi <?php $__errorArgs = ['nomor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nomor" name="nomor" value="<?php echo e(old('nomor', $target_kinerja->nomor)); ?>" readonly>
                                <?php $__errorArgs = ['nomor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="table-responsive mb-3">
                            <?php
                                $old = session()->getOldInput();
                            ?>
                            <table class="table" id="tablemultiple" style="font-size:12px">
                                <thead>
                                    <tr>
                                        <th style="min-width: 300px; background-color:rgb(243, 243, 243);" class="text-center">Nama Pegawai</th>
                                        <th style="min-width: 200px; background-color:rgb(243, 243, 243);" class="text-center">Jabatan</th>
                                        <th style="min-width: 200px; background-color:rgb(243, 243, 243);" class="text-center">Target Pribadi</th>
                                        <th style="min-width: 130px; background-color:rgb(243, 243, 243);" class="text-center">Jumlah %</th>
                                        <th style="min-width: 200px; background-color:rgb(243, 243, 243);" class="text-center">Bonus Pribadi</th>
                                        <th class="text-center" style="background-color:rgb(243, 243, 243);">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(isset($old['user_id'])): ?>
                                        <?php $__currentLoopData = $old['user_id']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detailName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr id="multiple<?php echo e($key); ?>">
                                                <td style="vertical-align: middle;">
                                                    <select class="form-control borderi select2 user_id" id="user_id" name="user_id[]">
                                                        <option value="">-- Pilih --</option>
                                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($user->id); ?>" <?php echo e($user->id == old('user_id')[$key] ? 'selected="selected"' : ''); ?>>
                                                                <?php echo e($user->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>

                                                <td style="vertical-align: middle;">
                                                    <input type="text" class="form-control borderi jabatan" id="jabatan" name="jabatan[]" value="<?php echo e(old('jabatan')[$key]); ?>" readonly>
                                                </td>

                                                <td style="vertical-align: middle;">
                                                    <input type="text" class="form-control borderi money target_pribadi" id="target_pribadi" name="target_pribadi[]" value="<?php echo e(old('target_pribadi')[$key]); ?>">
                                                </td>

                                                <td style="vertical-align: middle;">
                                                    <div class="input-group" style="width: 120px">
                                                        <input type="number" class="form-control borderi jumlah_persen_pribadi" id="jumlah_persen_pribadi" name="jumlah_persen_pribadi[]" value="<?php echo e(old('jumlah_persen_pribadi')[$key]); ?>">
                                                        <div class="input-group-text borderi">
                                                            <span>%</span>
                                                        </div>
                                                    </div>
                                                </td>

                                                <td style="vertical-align: middle;">
                                                    <input type="text" class="form-control borderi money bonus_pribadi" id="bonus_pribadi" name="bonus_pribadi[]" value="<?php echo e(old('bonus_pribadi')[$key]); ?>" readonly>
                                                </td>

                                                <td class="text-center" style="vertical-align: middle;">
                                                    <a class="btn btn-sm btn-danger delete"><i class="fa fa-trash"></i></a>
                                                </td>

                                                <td style="display:none;">
                                                    <input type="hidden" class="jabatan_id" id="jabatan_id" name="jabatan_id[]" value="<?php echo e(old('jabatan_id')[$key]); ?>" readonly>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $target_kinerja->team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr id="multiple<?php echo e($key); ?>">
                                                <td style="vertical-align: middle;">
                                                    <select class="form-control borderi select2 user_id" id="user_id" name="user_id[]">
                                                        <option value="">-- Pilih --</option>
                                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($user->id); ?>" <?php echo e($user->id == $item->user_id ? 'selected="selected"' : ''); ?>>
                                                                <?php echo e($user->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>

                                                <td style="vertical-align: middle;">
                                                    <input type="text" class="form-control borderi jabatan" id="jabatan" name="jabatan[]" value="<?php echo e($item->jabatan->nama_jabatan ?? ''); ?>" readonly>
                                                </td>

                                                <td style="vertical-align: middle;">
                                                    <input type="text" class="form-control borderi money target_pribadi" id="target_pribadi" name="target_pribadi[]" value="<?php echo e($item->target_pribadi); ?>">
                                                </td>

                                                <td style="vertical-align: middle;">
                                                    <div class="input-group" style="width: 120px">
                                                        <input type="number" class="form-control borderi jumlah_persen_pribadi" id="jumlah_persen_pribadi" name="jumlah_persen_pribadi[]" value="<?php echo e($item->jumlah_persen_pribadi); ?>">
                                                        <div class="input-group-text borderi">
                                                            <span>%</span>
                                                        </div>
                                                    </div>
                                                </td>

                                                <td style="vertical-align: middle;">
                                                    <input type="text" class="form-control borderi money bonus_pribadi" id="bonus_pribadi" name="bonus_pribadi[]" value="<?php echo e($item->bonus_pribadi); ?>" readonly>
                                                </td>

                                                <td class="text-center" style="vertical-align: middle;">
                                                    <a class="btn btn-sm btn-danger delete"><i class="fa fa-trash"></i></a>
                                                </td>

                                                <td style="display:none;">
                                                    <input type="hidden" class="jabatan_id" id="jabatan_id" name="jabatan_id[]" value="<?php echo e($item->jabatan_id); ?>" readonly>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <a id="add_row" class="btn btn-sm btn-success mt-3">+ Tambah</a>
                        </div>

                        <div class="row mb-3">
                            <div class="col-6">
                                <label for="target_team" class="float-left">Target Team</label>
                                <input type="text" class="form-control borderi money <?php $__errorArgs = ['target_team'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="target_team" name="target_team" value="<?php echo e(old('target_team', $target_kinerja->target_team)); ?>" readonly>
                                <?php $__errorArgs = ['target_team'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-2">
                                <label for="jumlah_persen_team">Jumlah %</label>
                                <div class="input-group mb-3">
                                    <input type="number" class="form-control borderi <?php $__errorArgs = ['jumlah_persen_team'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jumlah_persen_team" id="jumlah_persen_team" value="<?php echo e(old('jumlah_persen_team', $target_kinerja->jumlah_persen_team)); ?>" onkeyup="getBonusTeam()">
                                    <div class="input-group-text borderi">
                                        <span>%</span>
                                    </div>
                                    <?php $__errorArgs = ['jumlah_persen_team'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-4">
                                <label for="bonus_team" class="float-left">Bonus Team</label>
                                <input type="text" class="form-control borderi money <?php $__errorArgs = ['bonus_team'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="bonus_team" name="bonus_team" value="<?php echo e(old('bonus_team', $target_kinerja->bonus_team)); ?>" readonly>
                                <?php $__errorArgs = ['bonus_team'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-3">
                                <label for="tanggal_awal" class="float-left">Tanggal Awal Target</label>
                                <input type="datetime" class="form-control borderi <?php $__errorArgs = ['tanggal_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tanggal_awal" name="tanggal_awal" value="<?php echo e(old('tanggal_awal', $target_kinerja->tanggal_awal)); ?>">
                                <?php $__errorArgs = ['tanggal_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-3">
                                <label for="tanggal_akhir" class="float-left">Tanggal Akhir Target</label>
                                <input type="datetime" class="form-control borderi <?php $__errorArgs = ['tanggal_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tanggal_akhir" name="tanggal_akhir" value="<?php echo e(old('tanggal_akhir', $target_kinerja->tanggal_akhir)); ?>">
                                <?php $__errorArgs = ['tanggal_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-2">
                                <label for="jackpot" class="float-end mt-3">Jackpot</label>
                            </div>

                            <div class="col-4">
                                <input type="text" class="form-control borderi money <?php $__errorArgs = ['jackpot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jackpot" name="jackpot" value="<?php echo e(old('jackpot', $target_kinerja->jackpot)); ?>">
                                <?php $__errorArgs = ['jackpot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary float-end">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('style'); ?>
        <style>
            .select2-container--default .select2-selection--single {
                border-color: rgb(201, 201, 201) !important;
            }
            td {
                border: 1px solid #e2dede;
            }
            th {
                border: 1px solid #e2dede;
            }
        </style>
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('script'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
        <script>
            function replaceCurrency(n) {
                if (n) {
                    return n.replace(/\,/g, '');
                }
            }

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('.money').mask('000,000,000,000,000', {
                reverse: true
            });

            $('.select2').select2();

            var row_number = 1;
            var temp_row_number = row_number-1;
            $("#add_row").click(function(e) {
                e.preventDefault();
                var new_row_number = row_number - 1;
                var table = document.getElementById("tablemultiple");
                var tbodyRowCount = table.tBodies[0].rows.length;
                $(".user_id").select2('destroy');
                new_row = $('#tablemultiple tbody tr:last').clone();
                new_row.find("input").val("").end();
                new_row.find("select").val("").end();
                $('#tablemultiple').append(new_row);
                $('#tablemultiple tbody tr:last').attr('id','multiple'+(tbodyRowCount));
                row_number++;
                $('.user_id').select2();
                $('.money').mask('000,000,000,000,000', {
                    reverse: true
                });
                temp_row_number = row_number - 1;
            });

            $('body').on('click', '.delete', function (event) {
                var table = document.getElementById("tablemultiple");
                var tbodyRowCount = table.tBodies[0].rows.length;
                if (tbodyRowCount <= 1) {
                    alert('Cannot delete if only 1 row!');
                } else {
                    if (confirm('Are you sure you want to delete?')) {
                        $(this).closest('tr').remove();
                        let target_team = 0;
                        $('.target_pribadi').each(function () {
                            target_team += $(this).closest('tr').find('td:eq(2) input').val() ?  parseFloat(replaceCurrency($(this).closest('tr').find('td:eq(2) input').val())) : 0;
                        });
                        let jumlah_persen_team = $('#jumlah_persen_team').val() ? parseFloat($('#jumlah_persen_team').val()) : 0;
                        let bonus_team = target_team * (jumlah_persen_team / 100);
                        $('#target_team').val(accounting.formatMoney(target_team, '', 0, ",", "."));
                        $('#bonus_team').val(accounting.formatMoney(bonus_team, '', 0, ",", "."));
                    }
                }
            });

            $('body').on('change', '.user_id', function (event) {
                let $row = $(this).closest('tr');
                let user_id = $row.find('td:eq(0) select').val();
                $.ajax({
                    type: 'POST',
                    url: "<?php echo e(url('/target-kinerja/ajaxUserJabatan')); ?>",
                    data: { user_id: user_id },
                    cache: false,
                    success: function(data) {
                        $row.find('td:eq(1) input').val(data.nama_jabatan);
                        $row.find('td:eq(6) input').val(data.id);
                    },
                    error: function(data) {
                        console.log('error:', data);
                    }
                });
            });

            $('body').on('keyup', '.target_pribadi', function (event) {
                let $row = $(this).closest('tr');
                let target_pribadi = $row.find('td:eq(2) input').val() ? parseFloat(replaceCurrency($row.find('td:eq(2) input').val())) : 0;
                let jumlah_persen_pribadi = $row.find('td:eq(3) input').val() ? parseFloat($row.find('td:eq(3) input').val()) : 0;
                let bonus_pribadi = target_pribadi * (jumlah_persen_pribadi / 100);
                $row.find('td:eq(4) input').val(accounting.formatMoney(bonus_pribadi, '', 0, ",", "."));

                let target_team = 0;
                $('.target_pribadi').each(function () {
                    target_team += $(this).closest('tr').find('td:eq(2) input').val() ?  parseFloat(replaceCurrency($(this).closest('tr').find('td:eq(2) input').val())) : 0;
                });

                let jumlah_persen_team = $('#jumlah_persen_team').val() ? parseFloat($('#jumlah_persen_team').val()) : 0;
                let bonus_team = target_team * (jumlah_persen_team / 100);

                $('#target_team').val(accounting.formatMoney(target_team, '', 0, ",", "."));
                $('#bonus_team').val(accounting.formatMoney(bonus_team, '', 0, ",", "."));
            });

            $('body').on('keyup', '.jumlah_persen_pribadi', function (event) {
                let $row = $(this).closest('tr');
                let target_pribadi = $row.find('td:eq(2) input').val() ? parseFloat(replaceCurrency($row.find('td:eq(2) input').val())) : 0;
                let jumlah_persen_pribadi = $row.find('td:eq(3) input').val() ? parseFloat($row.find('td:eq(3) input').val()) : 0;
                let bonus_pribadi = target_pribadi * (jumlah_persen_pribadi / 100);
                $row.find('td:eq(4) input').val(accounting.formatMoney(bonus_pribadi, '', 0, ",", "."));

                let target_team = 0;
                $('.target_pribadi').each(function () {
                    target_team += $(this).closest('tr').find('td:eq(2) input').val() ?  parseFloat(replaceCurrency($(this).closest('tr').find('td:eq(2) input').val())) : 0;
                });

                let jumlah_persen_team = $('#jumlah_persen_team').val() ? parseFloat($('#jumlah_persen_team').val()) : 0;
                let bonus_team = target_team * (jumlah_persen_team / 100);

                $('#target_team').val(accounting.formatMoney(target_team, '', 0, ",", "."));
                $('#bonus_team').val(accounting.formatMoney(bonus_team, '', 0, ",", "."));
            });

            function getBonusTeam() {
                let target_team = $('#target_team').val() ? parseFloat(replaceCurrency($('#target_team').val())) : 0;
                let jumlah_persen_team = $('#jumlah_persen_team').val() ? parseFloat($('#jumlah_persen_team').val()) : 0;
                let bonus_team = target_team * (jumlah_persen_team / 100);

                $('#bonus_team').val(accounting.formatMoney(bonus_team, '', 0, ",", "."));
            }

        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\absensi\resources\views/target-kinerja/edit.blade.php ENDPATH**/ ?>