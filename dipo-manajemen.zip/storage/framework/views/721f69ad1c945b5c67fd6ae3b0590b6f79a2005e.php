<?php $__env->startSection('isi'); ?>
    <div class="container-fluid">
        <div class="card col-lg-12">
            <div class="mt-4 p-3">
                <form method="post" action="<?php echo e(url('/data-cuti/edit-proses/'.$data_cuti_karyawan->id)); ?>">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="col">
                            <label for="user_id">Nama karyawan</label>
                            <input type="text" disabled class="form-control" value="<?php echo e($data_cuti_karyawan->User->name); ?>" id="user_id">
                        </div>
                        <div class="col">
                            <label for="nama_cuti">Nama Cuti</label>
                            <input type="text" class="form-control" value="<?php echo e($data_cuti_karyawan->nama_cuti); ?>" id="nama_cuti" disabled>
                            <input type="hidden" name="nama_cuti" value="<?php echo e($data_cuti_karyawan->nama_cuti); ?>">
                        </div>
                    </div>
                    <br>
                    <div class="form-row">
                        <div class="col">
                            <label for="tanggal">Tanggal</label>
                            <input type="datetime" class="form-control <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tanggal" id="tanggal" value="<?php echo e($data_cuti_karyawan->tanggal); ?>">
                            <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col">
                            <label for="alasan_cuti">Alasan Cuti</label>
                            <input type="text" disabled class="form-control" value="<?php echo e($data_cuti_karyawan->alasan_cuti); ?>">
                        </div>
                    </div>
                    <br>
                    <div class="form-row">
                        <?php
                            $status_cuti = array(
                            [
                                "status_cuti" => "Pending"
                            ],
                            [
                                "status_cuti" => "Ditolak"
                            ],
                            [
                                "status_cuti" => "Diterima"
                            ]);
                        ?>
                        <div class="col">
                            <label for="status_cuti">Status Cuti</label>
                            <select name="status_cuti" class="form-control <?php $__errorArgs = ['status_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> selectpicker" data-live-search="true" id="status_cuti">
                                <?php $__currentLoopData = $status_cuti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(old('status_cuti', $data_cuti_karyawan->status_cuti) == $sc["status_cuti"]): ?>
                                        <option value="<?php echo e($sc["status_cuti"]); ?>" selected><?php echo e($sc["status_cuti"]); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($sc["status_cuti"]); ?>"><?php echo e($sc["status_cuti"]); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['status_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col">
                            <label for="catatan">Catatan</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['catatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="catatan" id="catatan" value="<?php echo e(old('catatan', $data_cuti_karyawan->catatan)); ?>">
                            <?php $__errorArgs = ['catatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <br>
                    <input type="hidden" name="jam_absen">
                    <input type="hidden" name="telat">
                    <input type="hidden" name="lat_absen">
                    <input type="hidden" name="long_absen">
                    <input type="hidden" name="jarak_masuk">
                    <input type="hidden" name="foto_jam_absen">
                    <input type="hidden" name="jam_pulang">
                    <input type="hidden" name="pulang_cepat">
                    <input type="hidden" name="foto_jam_pulang">
                    <input type="hidden" name="foto_jam_pulang">
                    <input type="hidden" name="lat_pulang">
                    <input type="hidden" name="long_pulang">
                    <input type="hidden" name="jarak_pulang">
                    <input type="hidden" name="status_absen">
                    <input type="hidden" name="cuti_dadakan">
                    <input type="hidden" name="cuti_bersama">
                    <input type="hidden" name="cuti_menikah">
                    <input type="hidden" name="cuti_diluar_tanggungan">
                    <input type="hidden" name="cuti_khusus">
                    <input type="hidden" name="cuti_melahirkan">
                    <input type="hidden" name="izin_telat">
                    <input type="hidden" name="izin_pulang_cepat">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </form>
            </div>
        </div>
        <br>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gpiclick\resources\views/cuti/editadmin.blade.php ENDPATH**/ ?>