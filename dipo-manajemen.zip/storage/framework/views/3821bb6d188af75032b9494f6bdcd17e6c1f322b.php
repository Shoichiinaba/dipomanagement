<?php $__env->startComponent('mail::message'); ?>
# Dear <?php echo e($data->User->name); ?>


Masa Berlaku Dokumen <?php echo e($data->nama_dokumen); ?> Akan Habis Pada Tanggal <?php echo e($data->tanggal_berakhir); ?>, Segera Perbaharui.

Thanks,<br>
<h1 style="color: green">GPI<sup>Click</sup></h1>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\gpiclick\resources\views/emails/email.blade.php ENDPATH**/ ?>