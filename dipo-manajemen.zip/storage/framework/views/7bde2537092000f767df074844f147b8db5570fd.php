<?php $__env->startSection('isi'); ?>
    <div class="container-fluid">
            <div class="card col-lg-12">
                <div class="mt-4 p-3">
                    <form method="post" action="<?php echo e(url('/cuti/proses-edit/'.$data_cuti_user->id)); ?>" enctype="multipart/form-data">
                        <?php echo method_field('put'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="col">
                                <label for="user_id">Nama Karyawan</label>
                                <select id="user_id" name="user_id" class="form-control selectpicker" id="">
                                    <option value="<?php echo e($data_cuti_user->User->id); ?>"><?php echo e($data_cuti_user->User->name); ?></option>
                                </select>
                            </div>
                            <div class="col">
                                <?php
                                    $cuti_dadakan = $data_cuti_user->User->cuti_dadakan;
                                    $cuti_bersama = $data_cuti_user->User->cuti_bersama;
                                    $cuti_menikah = $data_cuti_user->User->cuti_menikah;
                                    $cuti_diluar_tanggungan = $data_cuti_user->User->cuti_diluar_tanggungan;
                                    $cuti_khusus = $data_cuti_user->User->cuti_khusus;
                                    $cuti_melahirkan = $data_cuti_user->User->cuti_melahirkan;
                                    $izin_telat = $data_cuti_user->User->izin_telat;
                                    $izin_pulang_cepat = $data_cuti_user->User->izin_pulang_cepat;

                                    $data_cuti = array(
                                        [
                                            'nama' => 'Cuti Dadakan',
                                            'nama_cuti' => 'Cuti Dadakan ('.$cuti_dadakan.')'
                                        ],
                                        [
                                            'nama' => 'Cuti Bersama',
                                            'nama_cuti' => 'Cuti Bersama ('.$cuti_bersama.')'
                                        ],
                                        [
                                            'nama' => 'Cuti Menikah',
                                            'nama_cuti' => 'Cuti Menikah ('.$cuti_menikah.')'
                                        ],
                                        [
                                            'nama' => 'Cuti Diluar Tanggungan',
                                            'nama_cuti' => 'Cuti Diluar Tanggungan ('.$cuti_diluar_tanggungan.')'
                                        ],
                                        [
                                            'nama' => 'Cuti Khusus',
                                            'nama_cuti' => 'Cuti Khusus ('.$cuti_khusus.')'
                                        ],
                                        [
                                            'nama' => 'Cuti Melahirkan',
                                            'nama_cuti' => 'Cuti Melahirkan ('.$cuti_melahirkan.')'
                                        ],
                                        [
                                            'nama' => 'Izin Telat',
                                            'nama_cuti' => 'Izin Telat ('.$izin_telat.')'
                                        ],
                                        [
                                            'nama' => 'Izin Pulang Cepat',
                                            'nama_cuti' => 'Izin Pulang Cepat ('.$izin_pulang_cepat.')'
                                        ]
                                    );
                                ?>
                                <label for="nama_cuti">Nama Cuti</label>
                                <select class="form-control selectpicker <?php $__errorArgs = ['nama_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_cuti" name="nama_cuti" data-live-search="true">
                                    <option value="">Pilih Cuti</option>
                                    <?php $__currentLoopData = $data_cuti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(old('nama_cuti', $data_cuti_user->nama_cuti) == $dc["nama"]): ?>
                                    <option value="<?php echo e($dc["nama"]); ?>" selected><?php echo e($dc["nama_cuti"]); ?></option>
                                    <?php else: ?>
                                    <option value="<?php echo e($dc["nama"]); ?>"><?php echo e($dc["nama_cuti"]); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['nama_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <br>
                        <div class="form-row">
                            <div class="col">
                                <label for="tanggal">Tanggal</label>
                                <input type="datetime" class="form-control <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tanggal" id="tanggal" value="<?php echo e(old('tanggal', $data_cuti_user->tanggal)); ?>">
                                <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col">
                                <label for="foto_cuti">Unggah Foto</label>
                                <input type="file" name="foto_cuti" id="foto_cuti" class="form-control <?php $__errorArgs = ['foto_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['foto_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input type="hidden" name="foto_cuti_lama" value="<?php echo e($data_cuti_user->foto_cuti); ?>">
                            </div>
                        </div>
                        <br>
                        <div class="form-row">
                            <div class="col">
                                <label for="alasan_cuti">Alasan Cuti</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['alasan_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alasan_cuti" name="alasan_cuti" value="<?php echo e(old('alasan_cuti', $data_cuti_user->alasan_cuti)); ?>">
                                <?php $__errorArgs = ['alasan_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <br>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                    <br>
                </div>
            </div>
    </div>
    <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gpiclick\resources\views/cuti/edit.blade.php ENDPATH**/ ?>