                            <?php if(session()->has('success')): ?>
                              <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(session('success')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                            <?php endif; ?>

<table id="tableprint" class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>No.</th>
            <th>Nama</th>
            <th>Email</th>
            <th>Username</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $du): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($du->name); ?></td>
                <td><?php echo e($du->email); ?></td>
                <td><?php echo e($du->username); ?></td>
                <td>
                    <a href="<?php echo e(url('/users/detail/'.$du->id)); ?>" class="btn btn-sm btn-info"><i class="fa fa-solid fa-eye"></i></a>
                    <a href="<?php echo e(url('/users/edit-password/'.$du->id)); ?>" class="btn btn-sm btn-warning"><i class="fa fa-solid fa-key"></i></a>
                    <a href="<?php echo e(url('/users/delete/'.$du->id)); ?>" class="btn btn-sm btn-danger"><i class="fa fas fa-exclamation-triangle"></i></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <script>
    $(function () {
        $("#tableprint").DataTable({
        "responsive": true, "lengthChange": false, "autoWidth": false,
        "buttons": ["excel", "pdf", "print"]
        // "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('#tableprint_wrapper .col-md-6:eq(0)');
    });
  </script>
<?php /**PATH C:\xampp\htdocs\ricky\resources\views/users/getdatausers.blade.php ENDPATH**/ ?>