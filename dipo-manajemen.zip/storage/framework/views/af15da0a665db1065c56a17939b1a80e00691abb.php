<?php $__env->startSection('container'); ?>
    <div class="card-secton transfer-section">
        <div class="tf-container">
            <div class="tf-balance-box">
                    <form method="post" class="tf-form p-2" action="<?php echo e(url('/target-kinerja/update-user/'.$target_kinerja_team->id.'/'.$target_kinerja->id)); ?>" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="group-input">
                            <label for="judul" class="float-left">Judul</label>
                            <input type="text" class="<?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="judul" name="judul" value="<?php echo e(old('judul', $target_kinerja_team->judul)); ?>">
                            <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="group-input">
                            <label for="jumlah" class="float-left">Jumlah Penjualan</label>
                            <input type="text" class="money <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah" name="jumlah" value="<?php echo e(old('jumlah', $target_kinerja_team->jumlah)); ?>" onkeyup="calculation()">
                            <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="group-input">
                            <label for="target_pribadi" class="float-left">Target Pribadi</label>
                            <input type="text" class="money <?php $__errorArgs = ['target_pribadi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="target_pribadi" name="target_pribadi" value="<?php echo e(old('target_pribadi', $target_kinerja_team->target_pribadi)); ?>" readonly>
                            <?php $__errorArgs = ['target_pribadi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="group-input">
                            <label for="sisa_target_pribadi" class="float-left">Sisa Target Pribadi</label>
                            <input type="text" class="money <?php $__errorArgs = ['sisa_target_pribadi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="sisa_target_pribadi" name="sisa_target_pribadi" value="<?php echo e(old('sisa_target_pribadi', $target_kinerja_team->target_pribadi - $target_kinerja_team->jumlah)); ?>" readonly>
                            <?php $__errorArgs = ['sisa_target_pribadi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="row">
                            <div class="col group-input">
                                <label for="capai" class="float-left">Capai %</label>
                                <input type="text" class="<?php $__errorArgs = ['capai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="capai" name="capai" value="<?php echo e(old('capai', $target_kinerja_team->capai)); ?>" readonly>
                                <?php $__errorArgs = ['capai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col group-input">
                                <label for="nilai" class="float-left">Nilai</label>
                                <input type="text" class="<?php $__errorArgs = ['nilai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nilai" name="nilai" value="<?php echo e(old('nilai', $target_kinerja_team->nilai)); ?>" readonly>
                                <?php $__errorArgs = ['nilai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="group-input">
                            <label for="target_team" class="float-left">Target Team</label>
                            <input type="text" class="money <?php $__errorArgs = ['target_team'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="target_team" name="target_team" value="<?php echo e(old('target_team', $target_kinerja->target_team)); ?>" readonly>
                            <?php $__errorArgs = ['target_team'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="group-input">
                            <label for="sisa_target_team" class="float-left">Sisa Target Team</label>
                            <input type="text" class="money <?php $__errorArgs = ['sisa_target_team'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="sisa_target_team" name="sisa_target_team" value="<?php echo e(old('sisa_target_team', $target_kinerja->target_team - $sum_jumlah - $target_kinerja_team->jumlah)); ?>" readonly>
                            <?php $__errorArgs = ['sisa_target_team'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <input type="hidden" name="sum_jumlah" id="sum_jumlah" class="sum_jumlah" value="<?php echo e($sum_jumlah); ?>">


                        <div class="row">
                            <div class="col group-input">
                                <label for="bonus_p" class="float-left">Bonus Pribadi</label>
                                <input type="text" class="money <?php $__errorArgs = ['bonus_p'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="bonus_p" name="bonus_p" value="<?php echo e(old('bonus_p', $target_kinerja_team->bonus_p)); ?>" readonly>
                                <?php $__errorArgs = ['bonus_p'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <input type="hidden" name="jumlah_persen_pribadi" id="jumlah_persen_pribadi" class="jumlah_persen_pribadi" value="<?php echo e($target_kinerja_team->jumlah_persen_pribadi); ?>">

                            <div class="col group-input">
                                <label for="bonus_t" class="float-left">Bonus Team</label>
                                <input type="text" class="money <?php $__errorArgs = ['bonus_t'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="bonus_t" name="bonus_t" value="<?php echo e(old('bonus_t', $target_kinerja_team->bonus_t)); ?>" readonly>
                                <?php $__errorArgs = ['bonus_t'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <input type="hidden" name="jumlah_persen_team" id="jumlah_persen_team" class="jumlah_persen_team" value="<?php echo e($target_kinerja->jumlah_persen_team); ?>">

                        </div>

                        <div class="row">
                            <div class="col group-input">
                                <label for="tanggal_awal" class="float-left">Tanggal Awal Target</label>
                                <input type="text" class="<?php $__errorArgs = ['tanggal_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tanggal_awal" name="tanggal_awal" value="<?php echo e(old('tanggal_awal', $target_kinerja->tanggal_awal)); ?>" readonly>
                                <?php $__errorArgs = ['tanggal_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col group-input">
                                <label for="tanggal_akhir" class="float-left">Tanggal Akhir Target</label>
                                <input type="text" class=" <?php $__errorArgs = ['tanggal_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tanggal_akhir" name="tanggal_akhir" value="<?php echo e(old('tanggal_akhir', $target_kinerja->tanggal_akhir)); ?>" readonly>
                                <?php $__errorArgs = ['tanggal_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="group-input">
                            <label for="keterangan" class="form-label">Keterangan</label>
                            <textarea name="keterangan" id="keterangan" class="<?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30" rows="10"><?php echo e(old('keterangan', $target_kinerja_team->keterangan)); ?></textarea>
                            <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <button type="submit" class="btn btn-primary float-right">Submit</button>
                    </form>
            </div>
        </div>
    </div>
    <br>
    <br>
    <br>
    <br>
     <?php $__env->startPush('script'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
        <script>
            function replaceCurrency(n) {
                if (n) {
                    return n.replace(/\,/g, '');
                }
            }

            $('.money').mask('000,000,000,000,000', {
                reverse: true
            });


            function calculation() {
                let target_pribadi = $('#target_pribadi').val() ? parseFloat(replaceCurrency($('#target_pribadi').val())) : 0;
                let jumlah = $('#jumlah').val() ? parseFloat(replaceCurrency($('#jumlah').val())) : 0;
                let sisa_target_pribadi = target_pribadi - jumlah;
                $('#sisa_target_pribadi').val(accounting.formatMoney(sisa_target_pribadi, '', 0, ",", "."));
                let capai = (jumlah / target_pribadi) * 100;
                if (capai <= 50) {
                    $('#nilai').val('Buruk');
                } else if (capai <= 70) {
                    $('#nilai').val('Cukup');
                } else if (capai <= 80) {
                    $('#nilai').val('Baik');
                } else {
                    $('#nilai').val('Mantap');
                }
                $('#capai').val(capai.toFixed(2));

                let target_team = $('#target_team').val() ? parseFloat(replaceCurrency($('#target_team').val())) : 0;
                let sum_jumlah = $('#sum_jumlah').val() ? parseFloat($('#sum_jumlah').val()) : 0;
                let sisa_target_team = target_team - sum_jumlah - jumlah;
                $('#sisa_target_team').val(accounting.formatMoney(sisa_target_team, '', 0, ",", "."));

                let jumlah_persen_pribadi = $('#jumlah_persen_pribadi').val() ? parseFloat($('#jumlah_persen_pribadi').val()) : 0;
                let bonus_p = jumlah * (jumlah_persen_pribadi / 100);
                $('#bonus_p').val(accounting.formatMoney(bonus_p, '', 0, ",", "."));

                let jumlah_persen_team = $('#jumlah_persen_team').val() ? parseFloat($('#jumlah_persen_team').val()) : 0;
                let bonus_t = (target_team - sisa_target_team) * (jumlah_persen_team / 100);
                $('#bonus_t').val(accounting.formatMoney(bonus_t, '', 0, ",", "."));

            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\absensi\resources\views/target-kinerja/editUser.blade.php ENDPATH**/ ?>