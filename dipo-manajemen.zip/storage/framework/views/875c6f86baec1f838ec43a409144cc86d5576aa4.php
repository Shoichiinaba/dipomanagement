<?php $__env->startSection('container'); ?>
    <div id="app-wrap" class="style1">
        <div class="tf-container">
            <div class="tf-tab">
                <div class="bill-content mt-4">
                    <div class="tf-container ">
                        <ul>
                            <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                <div class="content-right">
                                    <p>
                                    Nomor Pengajuan Keuangan
                                    </p>
                                    <h5>
                                        <?php echo e($pk->nomor ?? '-'); ?>

                                    </h5>
                                </div>
                            </li>

                            <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                <div class="content-right">
                                    <p>
                                    Nama Pegawai
                                    </p>
                                    <h5>
                                        <?php echo e($pk->user->name ?? '-'); ?>

                                    </h5>
                                </div>
                            </li>

                            <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                <div class="content-right">
                                    <p>
                                    Tanggal
                                    </p>
                                    <h5>
                                        <?php if($pk->tanggal): ?>
                                            <?php
                                                Carbon\Carbon::setLocale('id');
                                                $tanggal = Carbon\Carbon::createFromFormat('Y-m-d', $pk->tanggal);
                                                $new_tanggal = $tanggal->translatedFormat('d F Y');
                                            ?>
                                            <?php echo e($new_tanggal); ?>

                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </h5>
                                </div>
                            </li>


                            <?php $__currentLoopData = $pk->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                    <div class="content-right">
                                        <p>
                                            <div class="row">
                                                <div class="col-4" style="color: black; font-weight:bold;">
                                                    <?php echo e($loop->iteration); ?>. Nama Barang
                                                </div>
                                                <div class="col-1" style="color: black; font-weight:bold;">
                                                    :
                                                </div>
                                                <div class="col-7" style="color: black; font-weight:bold;">
                                                    <?php echo e($item->nama); ?>

                                                </div>
                                            </div>
                                        </p>
                                        <p>
                                            <div class="row">
                                                <div class="col-4" style="color: black; font-weight:bold;">
                                                    <span class="ms-3">Qty</span>
                                                </div>
                                                <div class="col-1" style="color: black; font-weight:bold;">
                                                    :
                                                </div>
                                                <div class="col-7" style="color: black; font-weight:bold;">
                                                    <?php echo e($item->qty); ?>

                                                </div>
                                            </div>
                                        </p>
                                        <p>
                                            <div class="row">
                                                <div class="col-4" style="color: black; font-weight:bold;">
                                                    <span class="ms-3">Harga</span>
                                                </div>
                                                <div class="col-1" style="color: black; font-weight:bold;">
                                                    :
                                                </div>
                                                <div class="col-7" style="color: black; font-weight:bold;">
                                                    Rp <?php echo e(number_format($item->harga)); ?>

                                                </div>
                                            </div>
                                        </p>
                                        <p>
                                            <div class="row">
                                                <div class="col-4" style="color: black; font-weight:bold;">
                                                    <span class="ms-3">Total</span>
                                                </div>
                                                <div class="col-1" style="color: black; font-weight:bold;">
                                                    :
                                                </div>
                                                <div class="col-7" style="color: black; font-weight:bold;">
                                                    Rp <?php echo e(number_format($item->total)); ?>

                                                </div>
                                            </div>
                                        </p>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                <div class="content-right">
                                    <p>
                                    Total Pengajuan
                                    </p>
                                    <h5>
                                        Rp <?php echo e(number_format($pk->total_harga)); ?>

                                    </h5>
                                </div>
                            </li>

                            <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                <div class="content-right">
                                    <p>
                                    Keterangan
                                    </p>
                                    <h5>
                                        <?php echo $pk->keterangan ? nl2br(e($pk->keterangan)) : '-'; ?>

                                    </h5>
                                </div>
                            </li>

                            <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                <div class="content-right">
                                    <p>
                                    File
                                    </p>
                                    <h5>
                                        <?php if($pk->pk_file_path): ?>
                                            <a target="_blank" href="<?php echo e(url('/storage/'.$pk->pk_file_path)); ?>"><span style="color: rgb(21, 47, 118); background-color:rgba(192, 218, 254, 0.889); border-radius:10px;" class="badge"><i class="fa fa-download me-2"></i><?php echo e($pk->pk_file_name); ?></span></a>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </h5>
                                </div>
                            </li>

                            <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                <div class="content-right">
                                    <p>
                                    Status
                                    </p>
                                    <h5>
                                        <?php if($pk->status == 'REJECTED'): ?>
                                            <div class="badge" style="color: rgba(78, 26, 26, 0.889); background-color:rgb(242, 170, 170); border-radius:10px;"><?php echo e($pk->status ?? '-'); ?></div>
                                        <?php elseif($pk->status == 'APPROVED'): ?>
                                            <div class="badge" style="color: rgba(20, 78, 7, 0.889); background-color:rgb(186, 238, 162); border-radius:10px;"><?php echo e($pk->status ?? '-'); ?></div>
                                        <?php elseif($pk->status == 'PENDING'): ?>
                                            <div class="badge" style="color: rgba(255, 123, 0, 0.889); background-color:rgb(255, 238, 177); border-radius:10px;"><?php echo e($pk->status ?? '-'); ?></div>
                                        <?php elseif($pk->status == 'ON GOING'): ?>
                                            <div class="badge" style="color: rgb(21, 47, 118); background-color:rgba(192, 218, 254, 0.889); border-radius:10px;"><?php echo e($pk->status ?? '-'); ?></div>
                                        <?php else: ?>
                                            <div class="badge" style="color: rgb(45, 45, 45); background-color:rgba(207, 207, 207, 0.889); border-radius:10px;"><?php echo e($pk->status ?? '-'); ?></div>
                                        <?php endif; ?>
                                    </h5>
                                </div>
                            </li>

                            <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                <div class="content-right">
                                    <p>
                                    User Approval
                                    </p>
                                    <h5>
                                        <?php echo e($pk->ua->name ?? '-'); ?>

                                    </h5>
                                </div>
                            </li>

                            <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                <div class="content-right">
                                    <p>
                                    Nota
                                    </p>
                                    <h5>
                                        <?php if($pk->nota_file_path): ?>
                                            <a target="_blank" href="<?php echo e(url('/storage/'.$pk->nota_file_path)); ?>"><span style="color: rgb(21, 47, 118); background-color:rgba(192, 218, 254, 0.889); border-radius:10px;" class="badge"><i class="fa fa-download me-2"></i><?php echo e($pk->nota_file_name); ?></span></a>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </h5>
                                </div>
                            </li>

                            <?php if($pk->status == 'PENDING'): ?>
                                <div class="row">
                                    <div class="col">
                                        <a href="<?php echo e(url('/pengajuan-keuangan/edit/'.$pk->id)); ?>" class="tf-btn accent large">Edit</a>
                                    </div>
                                    <div class="col">
                                        <a href="<?php echo e(url('/pengajuan-keuangan/delete/'.$pk->id)); ?>" onclick="return confirm('are you sure?')" class="tf-btn accent large" style="background-color: red">Delete</a>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if($pk->status == 'APPROVED'): ?>
                                <a href="<?php echo e(url('/pengajuan-keuangan/accept/'.$pk->id)); ?>" onclick="return confirm('are you sure?')" class="tf-btn accent large" style="background-color: green">Terima Uang</a>
                            <?php endif; ?>

                            <?php if($pk->status == 'ON GOING'): ?>
                                <a href="#" id="btn-popup-down" class="tf-btn accent large">Upload Nota</a>
                            <?php endif; ?>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="tf-panel down">
        <div class="panel_overlay"></div>
        <div class="panel-box panel-down">
            <div class="header">
                <div class="tf-container">
                    <div class="tf-statusbar d-flex justify-content-center align-items-center">
                        <a href="#" class="clear-panel"> <i class="icon-close1"></i> </a>
                        <h3>Upload Nota</h3>
                    </div>

                </div>
            </div>

            <div class="mt-5">
                <div class="tf-container">
                    <form class="tf-form-verify" action="<?php echo e(url('/pengajuan-keuangan/nota/'.$pk->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="group-input">
                            <input type="file" class="form-control <?php $__errorArgs = ['nota_file_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nota_file_path" value="<?php echo e(old('nota_file_path')); ?>" />
                            <?php $__errorArgs = ['nota_file_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mt-7 mb-6">
                            <button type="submit" class="tf-btn accent">Submit</button>
                        </div>
                </form>
                </div>
            </div>
        </div>
    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\absensi\resources\views/pengajuan-keuangan/show.blade.php ENDPATH**/ ?>