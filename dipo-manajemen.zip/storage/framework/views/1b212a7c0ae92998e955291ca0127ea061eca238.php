<?php $__env->startSection('isi'); ?>
    <div class="row">
        <div class="col-md-12 project-list">
            <div class="card">
                <div class="row">
                    <div class="col-md-6 mt-2 p-0 d-flex">
                        <h4><?php echo e($title); ?></h4>
                    </div>
                    <div class="col-md-6 p-0">
                        <a href="<?php echo e(url('/penugasan/tambah')); ?>" class="btn btn-primary ms-2">+ Tambah</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <form action="<?php echo e(url('/laporan-kinerja')); ?>">
                        <div class="row mb-2">
                            <div class="col-5">
                                <input type="datetime" class="form-control" name="mulai" placeholder="Tanggal Mulai" id="mulai" value="<?php echo e(request('mulai')); ?>">
                            </div>
                            <div class="col-5">
                                <input type="datetime" class="form-control" name="akhir" placeholder="Tanggal Akhir" id="akhir" value="<?php echo e(request('akhir')); ?>">
                            </div>
                            <div class="col-2">
                                <button type="submit" id="search"class="border-0 mt-3" style="background-color: transparent;"><i class="fas fa-search"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th class="text-center">No.</th>
                                    <th style="min-width: 130px;" class="text-center">Nomor Penugasan</th>
                                    <th style="min-width: 180px;" class="text-center">Tanggal</th>
                                    <th style="min-width: 250px;" class="text-center">Nama Pegawai</th>
                                    <th style="min-width: 200px;" class="text-center">Judul</th>
                                    <th style="min-width: 300px;" class="text-center">Rincian</th>
                                    <th style="min-width: 570px;" class="text-center">Progress</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($penugasans) <= 0): ?>
                                    <tr>
                                        <td colspan="10" class="text-center">Tidak Ada Data</td>
                                    </tr>
                                <?php else: ?>
                                    <?php $__currentLoopData = $penugasans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $penugasan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(($penugasans->currentpage() - 1) * $penugasans->perpage() + $key + 1); ?>.</td>
                                            <td class="text-center"><?php echo e($penugasan->nomor_penugasan ?? '-'); ?></td>
                                            <td class="text-center">
                                                <?php if($penugasan->tanggal): ?>
                                                    <?php
                                                        Carbon\Carbon::setLocale('id');
                                                        $tanggal = Carbon\Carbon::createFromFormat('Y-m-d', $penugasan->tanggal);
                                                        $new_tanggal = $tanggal->translatedFormat('d F Y');
                                                    ?>
                                                    <?php echo e($new_tanggal); ?>

                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center"><?php echo e($penugasan->user->name ?? '-'); ?></td>
                                            <td class="text-center"><?php echo e($penugasan->judul ?? '-'); ?></td>
                                            <td><?php echo $penugasan->rincian ? nl2br(e($penugasan->rincian)) : '-'; ?></td>
                                            <td>
                                                <?php if(count($penugasan->items) > 0): ?>
                                                    <?php $__currentLoopData = $penugasan->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($item->flow == 'PENDING'): ?>
                                                            <span class="float-start"><?php echo e($item->user->name ?? '-'); ?></span> <span class="float-end btn btn-xs" style="color: rgba(255, 123, 0, 0.889); background-color:rgb(255, 238, 177); border-radius:10px;"><?php echo e($item->flow ?? '-'); ?></span>
                                                            <br>
                                                            <span style="color: rgb(173, 173, 173); font-size:10px">
                                                                <?php if($item->created_at): ?>
                                                                    <?php
                                                                        Carbon\Carbon::setLocale('id');
                                                                        $created_at = Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->created_at);
                                                                        $new_created_at = $created_at->translatedFormat('l, d F Y H:i:s');
                                                                    ?>
                                                                    <?php echo e($new_created_at); ?>

                                                                <?php else: ?>
                                                                    -
                                                                <?php endif; ?>
                                                            </span>
                                                            <br>
                                                            <span style="color: rgb(173, 173, 173); font-size:10px;">Tugas <?php echo e($penugasan->nomor_penugasan); ?> ditugaskan kepada <?php echo e($penugasan->user->name ?? '-'); ?> oleh <?php echo e($item->user->name ?? '-'); ?></span>
                                                        <?php elseif($item->flow == 'PROCESS'): ?>
                                                            <span class="float-start"><?php echo e($item->user->name ?? '-'); ?></span> <span class="float-end btn btn-xs" style="color: rgb(21, 47, 118); background-color:rgba(192, 218, 254, 0.889); border-radius:10px;"><?php echo e($item->flow ?? '-'); ?></span>
                                                            <br>
                                                            <span style="color: rgb(173, 173, 173); font-size:10px">
                                                                <?php if($item->created_at): ?>
                                                                    <?php
                                                                        Carbon\Carbon::setLocale('id');
                                                                        $created_at = Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->created_at);
                                                                        $new_created_at = $created_at->translatedFormat('l, d F Y H:i:s');
                                                                    ?>
                                                                    <?php echo e($new_created_at); ?>

                                                                <?php else: ?>
                                                                    -
                                                                <?php endif; ?>
                                                            </span>
                                                            <br>
                                                            <span style="color: rgb(173, 173, 173); font-size:10px;">Tugas <?php echo e($penugasan->nomor_penugasan); ?> diproses oleh <?php echo e($item->user->name ?? '-'); ?></span>
                                                        <?php else: ?>
                                                            <span class="float-start"><?php echo e($item->user->name ?? '-'); ?></span> <span class="float-end btn btn-xs" style="color: rgba(20, 78, 7, 0.889); background-color:rgb(186, 238, 162); border-radius:10px;"><?php echo e($item->flow ?? '-'); ?></span>
                                                            <br>
                                                            <span style="color: rgb(173, 173, 173); font-size:10px">
                                                                <?php if($item->created_at): ?>
                                                                    <?php
                                                                        Carbon\Carbon::setLocale('id');
                                                                        $created_at = Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->created_at);
                                                                        $new_created_at = $created_at->translatedFormat('l, d F Y H:i:s');
                                                                    ?>
                                                                    <?php echo e($new_created_at); ?>

                                                                <?php else: ?>
                                                                    -
                                                                <?php endif; ?>
                                                            </span>
                                                            <br>
                                                            <span style="color: rgb(173, 173, 173); font-size:10px;">Tugas <?php echo e($penugasan->nomor_penugasan); ?> diselesaikan oleh <?php echo e($item->user->name ?? '-'); ?></span>
                                                        <?php endif; ?>
                                                        <?php if(!$loop->last): ?>
                                                            <hr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <?php if($penugasan->status == 'PENDING'): ?>
                                                    <span class="float-end btn btn-xs" style="color: rgba(255, 123, 0, 0.889); background-color:rgb(255, 238, 177); border-radius:10px;"><?php echo e($penugasan->status ?? '-'); ?></span>
                                                <?php elseif($penugasan->status == 'PROCESS'): ?>
                                                    <span class="float-end btn btn-xs" style="color: rgb(21, 47, 118); background-color:rgba(192, 218, 254, 0.889); border-radius:10px;"><?php echo e($penugasan->status ?? '-'); ?></span>
                                                <?php else: ?>
                                                    <span class="float-end btn btn-xs" style="color: rgba(20, 78, 7, 0.889); background-color:rgb(186, 238, 162); border-radius:10px;"><?php echo e($penugasan->status ?? '-'); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <ul class="action">
                                                    <?php if($penugasan->status == 'PENDING'): ?>
                                                        <li class="edit">
                                                            <a href="<?php echo e(url('/penugasan/edit/'.$penugasan->id)); ?>"><i class="fa fa-solid fa-edit"></i></a>
                                                        </li>
                                                        <li class="delete">
                                                            <form action="<?php echo e(url('/penugasan/delete/'.$penugasan->id)); ?>" method="post" class="d-inline">
                                                                <?php echo method_field('delete'); ?>
                                                                <?php echo csrf_field(); ?>
                                                                <button class="border-0" style="background-color: transparent;" onClick="return confirm('Are You Sure')"><i class="fa fa-solid fa-trash"></i></button>
                                                            </form>
                                                        </li>
                                                    <?php endif; ?>
                                                </ul>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-end mt-4">
                        <?php echo e($penugasans->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>

    <?php $__env->startPush('script'); ?>
        <script>
            $(document).ready(function() {
                $('#mulai').change(function(){
                    var mulai = $(this).val();
                $('#akhir').val(mulai);
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\absensi\resources\views/penugasan/index.blade.php ENDPATH**/ ?>