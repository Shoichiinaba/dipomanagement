
<?php $__env->startSection('isi'); ?>
    <div class="container-fluid">
        <center>
            <div class="card col-lg-5">
                <div class="p-4">
                    <form method="post" action="<?php echo e(url('/file/upload-proses')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="user_id" class="float-left">Nama Pegawai</label>
                                <select class="form-control selectpicker <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="user_id" name="user_id" data-live-search="true">
                                    <option value="">Pilih Pegawai</option>
                                    <?php $__currentLoopData = $data_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $du): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(old('user_id') == $du->id): ?>
                                            <option value="<?php echo e($du->id); ?>" selected><?php echo e($du->name); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($du->id); ?>"><?php echo e($du->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <?php $jenis_file = array(
                                [
                                    "jenis_file" => "Absensi"
                                ],
                                [
                                    "jenis_file" => "Database Karyawan"
                                ],
                                [
                                    "jenis_file" => "Penilaian Kinerja"
                                ],
                                [
                                    "jenis_file" => "Perhitungan Cuti"
                                ],
                                [
                                    "jenis_file" => "KPI Departemen Satu Dashboard"
                                ],
                                [
                                    "jenis_file" => "Data Audit"
                                ],
                                [
                                    "jenis_file" => "Form Peralatan, Cuti, Pinjam Uang, Perbaikannya Mesin, Lemburan, Berita Acara, Kaizen"
                                ],
                                [
                                    "jenis_file" => "Perhitungan Payrol Kit"
                                ],
                                [
                                    "jenis_file" => "Kontrak Kerja"
                                ],
                                [
                                    "jenis_file" => "Jadwal Produksi"
                                ],
                                [
                                    "jenis_file" => "Recruitment"
                                ],
                                [
                                    "jenis_file" => "Penilain Karyawan"
                                ],
                                [
                                    "jenis_file" => "Resume Meeting"
                                ],
                                [
                                    "jenis_file" => "Data Laporan Harian Bulanan Karyawan"
                                ],
                                [
                                    "jenis_file" => "SOP Karyawan"
                                ]);
                                ?>
                                <label for="jenis_file" class="float-left">Jenis File</label>
                                <select name="jenis_file" id="jenis_file" class="form-control selectpicker" data-live-search="true">
                                    <option value="">Pilih Jenis File</option>
                                    <?php $__currentLoopData = $jenis_file; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(old('jenis_file') == $jf["jenis_file"]): ?>
                                        <option value="<?php echo e($jf["jenis_file"]); ?>" selected><?php echo e($jf["jenis_file"]); ?></option>
                                        <?php else: ?>
                                        <option value="<?php echo e($jf["jenis_file"]); ?>"><?php echo e($jf["jenis_file"]); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['jenis_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="fileUpload" class="float-left">File</label>
                                <input class="form-control <?php $__errorArgs = ['fileUpload'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="fileUpload" name="fileUpload">
                                <span class="float-left font-italic form-control-sm">File yang di perbolehkan doc,docx,pdf,xls,xlsx,ppt,pptx dan Max Size 10 MB</span>
                                <?php $__errorArgs = ['fileUpload'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <button type="submit" class="btn btn-primary float-right">Submit</button>
                      </form>
                </div>
            </div>
        </center>
    </div>
    <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\absensi\resources\views/file/upload.blade.php ENDPATH**/ ?>