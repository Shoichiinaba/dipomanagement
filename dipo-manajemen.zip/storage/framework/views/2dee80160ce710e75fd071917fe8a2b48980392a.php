<?php $__env->startSection('isi'); ?>
  <div class="row">
    <div class="col-xl-12">
      <div class="items-slider">
        <div class="col-xl-2 col-lg-4 col-sm-4 des-xsm-50 box-col-33">
          <div class="card investment-sec">
            <div class="animated-bg"><i></i><i></i><i></i></div>
            <div class="card-body">
              <div class="icon"><i data-feather="users"></i></div>
              <p>Total Pegawai</p>
              <h3><?php echo e($jumlah_user); ?></h3>
            </div>
          </div>
        </div>
        <div class="col-xl-2 col-lg-4 col-sm-4 des-xsm-50 box-col-33">
          <div class="card investment-sec">
            <div class="animated-bg"><i></i><i></i><i></i></div>
            <div class="card-body">
              <div class="icon"><i data-feather="database"></i></div>
              <p>Masuk</p>
              <h3><?php echo e($jumlah_masuk + $jumlah_izin_telat + $jumlah_izin_pulang_cepat); ?></h3>
            </div>
          </div>
        </div>
        <div class="col-xl-2 col-lg-4 col-sm-4 des-xsm-50 box-col-33">
          <div class="card investment-sec">
            <div class="animated-bg"><i></i><i></i><i></i></div>
            <div class="card-body">
              <div class="icon"><i data-feather="user"></i></div>
              <p>Alfa</p>
              <h3><?php echo e(($jumlah_user - ($jumlah_masuk + $jumlah_izin_telat + $jumlah_izin_pulang_cepat + $jumlah_libur + $jumlah_cuti + $jumlah_izin_masuk + $jumlah_sakit))); ?></h3>
            </div>
          </div>
        </div>
        <div class="col-xl-2 col-lg-4 col-sm-4 des-xsm-50 box-col-33">
          <div class="card investment-sec">
            <div class="animated-bg"><i></i><i></i><i></i></div>
            <div class="card-body">
              <div class="icon"><i data-feather="clipboard"></i></div>
              <p>Libur</p>
              <h3><?php echo e($jumlah_libur); ?></h3>
            </div>
          </div>
        </div>
        <div class="col-xl-2 col-lg-4 col-sm-4 des-xsm-50 box-col-33">
          <div class="card investment-sec">
            <div class="animated-bg"><i></i><i></i><i></i></div>
            <div class="card-body">
              <div class="icon"><i data-feather="file-text"></i></div>
              <p>Lembur</p>
              <h3><?php echo e($jumlah_karyawan_lembur); ?></h3>
            </div>
          </div>
        </div>
        <div class="col-xl-2 col-lg-4 col-sm-4 des-xsm-50 box-col-33">
          <div class="card investment-sec">
            <div class="animated-bg"><i></i><i></i><i></i></div>
            <div class="card-body">
              <div class="icon"><i data-feather="credit-card"></i></div>
              <p>Cuti</p>
              <h3><?php echo e($jumlah_cuti); ?></h3>
            </div>
          </div>
        </div>
        <div class="col-xl-2 col-lg-4 col-sm-4 des-xsm-50 box-col-33">
          <div class="card investment-sec">
            <div class="animated-bg"><i></i><i></i><i></i></div>
            <div class="card-body">
              <div class="icon"><i data-feather="credit-card"></i></div>
              <p>Sakit</p>
              <h3><?php echo e($jumlah_sakit); ?></h3>
            </div>
          </div>
        </div>
        <div class="col-xl-2 col-lg-4 col-sm-4 des-xsm-50 box-col-33">
          <div class="card investment-sec">
            <div class="animated-bg"><i></i><i></i><i></i></div>
            <div class="card-body">
              <div class="icon"><i data-feather="umbrella"></i></div>
              <p>Izin</p>
              <h3><?php echo e($jumlah_cuti); ?></h3>
            </div>
          </div>
        </div>
        <div class="col-xl-2 col-lg-4 col-sm-4 des-xsm-50 box-col-33">
          <div class="card investment-sec">
            <div class="animated-bg"><i></i><i></i><i></i></div>
            <div class="card-body">
              <div class="icon"><i data-feather="droplet"></i></div>
              <p>Izin Telat</p>
              <h3><?php echo e($jumlah_izin_telat); ?></h3>
            </div>
          </div>
        </div>
        <div class="col-xl-2 col-lg-4 col-sm-4 des-xsm-50 box-col-33">
          <div class="card investment-sec">
            <div class="animated-bg"><i></i><i></i><i></i></div>
            <div class="card-body">
              <div class="icon"><i data-feather="navigation"></i></div>
              <p>Izin Pulang Cepat</p>
              <h3><?php echo e($jumlah_izin_pulang_cepat); ?></h3>
            </div>
          </div>
        </div>

        <div class="col-xl-2 col-lg-4 col-sm-4 des-xsm-50 box-col-33">
          <div class="card investment-sec">
            <div class="animated-bg"><i></i><i></i><i></i></div>
            <div class="card-body">
              <div class="icon"><i data-feather="dollar-sign"></i></div>
              <p>Payroll <?php echo e(date('F')); ?> <?php echo e(date('Y')); ?></p>
              <h3>Rp <?php echo e(number_format($payroll)); ?></h3>
            </div>
          </div>
        </div>

        <div class="col-xl-2 col-lg-4 col-sm-4 des-xsm-50 box-col-33">
          <div class="card investment-sec">
            <div class="animated-bg"><i></i><i></i><i></i></div>
            <div class="card-body">
              <div class="icon"><i data-feather="git-commit"></i></div>
              <p>Kasbon <?php echo e(date('F')); ?> <?php echo e(date('Y')); ?></p>
              <h3>Rp <?php echo e(number_format($kasbon)); ?></h3>
            </div>
          </div>
        </div>

        <div class="col-xl-2 col-lg-4 col-sm-4 des-xsm-50 box-col-33">
          <div class="card investment-sec">
            <div class="animated-bg"><i></i><i></i><i></i></div>
            <div class="card-body">
              <div class="icon"><i data-feather="pocket"></i></div>
              <p>Reimbursement <?php echo e(date('F')); ?> <?php echo e(date('Y')); ?></p>
              <h3>Rp <?php echo e(number_format($reimbursement)); ?></h3>
            </div>
          </div>
        </div>


      </div>
    </div>
    <div class="col-xl-12 container-fluid calendar-basic">
      <div class="card">
        <div class="card-body">
          <div class="row" id="wrap">
            <div class="col-xxl-12 col-xl-12 box-col-70">
              <div id="external-events mb-4">
                <div id="external-events-list">
                </div>
              </div>
              <div class="calendar-default" id="calendar-container">
                <div id="calendar"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php $__env->startPush('script'); ?>
      <script>
        document.addEventListener("DOMContentLoaded", function () {
            var date = new Date();
            var d    = date.getDate();
            m    = date.getMonth();
            y    = date.getFullYear();

            var containerEl = document.getElementById("external-events-list");
            new FullCalendar.Draggable(containerEl, {
                itemSelector: ".fc-event",
                eventData: function (eventEl) {
                    return {
                        title: eventEl.innerText.trim(),
                    };
                },
            });

            var calendarEl = document.getElementById("calendar");
            var calendar = new FullCalendar.Calendar(calendarEl, {
                headerToolbar: {
                    left: "prev,next today",
                    center: "title",
                    right: "dayGridMonth,timeGridWeek,timeGridDay,listWeek",
                },
                initialView: "dayGridMonth",
                navLinks: true, // can click day/week names to navigate views
                editable: true,
                selectable: true,
                nowIndicator: true,
                // dayMaxEvents: true, // allow "more" link when too many events
                events: [
                  <?php
                    $tahun_skrg = date('Y');
                    $bulan_skrg = date('m');
                    $jmlh_bulan = cal_days_in_month(CAL_GREGORIAN,$bulan_skrg,$tahun_skrg);
                    $tgl_mulai = date('1945-01-01');
                    $tgl_akhir = date('Y-m-'.$jmlh_bulan);
                    $data_user = App\Models\User::select('name', 'tgl_lahir')->whereBetween('tgl_lahir', [$tgl_mulai, $tgl_akhir])->get();
                    $data_sakit = App\Models\MappingShift::where('status_absen', 'Sakit')->whereBetween('tanggal', [$tgl_mulai, $tgl_akhir])->get();
                    $data_cuti = App\Models\MappingShift::where('status_absen', 'Cuti')->whereBetween('tanggal', [$tgl_mulai, $tgl_akhir])->get();
                    $data_izin_masuk = App\Models\MappingShift::where('status_absen', 'Izin Masuk')->whereBetween('tanggal', [$tgl_mulai, $tgl_akhir])->get();
                    $data_izin_telat = App\Models\MappingShift::where('status_absen', 'Izin Telat')->whereBetween('tanggal', [$tgl_mulai, $tgl_akhir])->get();
                    $data_izin_pulang_cepat = App\Models\MappingShift::where('status_absen', 'Izin Pulang Cepat')->whereBetween('tanggal', [$tgl_mulai, $tgl_akhir])->get();
                  ?>
                  <?php $__currentLoopData = $data_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $du): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                      $pecah = explode("-", $du->tgl_lahir)
                    ?>
                    {
                      title          : 'Ulang Tahun: <?php echo e($du->name); ?>',
                      start          : new Date(y, <?php echo e($pecah[1]-1); ?>, <?php echo e($pecah[2]); ?>),
                      allDay         : true
                    },
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php $__currentLoopData = $data_sakit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                      $pecah2 = explode("-", $ds->tanggal)
                    ?>
                    {
                      title          : 'Sakit: <?php echo e($ds->User->name); ?>',
                      start          : new Date(<?php echo e($pecah2[0]); ?>, <?php echo e($pecah2[1]-1); ?>, <?php echo e($pecah2[2]); ?>),
                      allDay         : true
                    },
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php $__currentLoopData = $data_cuti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                      $pecah3 = explode("-", $dc->tanggal)
                    ?>
                    {
                      title          : 'Cuti: <?php echo e($dc->User->name); ?>',
                      start          : new Date(<?php echo e($pecah3[0]); ?>, <?php echo e($pecah3[1]-1); ?>, <?php echo e($pecah3[2]); ?>),
                      allDay         : true
                    },
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php $__currentLoopData = $data_izin_masuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                      $pecah4 = explode("-", $dim->tanggal)
                    ?>
                    {
                      title          : 'Izin Masuk: <?php echo e($dim->User->name); ?>',
                      start          : new Date(<?php echo e($pecah4[0]); ?>, <?php echo e($pecah4[1]-1); ?>, <?php echo e($pecah4[2]); ?>),
                      allDay         : true
                    },
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php $__currentLoopData = $data_izin_telat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                      $pecah5 = explode("-", $dit->tanggal)
                    ?>
                    {
                      title          : 'Izin Telat: <?php echo e($dit->User->name); ?>',
                      start          : new Date(<?php echo e($pecah5[0]); ?>, <?php echo e($pecah5[1]-1); ?>, <?php echo e($pecah5[2]); ?>),
                      allDay         : true
                    },
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php $__currentLoopData = $data_izin_pulang_cepat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dipc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                      $pecah6 = explode("-", $dipc->tanggal)
                    ?>
                    {
                      title          : 'Izin Pulang Cepat: <?php echo e($dipc->User->name); ?>',
                      start          : new Date(<?php echo e($pecah6[0]); ?>, <?php echo e($pecah6[1]-1); ?>, <?php echo e($pecah6[2]); ?>),
                      allDay         : true
                    },
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
                editable: true,
                droppable: true,
                drop: function (arg) {
                    if (document.getElementById("drop-remove").checked) {
                        arg.draggedEl.parentNode.removeChild(arg.draggedEl);
                    }
                },
            });
            calendar.render();
        });
      </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\absensi\resources\views/dashboard/index.blade.php ENDPATH**/ ?>