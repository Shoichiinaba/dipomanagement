<?php $__env->startSection('isi'); ?>
    <div class="row">
        <div class="col-md-5">
            <div class="card">
                <form method="post" action="<?php echo e(url('/lokasi-kantor/update/'.$lokasi->id)); ?>" class="p-4">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="nama_lokasi">Nama Lokasi</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nama_lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_lokasi" name="nama_lokasi" autofocus value="<?php echo e(old('nama_lokasi', $lokasi->nama_lokasi)); ?>">
                            <?php $__errorArgs = ['nama_lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="lat_kantor">Latitude Kantor</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['lat_kantor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lat_kantor" name="lat_kantor" autofocus value="<?php echo e(old('lat_kantor', $lokasi->lat_kantor)); ?>">
                            <?php $__errorArgs = ['lat_kantor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="long_kantor">Longitude Kantor</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['long_kantor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="long_kantor" name="long_kantor" autofocus value="<?php echo e(old('long_kantor', $lokasi->long_kantor)); ?>">
                            <?php $__errorArgs = ['long_kantor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="keterangan">Keterangan</label>
                            <select name="keterangan" id="keterangan" class="form-control <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> selectpicker" data-live-search="true">
                                <option value="">-- Pilih Keterangan --</option>
                                <option value="Office" <?php echo e('Office' == old('keterangan', $lokasi->keterangan) ? 'selected="selected"' : ''); ?>>Office</option>
                                <option value="Patroli" <?php echo e('Patroli' == old('keterangan', $lokasi->keterangan) ? 'selected="selected"' : ''); ?>>Patroli</option>
                            </select>
                            <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <button type="submit" class="btn btn-primary float-right">Submit</button>
                </form>
                <br>
            </div>
        </div>
        <div class="col-md-2">
            <center>
                <h1 style="color: white">Or</h1>
            </center>
        </div>
        <div class="col-md-5">
            <div class="card">
                <form method="post" action="<?php echo e(url('/lokasi-kantor/update/'.$lokasi->id)); ?>" class="p-4">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                        <input type="hidden" name="nama_lokasi" value="<?php echo e($lokasi->nama_lokasi); ?>">
                        <input type="hidden" name="keterangan" value="<?php echo e($lokasi->keterangan); ?>">
                        <input type="hidden" name="lat_kantor" id="lat">
                        <input type="hidden" name="long_kantor" id="long">
                        <center>
                            <button type="submit" class="btn btn-success"><i class="fa fa-map-marker-alt me-2"></i> Ambil Lokasi Saat Ini</button>
                        </center>
                </form>
            </div>
            <div class="card">
                <form method="post" action="<?php echo e(url('/lokasi-kantor/radius/'.$lokasi->id)); ?>" class="p-4">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="radius" class="float-start">Radius (Meter)</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['radius'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="radius" name="radius" autofocus value="<?php echo e(old('radius', $lokasi->radius)); ?>">
                            <?php $__errorArgs = ['radius'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <button type="submit" class="btn btn-primary float-end">Submit</button>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\absensi\resources\views/lokasi/edit.blade.php ENDPATH**/ ?>