<?php $__env->startSection('isi'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <form method="post" action="<?php echo e(url('/payroll/'.$data->id.'/update')); ?>" enctype="multipart/form-data" class="p-4">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col mb-4">
                            <label for="pegawai">Pegawai</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['pegawai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pegawai" name="pegawai" value="<?php echo e(old('pegawai', $data->user->name ?? '')); ?>" readonly>
                            <?php $__errorArgs = ['pegawai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="hidden" name="user_id" value="<?php echo e($data->id); ?>">
                        </div>
                        <?php
                            $bulan = array(
                            [
                                "id" => "1",
                                "bulan" => "Januari"
                            ],
                            [
                                "id" => "2",
                                "bulan" => "Februari"
                            ],
                            [
                                "id" => "3",
                                "bulan" => "Maret"
                            ],
                            [
                                "id" => "4",
                                "bulan" => "April"
                            ],
                            [
                                "id" => "5",
                                "bulan" => "Mei"
                            ],
                            [
                                "id" => "6",
                                "bulan" => "Juni"
                            ],
                            [
                                "id" => "7",
                                "bulan" => "Juli"
                            ],
                            [
                                "id" => "8",
                                "bulan" => "Agustus"
                            ],
                            [
                                "id" => "9",
                                "bulan" => "September"
                            ],
                            [
                                "id" => "10",
                                "bulan" => "Oktober"
                            ],
                            [
                                "id" => "11",
                                "bulan" => "November"
                            ],
                            [
                                "id" => "12",
                                "bulan" => "Desember"
                            ]);
                        ?>
                        <div class="col mb-4">
                            <label for="bulan">Bulan</label>
                            <select name="bulan" id="bulan" class="form-control <?php $__errorArgs = ['bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> selectpicker" data-live-search="true">
                                <option value="">Pilih Bulan</option>
                                <?php $__currentLoopData = $bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(old('bulan', $data->bulan) == $bu['id']): ?>
                                        <option value="<?php echo e($bu['id']); ?>" selected><?php echo e($bu['bulan']); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($bu['id']); ?>"><?php echo e($bu['bulan']); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row">
                        <?php
                            $last = date('Y')-10;
                            $now = date('Y');
                        ?>
                        <div class="col mb-4">
                            <label for="tahun">Tahun</label>
                            <select name="tahun" id="tahun" class="form-control <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> selectpicker" data-live-search="true">
                                <option value="">Pilih Tahun</option>
                                <?php for($i = $now; $i >= $last; $i--): ?>
                                    <?php if(old('tahun', $data->tahun) == $i): ?>
                                        <option value="<?php echo e($i); ?>" selected><?php echo e($i); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </select>
                            <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col mb-4">
                            <label for="persentase_kehadiran">Persentase Kehadiran</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['persentase_kehadiran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="persentase_kehadiran" name="persentase_kehadiran" value="<?php echo e(old('persentase_kehadiran', $data->persentase_kehadiran)); ?>" readonly>
                            <?php $__errorArgs = ['persentase_kehadiran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col mb-4">
                            <label for="jabatan">Jabatan</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jabatan" name="jabatan" value="<?php echo e(old('jabatan', $data->user->Jabatan->nama_jabatan ?? '')); ?>" readonly>
                            <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col mb-4">
                            <label for="no_gaji">Nomor Gaji</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['no_gaji'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="no_gaji" name="no_gaji" value="<?php echo e(old('no_gaji', $data->no_gaji)); ?>" readonly>
                            <?php $__errorArgs = ['no_gaji'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col mb-4">
                            <label for="tanggal_mulai">Tanggal Mulai</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['tanggal_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tanggal_mulai" name="tanggal_mulai" value="<?php echo e(old('tanggal_mulai', $data->tanggal_mulai)); ?>" readonly>
                            <?php $__errorArgs = ['tanggal_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col mb-4">
                            <label for="tanggal_akhir">Tanggal Akhir</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['tanggal_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tanggal_akhir" name="tanggal_akhir" value="<?php echo e(old('tanggal_akhir', $data->tanggal_akhir)); ?>" readonly>
                            <?php $__errorArgs = ['tanggal_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col mb-4">
                            <label for="gaji_pokok">Gaji Pokok</label>
                            <input type="text" class="form-control money <?php $__errorArgs = ['gaji_pokok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="gaji_pokok" name="gaji_pokok" value="<?php echo e(old('gaji_pokok', $data->gaji_pokok)); ?>">
                            <?php $__errorArgs = ['gaji_pokok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col mb-4">
                            <label for="uang_transport">Uang Transport</label>
                            <input type="text" class="form-control money <?php $__errorArgs = ['uang_transport'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="uang_transport" name="uang_transport" value="<?php echo e(old('uang_transport', $data->uang_transport)); ?>">
                            <?php $__errorArgs = ['uang_transport'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col mb-4">
                            <div class="card p-4">
                                <label for="total_reimbursement">Reimbursement</label>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control money <?php $__errorArgs = ['total_reimbursement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="total_reimbursement" value="<?php echo e(old('total_reimbursement', $data->total_reimbursement)); ?>" id="total_reimbursement" style="background-color: orange">
                                    <div class="input-group-text">
                                        <span>Total Reimbursement</span>
                                    </div>
                                    <?php $__errorArgs = ['total_reimbursement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4">
                            <div class="card p-4">
                                <label for="jumlah_mangkir">Mangkir</label>
                                <div class="input-group mb-3">
                                    <input type="number" class="form-control <?php $__errorArgs = ['jumlah_mangkir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jumlah_mangkir" value="<?php echo e(old('jumlah_mangkir', $data->jumlah_mangkir)); ?>" id="jumlah_mangkir" style="background-color: orange">
                                    <div class="input-group-text">
                                        <span>/ Kali</span>
                                    </div>
                                    <?php $__errorArgs = ['jumlah_mangkir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control money <?php $__errorArgs = ['uang_mangkir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="uang_mangkir" name="uang_mangkir" value="<?php echo e(old('uang_mangkir', $data->uang_mangkir)); ?>">
                                    <div class="input-group-text">
                                        <span>Uang Mangkir</span>
                                    </div>
                                    <?php $__errorArgs = ['uang_mangkir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <input type="hidden" name="total_mangkir" id="total_mangkir" value="<?php echo e(old('total_mangkir', $data->total_mangkir)); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                         <div class="col mb-4">
                            <div class="card p-4">
                                <label for="jumlah_lembur">Lembur</label>
                                <div class="input-group mb-3">
                                    <input type="number" class="form-control <?php $__errorArgs = ['jumlah_lembur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jumlah_lembur" value="<?php echo e(old('jumlah_lembur', $data->jumlah_lembur)); ?>" id="jumlah_lembur" style="background-color: orange">
                                    <div class="input-group-text">
                                        <span>/ Jam</span>
                                    </div>
                                    <?php $__errorArgs = ['jumlah_lembur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control money <?php $__errorArgs = ['uang_lembur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="uang_lembur" name="uang_lembur" value="<?php echo e(old('uang_lembur', $data->uang_lembur)); ?>">
                                    <div class="input-group-text">
                                        <span>Uang Lembur</span>
                                    </div>
                                    <?php $__errorArgs = ['uang_lembur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <input type="hidden" name="total_lembur" id="total_lembur" value="<?php echo e(old('total_lembur', $data->total_lembur)); ?>">
                            </div>
                        </div>
                        <div class="col mb-4">
                            <div class="card p-4">
                                <label for="jumlah_izin">Izin Masuk</label>
                                <div class="input-group mb-3">
                                    <input type="number" class="form-control <?php $__errorArgs = ['jumlah_izin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jumlah_izin" value="<?php echo e(old('jumlah_izin', $data->jumlah_izin)); ?>" id="jumlah_izin" style="background-color: orange">
                                    <div class="input-group-text">
                                        <span>/ Kali</span>
                                    </div>
                                    <?php $__errorArgs = ['jumlah_izin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control money <?php $__errorArgs = ['uang_izin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="uang_izin" name="uang_izin" value="<?php echo e(old('uang_izin', $data->uang_izin)); ?>">
                                    <div class="input-group-text">
                                        <span>Uang Izin</span>
                                    </div>
                                    <?php $__errorArgs = ['izin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <input type="hidden" name="total_izin" id="total_izin" value="<?php echo e(old('total_izin', $data->total_izin)); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                         <div class="col mb-4">
                            <div class="card p-4">
                                <label for="bonus_pribadi">Bonus</label>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control money <?php $__errorArgs = ['bonus_pribadi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="bonus_pribadi" style="background-color: orange" name="bonus_pribadi" value="<?php echo e(old('bonus_pribadi', $data->bonus_pribadi)); ?>">
                                    <div class="input-group-text">
                                        <span>Bonus Pribadi</span>
                                    </div>
                                    <?php $__errorArgs = ['bonus_pribadi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control money <?php $__errorArgs = ['bonus_team'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="bonus_team" name="bonus_team" style="background-color: orange" value="<?php echo e(old('bonus_team', $data->bonus_team)); ?>">
                                    <div class="input-group-text">
                                        <span>Bonus Team</span>
                                    </div>
                                    <?php $__errorArgs = ['bonus_team'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control money <?php $__errorArgs = ['bonus_jackpot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="bonus_jackpot" style="background-color: orange" name="bonus_jackpot" value="<?php echo e(old('bonus_jackpot', $data->bonus_jackpot)); ?>">
                                    <div class="input-group-text">
                                        <span>Bonus Jackpot</span>
                                    </div>
                                    <?php $__errorArgs = ['bonus_jackpot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4">
                            <div class="card p-4">
                                <label for="jumlah_terlambat">Terlambat</label>
                                <div class="input-group mb-3">
                                    <input type="number" class="form-control <?php $__errorArgs = ['jumlah_terlambat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jumlah_terlambat" value="<?php echo e(old('jumlah_terlambat', $data->jumlah_terlambat)); ?>" id="jumlah_terlambat" style="background-color: orange">
                                    <div class="input-group-text">
                                        <span>/ Kali</span>
                                    </div>
                                    <?php $__errorArgs = ['jumlah_terlambat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control money <?php $__errorArgs = ['uang_terlambat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="uang_terlambat" name="uang_terlambat" value="<?php echo e(old('uang_terlambat', $data->uang_terlambat)); ?>">
                                    <div class="input-group-text">
                                        <span>Uang Terlambat</span>
                                    </div>
                                    <?php $__errorArgs = ['uang_terlambat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <input type="hidden" name="total_terlambat" id="total_terlambat" value="<?php echo e(old('total_terlambat', $data->total_terlambat)); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                         <div class="col mb-4">
                            <div class="card p-4">
                                <label for="jumlah_kehadiran">100% Kehadiran</label>
                                <div class="input-group mb-3">
                                    <input type="number" class="form-control <?php $__errorArgs = ['jumlah_kehadiran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jumlah_kehadiran" value="<?php echo e(old('jumlah_kehadiran', $data->jumlah_kehadiran)); ?>" id="jumlah_kehadiran" style="background-color: orange">
                                    <div class="input-group-text">
                                        <span>/ Kali</span>
                                    </div>
                                    <?php $__errorArgs = ['jumlah_kehadiran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control money <?php $__errorArgs = ['uang_kehadiran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="uang_kehadiran" name="uang_kehadiran" value="<?php echo e(old('uang_kehadiran', $data->uang_kehadiran)); ?>">
                                    <div class="input-group-text">
                                        <span>Uang 100% Kehadiran</span>
                                    </div>
                                    <?php $__errorArgs = ['uang_kehadiran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <input type="hidden" name="total_kehadiran" id="total_kehadiran" value="<?php echo e(old('total_kehadiran', $data->total_kehadiran)); ?>">
                            </div>
                        </div>
                        <div class="col mb-4">
                            <div class="card p-4">
                                <label for="saldo_kasbon">Kasbon</label>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control money <?php $__errorArgs = ['saldo_kasbon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="saldo_kasbon" value="<?php echo e(old('saldo_kasbon', $data->saldo_kasbon)); ?>" id="saldo_kasbon" style="background-color: orange" readonly>
                                    <div class="input-group-text">
                                        <span>Total Kasbon</span>
                                    </div>
                                    <?php $__errorArgs = ['saldo_kasbon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control money <?php $__errorArgs = ['bayar_kasbon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="bayar_kasbon" name="bayar_kasbon" value="<?php echo e(old('bayar_kasbon', $data->bayar_kasbon)); ?>">
                                    <div class="input-group-text">
                                        <span>Bayar Kasbon</span>
                                    </div>
                                    <?php $__errorArgs = ['bayar_kasbon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                         <div class="col mb-4">
                            <div class="card p-4">
                                <label for="jumlah_thr">Tunjangan Hari Raya</label>
                                <div class="input-group mb-3">
                                    <input type="number" class="form-control <?php $__errorArgs = ['jumlah_thr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jumlah_thr" value="<?php echo e(old('jumlah_thr', $data->jumlah_thr)); ?>" id="jumlah_thr" style="background-color: orange">
                                    <div class="input-group-text">
                                        <span>/ Kali</span>
                                    </div>
                                    <?php $__errorArgs = ['jumlah_thr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control money <?php $__errorArgs = ['uang_thr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="uang_thr" name="uang_thr" value="<?php echo e(old('uang_thr', $data->uang_thr)); ?>">
                                    <div class="input-group-text">
                                        <span>Uang THR</span>
                                    </div>
                                    <?php $__errorArgs = ['uang_thr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <input type="hidden" name="total_thr" id="total_thr" value="<?php echo e(old('total_thr', $data->total_thr)); ?>">
                            </div>
                        </div>
                        <div class="col mb-4">
                            <label for="loss">Loss</label>
                            <input type="text" class="form-control money <?php $__errorArgs = ['loss'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="loss" name="loss" value="<?php echo e(old('loss', $data->loss)); ?>">
                            <?php $__errorArgs = ['loss'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <button class="btn form-control btn-secondary mt-3 mb-3" id="proses">Proses</button>
                            <button type="submit" class="btn form-control btn-primary mt-3 mb-3" id="submit" disabled>Simpan</button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col mb-4">
                            <div class="card p-4">
                                <center>
                                    <label style="color:green">TOTAL PENJUMLAHAN</label>
                                    <input type="text" class="form-control border-white text-center money <?php $__errorArgs = ['total_penjumlahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="total_penjumlahan" name="total_penjumlahan" value="<?php echo e(old('total_penjumlahan', $data->total_penjumlahan)); ?>" readonly style="background-color: white; color:black">
                                </center>
                            </div>
                        </div>
                        <div class="col mb-4">
                            <div class="card p-4">
                                <center>
                                    <label style="color:red">TOTAL PENGURANGAN</label>
                                    <input type="text" class="form-control border-white text-center money <?php $__errorArgs = ['total_pengurangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="total_pengurangan" name="total_pengurangan" value="<?php echo e(old('total_pengurangan', $data->total_pengurangan)); ?>" readonly style="background-color: white; color:black">
                                </center>
                            </div>
                        </div>
                    </div>
                    <center>
                        <div class="col">
                            <div class="card p-4">
                                <label style="color:blue">GRAND TOTAL</label>
                                <input type="text" class="form-control border-white text-center money <?php $__errorArgs = ['grand_total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="grand_total" name="grand_total" value="<?php echo e(old('grand_total', $data->grand_total)); ?>" readonly style="background-color: white; color:black">
                            </div>
                        </div>
                    </center>
                  </form>
            </div>
        </div>
    </div>
    <?php $__env->startPush('script'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script type="text/javascript">
            function replaceCurrency(n) {
                if (n) {
                    return n.replace(/\,/g, '');
                }
            }
        </script>
        <script>
            $(document).ready(function(){
                $('.money').mask('000,000,000,000,000', {
                    reverse: true
                });

                $("#proses").click(function(e) {
                    e.preventDefault();

                    //Penambahan Gaji
                    var gaji_pokok = $('#gaji_pokok').val() ? parseFloat(replaceCurrency($('#gaji_pokok').val())) : 0;
                    var total_reimbursement = $('#total_reimbursement').val() ? parseFloat(replaceCurrency($('#total_reimbursement').val())) : 0;
                    var uang_transport = $('#uang_transport').val() ? parseFloat(replaceCurrency($('#uang_transport').val())) : 0;

                    var jumlah_lembur = $('#jumlah_lembur').val() ? parseFloat($('#jumlah_lembur').val()) : 0;
                    var uang_lembur = $('#uang_lembur').val() ? parseFloat(replaceCurrency($('#uang_lembur').val())) : 0;
                    var total_lembur = jumlah_lembur * uang_lembur;
                    $('#total_lembur').val(accounting.formatMoney(total_lembur, '', 0, ",", "."));

                    var bonus_pribadi = $('#bonus_pribadi').val() ? parseFloat(replaceCurrency($('#bonus_pribadi').val())) : 0;
                    var bonus_team = $('#bonus_team').val() ? parseFloat(replaceCurrency($('#bonus_team').val())) : 0;
                    var bonus_jackpot = $('#bonus_jackpot').val() ? parseFloat(replaceCurrency($('#bonus_jackpot').val())) : 0;

                    var jumlah_kehadiran = $('#jumlah_kehadiran').val() ? parseFloat($('#jumlah_kehadiran').val()) : 0;
                    var uang_kehadiran = $('#uang_kehadiran').val() ? parseFloat(replaceCurrency($('#uang_kehadiran').val())) : 0;
                    var total_kehadiran = jumlah_kehadiran * uang_kehadiran;
                    $('#total_kehadiran').val(accounting.formatMoney(total_kehadiran, '', 0, ",", "."));

                    var jumlah_thr = $('#jumlah_thr').val() ? parseFloat($('#jumlah_thr').val()) : 0;
                    var uang_thr = $('#uang_thr').val() ? parseFloat(replaceCurrency($('#uang_thr').val())) : 0;
                    var total_thr = jumlah_thr * uang_thr;
                    $('#total_thr').val(accounting.formatMoney(total_thr, '', 0, ",", "."));

                    var total_penjumlahan = gaji_pokok + total_reimbursement + uang_transport + total_lembur + bonus_pribadi + bonus_team + bonus_jackpot + total_kehadiran + total_thr;

                    $('#total_penjumlahan').val(accounting.formatMoney(total_penjumlahan, '', 0, ",", "."));

                    //Pengurangan Gaji
                    var jumlah_mangkir = $('#jumlah_mangkir').val() ? parseFloat($('#jumlah_mangkir').val()) : 0;
                    var uang_mangkir = $('#uang_mangkir').val() ? parseFloat(replaceCurrency($('#uang_mangkir').val())) : 0;
                    var total_mangkir = jumlah_mangkir * uang_mangkir;
                    $('#total_mangkir').val(accounting.formatMoney(total_mangkir, '', 0, ",", "."));

                    var jumlah_izin = $('#jumlah_izin').val() ? parseFloat($('#jumlah_izin').val()) : 0;
                    var uang_izin = $('#uang_izin').val() ? parseFloat(replaceCurrency($('#uang_izin').val())) : 0;
                    var total_izin = jumlah_izin * uang_izin;
                    $('#total_izin').val(accounting.formatMoney(total_izin, '', 0, ",", "."));

                    var jumlah_terlambat = $('#jumlah_terlambat').val() ? parseFloat($('#jumlah_terlambat').val()) : 0;
                    var uang_terlambat = $('#uang_terlambat').val() ? parseFloat(replaceCurrency($('#uang_terlambat').val())) : 0;
                    var total_terlambat = jumlah_terlambat * uang_terlambat;
                    $('#total_terlambat').val(accounting.formatMoney(total_terlambat, '', 0, ",", "."));

                    var bayar_kasbon = $('#bayar_kasbon').val() ? parseFloat(replaceCurrency($('#bayar_kasbon').val())) : 0;
                    var loss = $('#loss').val() ? parseFloat(replaceCurrency($('#loss').val())) : 0;

                    var total_pengurangan = total_mangkir + total_izin + total_terlambat + bayar_kasbon + loss;

                    $('#total_pengurangan').val(accounting.formatMoney(total_pengurangan, '', 0, ",", "."));

                    $("#submit").prop('disabled', false);

                    var grand_total = total_penjumlahan - total_pengurangan;
                    $('#grand_total').val(accounting.formatMoney(grand_total, '', 0, ",", "."));
                    Swal.fire('Berhasil Proses Data, Klik Simpan Untuk Melanjutkan', '', 'success');
                    setTimeout(function() {
                        Swal.close();
                    }, 2000);
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\absensi\resources\views/payroll/edit.blade.php ENDPATH**/ ?>