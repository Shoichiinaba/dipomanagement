<?php $__env->startSection('isi'); ?>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <a href="#" onclick="tambahUser()" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Data User</a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="tableprint" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Username</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $du): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($du->name); ?></td>
                                <td><?php echo e($du->email); ?></td>
                                <td><?php echo e($du->username); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/users/detail/'.$du->id)); ?>" class="btn btn-sm btn-info"><i class="fa fa-solid fa-eye"></i></a>
                                    <a href="<?php echo e(url('/users/edit-password/'.$du->id)); ?>" class="btn btn-sm btn-warning"><i class="fa fa-solid fa-key"></i></a>
                                    <a href="<?php echo e(url('/users/delete/'.$du->id)); ?>" class="btn btn-sm btn-danger"><i class="fa fas fa-exclamation-triangle"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
            </div>
            <!-- /.card-body -->
          </div>
    </div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ricky\resources\views/users/index.blade.php ENDPATH**/ ?>