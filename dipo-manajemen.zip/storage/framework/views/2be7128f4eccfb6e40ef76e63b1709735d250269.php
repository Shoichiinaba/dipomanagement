<?php $__env->startSection('container'); ?>
    <style>
        .row {
            display: flex;
            align-items: stretch;
        }

        .separator {
            width: 1px;
            background-color: #ccc;
            margin: 0 10px;
        }
    </style>
    <form class="tf-form" action="<?php echo e(url('/login-proses')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <h1><?php echo e($title); ?></h1>
        <div class="group-input">
            <label>Username</label>
            <input type="text" placeholder="Username" class="<?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('username')); ?>" name="username">
            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="group-input auth-pass-input last">
            <label>Password</label>
            <input type="password" class="password-input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" name="password">
            <a class="icon-eye password-addon" id="password-addon"></a>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback">
                  <?php echo e($message); ?>

              </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        

        <button type="submit" class="tf-btn accent large">Log In</button>
        <div class="mt-2 text-right"> <a href="<?php echo e(url('/forgot-password')); ?>">Forgot Password <i class="fa fa-key"></i></a></div>
    </form>
    <p class="mb-9 fw-3 text-center ">Don't have an Account? <a href="<?php echo e(url('/register')); ?>" class="auth-link-rg" >Sign up</a></p>
    <div class="row">
        <div class="col">
            <div class="auth-line">Face Recognition</div>
            <ul class="bottom socials-login mb-4">
                <li><a href="<?php echo e(url('/presensi')); ?>">Absen Masuk</a></li>
                <li><a href="<?php echo e(url('/presensi-pulang')); ?>">Absen Pulang</a></li>
            </ul>
        </div>
        <div class="separator"></div>
        <div class="col">
            <div class="auth-line">Qr Code</div>
            <ul class="bottom socials-login mb-4">
                <li><a href="<?php echo e(url('/qr-masuk')); ?>">Absen Masuk</a></li>
                <li><a href="<?php echo e(url('/qr-pulang')); ?>">Absen Pulang</a></li>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\absensi\resources\views/auth/login.blade.php ENDPATH**/ ?>