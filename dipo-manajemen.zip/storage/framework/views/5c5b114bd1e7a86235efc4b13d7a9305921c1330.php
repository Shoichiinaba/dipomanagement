<?php echo e($slot); ?>

<?php /**PATH /home/t46813/gpiclick.grhapermataibu.com/gpiclick/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>