<?php $__env->startSection('container'); ?>
    <div class="card-secton transfer-section">
        <div class="tf-container">
            <div class="tf-balance-box">
                    <form method="post" class="tf-form p-2" action="<?php echo e(url('/reimbursement/update/'.$reimbursement->id)); ?>" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="group-input">
                            <label for="pegawai">Nama Pegawai</label>
                            <input type="text" class="<?php $__errorArgs = ['pegawai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pegawai" name="pegawai" value="<?php echo e(old('pegawai', $reimbursement->user->name ?? '')); ?>" readonly>
                            <input type="hidden" name="user_id" id="user_id" value="<?php echo e($reimbursement->user_id); ?>">
                        </div>
                        <div class="group-input">
                            <label for="tanggal">Tanggal</label>
                            <input type="datetime" class="<?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tanggal" name="tanggal" value="<?php echo e(old('tanggal', $reimbursement->tanggal)); ?>">
                            <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="group-input">
                            <label for="event">event</label>
                            <textarea name="event" id="event" class="<?php $__errorArgs = ['event'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('event', $reimbursement->event)); ?></textarea>
                            <?php $__errorArgs = ['event'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="group-input">
                            <label for="kategori_id" style="z-index: 1000">Kategori</label>
                            <select class="select2 <?php $__errorArgs = ['kategori_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kategori_id" name="kategori_id" data-live-search="true">
                                <option value="">Pilih Kategori</option>
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(old('kategori_id', $reimbursement->kategori_id) == $kat->id): ?>
                                        <option value="<?php echo e($kat->id); ?>" selected><?php echo e($kat->name); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($kat->id); ?>"><?php echo e($kat->name); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['kategori_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="group-input">
                            <label for="jumlah">Jumlah</label>
                            <input type="text" class="money <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah" name="jumlah" value="<?php echo e(old('jumlah', $reimbursement->jumlah)); ?>">
                            <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="group-input">
                            <label for="qty">Qty</label>
                            <input type="number" class="money <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="qty" name="qty" value="<?php echo e(old('qty', $reimbursement->qty)); ?>">
                            <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="group-input">
                            <label for="total">Total</label>
                            <input type="text" readonly class="money <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="total" name="total" value="<?php echo e(old('total', $reimbursement->total)); ?>">
                            <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="table-responsive mb-4">
                            <table id="tablemultiple" class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <th>Fee</th>
                                        <th class="text-center">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $old = session()->getOldInput();
                                    ?>
                                    <?php if(isset($old['user_id_item'])): ?>
                                        <?php $__currentLoopData = $old['user_id_item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detailName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr id="multiple<?php echo e($key); ?>">
                                                <td>
                                                    <select style="width: 130px" class="user_id_item" name="user_id_item[]">
                                                        <option value="">-- Pilih --</option>
                                                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(old('user_id_item')[$key] == $us->id): ?>
                                                                <option value="<?php echo e($us->id); ?>" selected><?php echo e($us->name); ?></option>
                                                            <?php else: ?>
                                                                <option value="<?php echo e($us->id); ?>"><?php echo e($us->name); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td>
                                                    <input type="text" class="money fee" id="fee" name="fee[]" value="<?php echo e(old('fee')[$key]); ?>">
                                                    <?php $__errorArgs = ['fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback">
                                                            <?php echo e($message); ?>

                                                        </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </td>
                                                <td class="text-center">
                                                    <a class="btn btn-sm btn-danger delete"><i class="fa fa-trash"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $reimbursement->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr id="multiple<?php echo e($key); ?>">
                                                <td>
                                                    <select style="width: 130px" class="user_id_item" name="user_id_item[]">
                                                        <option value="">-- Pilih --</option>
                                                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($item->user_id == $us->id): ?>
                                                                <option value="<?php echo e($us->id); ?>" selected><?php echo e($us->name); ?></option>
                                                            <?php else: ?>
                                                                <option value="<?php echo e($us->id); ?>"><?php echo e($us->name); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td>
                                                    <input type="text" class="money fee" id="fee" name="fee[]" value="<?php echo e($item->fee); ?>">
                                                </td>
                                                <td class="text-center">
                                                    <a class="btn btn-sm btn-danger delete"><i class="fa fa-trash"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <a id="add_row" class="btn btn-sm btn-success float-end">+ Tambah</a>
                        </div>

                        <div class="group-input">
                            <label for="sisa">Sisa</label>
                            <input type="text" readonly class="money <?php $__errorArgs = ['sisa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="sisa" name="sisa" value="<?php echo e(old('sisa', $reimbursement->sisa)); ?>">
                            <?php $__errorArgs = ['sisa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="group-input">
                            <label for="status">status</label>
                            <input type="text" class="<?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status" name="status" value="<?php echo e(old('status', $reimbursement->status)); ?>">
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="group-input">
                            <input type="file" class="form-control <?php $__errorArgs = ['file_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="file_path" name="file_path" value="<?php echo e(old('file_path')); ?>">
                            <?php $__errorArgs = ['file_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <input type="hidden" name="kategori_name" id="kategori_name" value="<?php echo e(old('kategori_name', $reimbursement->kategori->name ?? '')); ?>">

                        <button type="submit" class="btn btn-primary float-right">Submit</button>
                    </form>
            </div>
        </div>
    </div>
    <br>
    <br>
    <br>
    <br>
    <?php $__env->startPush('script'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
        <script>
            function replaceCurrency(n) {
                if (n) {
                    return n.replace(/\,/g, '');
                }
            }
            $(document).ready(function(){
                $('.money').mask('000,000,000,000,000', {
                    reverse: true
                });

                $('#kategori_id').select2();
                $('.user_id_item').select2();

                var row_number = 1;
                var temp_row_number = row_number-1;
                $("#add_row").click(function(e) {
                    e.preventDefault();
                    var new_row_number = row_number - 1;
                    var table = document.getElementById("tablemultiple");
                    var tbodyRowCount = table.tBodies[0].rows.length;
                    $(".user_id_item").select2('destroy');
                    new_row = $('#tablemultiple tbody tr:last').clone();
                    new_row.find("input").val("").end();
                    new_row.find("select").val("").end();
                    $('#tablemultiple').append(new_row);
                    $('#tablemultiple tbody tr:last').attr('id','multiple'+(tbodyRowCount));
                    row_number++;
                    $('.user_id_item').select2();
                    temp_row_number = row_number - 1;
                });

                $('body').on('click', '.delete', function (event) {
                    var table = document.getElementById("tablemultiple");
                    var tbodyRowCount = table.tBodies[0].rows.length;
                    if (tbodyRowCount <= 1) {
                        alert('Cannot delete if only 1 row!');
                    } else {
                        if (confirm('Are you sure you want to delete?')) {
                            $(this).closest('tr').remove();
                            let total = $('#total').val() ? parseFloat(replaceCurrency($('#total').val())) : 0;
                            let sum_fee = 0;
                            $('.fee').each(function () {
                                sum_fee += $(this).closest('tr').find('td:eq(1) input').val() ?  parseFloat(replaceCurrency($(this).closest('tr').find('td:eq(1) input').val())) : 0;
                            });
                            $('#sisa').val(accounting.formatMoney(total - sum_fee, '', 0, ",", "."));
                        }
                    }
                });

                $('body').on('keyup click', '.fee', function (event) {
                    let total = $('#total').val() ? parseFloat(replaceCurrency($('#total').val())) : 0;
                    let sum_fee = 0;
                    $('.fee').each(function () {
                        sum_fee += $(this).closest('tr').find('td:eq(1) input').val() ?  parseFloat(replaceCurrency($(this).closest('tr').find('td:eq(1) input').val())) : 0;
                    });
                    $('#sisa').val(accounting.formatMoney(total - sum_fee, '', 0, ",", "."));
                });

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                let kategori_name = $('#kategori_name').val();
                if (kategori_name == 'Lain-lain') {
                    $("#jumlah").prop('readonly', false);
                } else {
                    $("#jumlah").prop('readonly', true);
                }


                $('#kategori_id').on('change', function(){
                    let kategori_id = $('#kategori_id').val();
                    $.ajax({
                        type : 'POST',
                        url : "<?php echo e(url('/reimbursement/getKategori')); ?>",
                        data :  {kategori_id:kategori_id},
                        cache : false,
                        success: function(data){
                            $('#kategori_name').val(data.name);
                            let qty = $('#qty').val() ? parseFloat($('#qty').val()) : 0;
                            let sum_fee = 0;
                            $('.fee').each(function () {
                                sum_fee += $(this).closest('tr').find('td:eq(1) input').val() ?  parseFloat(replaceCurrency($(this).closest('tr').find('td:eq(1) input').val())) : 0;
                            });
                            if (data.name == 'Lain-lain') {
                                $('#jumlah').val(accounting.formatMoney(0, '', 0, ",", "."));
                                $('#total').val(accounting.formatMoney(0, '', 0, ",", "."));
                                $('#sisa').val(accounting.formatMoney(0, '', 0, ",", "."));
                                $("#jumlah").prop('readonly', false);
                            } else {
                                let total = parseFloat(data.jumlah) * qty;
                                let sisa = total - sum_fee;
                                $('#jumlah').val(accounting.formatMoney(data.jumlah, '', 0, ",", "."));
                                $('#total').val(accounting.formatMoney(total, '', 0, ",", "."));
                                $("#jumlah").prop('readonly', true);
                                $('#sisa').val(accounting.formatMoney(sisa, '', 0, ",", "."));
                            }
                        },
                        error: function(data){
                            console.log('error:' ,data);
                        }
                    })
                })

                $('#jumlah').on('keyup', function(){
                    let jumlah = $('#jumlah').val() ? parseFloat(replaceCurrency($('#jumlah').val())) : 0;
                    let qty = $('#qty').val() ? parseFloat($('#qty').val()) : 0;
                    let total = jumlah * qty;
                    $('#total').val(accounting.formatMoney(total, '', 0, ",", "."));

                    let sum_fee = 0;
                    $('.fee').each(function () {
                        sum_fee += $(this).closest('tr').find('td:eq(1) input').val() ?  parseFloat(replaceCurrency($(this).closest('tr').find('td:eq(1) input').val())) : 0;
                    });
                    let sisa = total - sum_fee;
                    $('#sisa').val(accounting.formatMoney(sisa, '', 0, ",", "."));
                })

                $('#qty').on('keyup change', function(){
                    let jumlah = $('#jumlah').val() ? parseFloat(replaceCurrency($('#jumlah').val())) : 0;
                    let qty = $('#qty').val() ? parseFloat($('#qty').val()) : 0;
                    let total = jumlah * qty;
                    $('#total').val(accounting.formatMoney(total, '', 0, ",", "."));

                    let sum_fee = 0;
                    $('.fee').each(function () {
                        sum_fee += $(this).closest('tr').find('td:eq(1) input').val() ?  parseFloat(replaceCurrency($(this).closest('tr').find('td:eq(1) input').val())) : 0;
                    });
                    let sisa = total - sum_fee;
                    $('#sisa').val(accounting.formatMoney(sisa, '', 0, ",", "."));
                })
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\absensi\resources\views/reimbursement/editUser.blade.php ENDPATH**/ ?>