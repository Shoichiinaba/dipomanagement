<?php $__env->startSection('container'); ?>
    <div id="app-wrap" class="style1">
        <div class="tf-container">
            <form method="post" class="tf-form p-2" action="<?php echo e(url('/pengajuan-keuangan/store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="group-input">
                    <label for="pegawai">Nama Pegawai</label>
                    <input type="text" class="<?php $__errorArgs = ['pegawai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pegawai" name="pegawai" value="<?php echo e(old('pegawai', auth()->user()->name)); ?>" readonly>
                    <input type="hidden" name="user_id" id="user_id" value="<?php echo e(auth()->user()->id); ?>">
                </div>

                <div class="group-input">
                    <label for="nomor">Nomor Pengajuan</label>
                    <input type="text" class="<?php $__errorArgs = ['nomor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nomor" name="nomor" value="<?php echo e(old('nomor', $nomor)); ?>" readonly>
                </div>

                <div class="group-input">
                    <label for="tanggal">Tanggal</label>
                    <input type="datetime" class="<?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tanggal" name="tanggal" value="<?php echo e(old('tanggal', date('Y-m-d'))); ?>">
                    <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="table-responsive mb-4">
                    <table id="tablemultiple" class="table table-striped">
                        <thead>
                            <tr>
                                <th class="text-center" style="min-width: 200px; background-color:rgb(222, 222, 222)">Nama Item</th>
                                <th class="text-center" style="min-width: 100px; background-color:rgb(222, 222, 222)">Qty</th>
                                <th class="text-center" style="min-width: 200px; background-color:rgb(222, 222, 222)">Harga</th>
                                <th class="text-center" style="min-width: 200px; background-color:rgb(222, 222, 222)">Total</th>
                                <th class="text-center" style=" background-color:rgb(222, 222, 222)">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $old = session()->getOldInput();
                            ?>
                            <?php if(isset($old['nama'])): ?>
                                <?php $__currentLoopData = $old['nama']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detailName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="multiple<?php echo e($key); ?>">
                                        <td>
                                            <input type="text" class="nama" id="nama" name="nama[]" value="<?php echo e(old('nama')[$key]); ?>">
                                        </td>
                                        <td>
                                            <input type="number" step="0.01" class="qty" id="qty" name="qty[]" value="<?php echo e(old('qty')[$key]); ?>">
                                        </td>
                                        <td>
                                            <input type="text" class="money harga" id="harga" name="harga[]" value="<?php echo e(old('harga')[$key]); ?>">
                                        </td>
                                        <td>
                                            <input type="text" class="money total" id="total" name="total[]" value="<?php echo e(old('total')[$key]); ?>" readonly>
                                        </td>
                                        <td class="text-center">
                                            <a class="btn btn-sm btn-danger delete"><i class="fa fa-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr id="multiple0">
                                    <td>
                                        <input type="text" class="nama" id="nama" name="nama[]">
                                    </td>
                                    <td>
                                        <input type="number" step="0.01" class="qty" id="qty" name="qty[]">
                                    </td>
                                    <td>
                                        <input type="text" class="money harga" id="harga" name="harga[]">
                                    </td>
                                    <td>
                                        <input type="text" class="money total" id="total" name="total[]" readonly>
                                    </td>
                                    <td class="text-center">
                                        <a class="btn btn-sm btn-danger delete"><i class="fa fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <a id="add_row" class="btn btn-sm btn-success float-start mb-2">+ Tambah</a>
                </div>

                <div class="group-input">
                    <label for="total_harga">Total Pengajuan</label>
                    <input type="text" class="money <?php $__errorArgs = ['total_harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="total_harga" name="total_harga" value="<?php echo e(old('total_harga')); ?>" readonly>
                    <?php $__errorArgs = ['total_harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="group-input">
                    <label for="keterangan">Keterangan</label>
                    <textarea name="keterangan" id="keterangan" class="<?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('keterangan')); ?></textarea>
                    <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="group-input">
                    <input type="file" class="form-control <?php $__errorArgs = ['pk_file_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pk_file_path" name="pk_file_path" value="<?php echo e(old('pk_file_path')); ?>">
                    <?php $__errorArgs = ['pk_file_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit" class="btn btn-primary float-right">Submit</button>
            </form>
        </div>
    </div>
    <br>
    <br>
    <br>
    <?php $__env->startPush('script'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
        <script>
            function replaceCurrency(n) {
                if (n) {
                    return n.replace(/\,/g, '');
                }
            }

            $('.money').mask('000,000,000,000,000', {
                reverse: true
            });

            let row_number = 1;
            let temp_row_number = row_number-1;
            $("#add_row").click(function(e) {
                e.preventDefault();
                let new_row_number = row_number - 1;
                let table = document.getElementById("tablemultiple");
                let tbodyRowCount = table.tBodies[0].rows.length;
                new_row = $('#tablemultiple tbody tr:last').clone();
                new_row.find("input").val("").end();
                $('#tablemultiple').append(new_row);
                $('#tablemultiple tbody tr:last').attr('id','multiple'+(tbodyRowCount));
                row_number++;
                temp_row_number = row_number - 1;
            });

            $('body').on('keyup click', '.qty', function (event) {
                let qty =  $(this).closest('tr').find('td:eq(1) input').val() ?  parseFloat($(this).closest('tr').find('td:eq(1) input').val()) : 0;
                let harga =  $(this).closest('tr').find('td:eq(2) input').val() ?  parseFloat(replaceCurrency($(this).closest('tr').find('td:eq(2) input').val())) : 0;
                let total = qty * harga;
                $(this).closest('tr').find('td:eq(3) input').val(accounting.formatMoney(total, '', 0, ",", "."))

                let total_harga = 0;
                $('.total').each(function () {
                    let qty_loop =  $(this).closest('tr').find('td:eq(1) input').val() ?  parseFloat($(this).closest('tr').find('td:eq(1) input').val()) : 0;
                    let harga_loop =  $(this).closest('tr').find('td:eq(2) input').val() ?  parseFloat(replaceCurrency($(this).closest('tr').find('td:eq(2) input').val())) : 0;
                    let total_loop = qty_loop * harga_loop;
                    total_harga += total_loop;
                });
                $('#total_harga').val(accounting.formatMoney(total_harga, '', 0, ",", "."));
            });

            $('body').on('keyup click', '.harga', function (event) {
                let qty =  $(this).closest('tr').find('td:eq(1) input').val() ?  parseFloat($(this).closest('tr').find('td:eq(1) input').val()) : 0;
                let harga =  $(this).closest('tr').find('td:eq(2) input').val() ?  parseFloat(replaceCurrency($(this).closest('tr').find('td:eq(2) input').val())) : 0;
                let total = qty * harga;
                $(this).closest('tr').find('td:eq(3) input').val(accounting.formatMoney(total, '', 0, ",", "."))

                let total_harga = 0;
                $('.total').each(function () {
                    let qty_loop =  $(this).closest('tr').find('td:eq(1) input').val() ?  parseFloat($(this).closest('tr').find('td:eq(1) input').val()) : 0;
                    let harga_loop =  $(this).closest('tr').find('td:eq(2) input').val() ?  parseFloat(replaceCurrency($(this).closest('tr').find('td:eq(2) input').val())) : 0;
                    let total_loop = qty_loop * harga_loop;
                    total_harga += total_loop;
                });
                $('#total_harga').val(accounting.formatMoney(total_harga, '', 0, ",", "."));
            });

            $('body').on('click', '.delete', function (event) {
                var table = document.getElementById("tablemultiple");
                var tbodyRowCount = table.tBodies[0].rows.length;
                if (tbodyRowCount <= 1) {
                    alert('Cannot delete if only 1 row!');
                } else {
                    if (confirm('Are you sure you want to delete?')) {
                        $(this).closest('tr').remove();
                        let total_harga = 0;
                        $('.total').each(function () {
                            let qty_loop =  $(this).closest('tr').find('td:eq(1) input').val() ?  parseFloat($(this).closest('tr').find('td:eq(1) input').val()) : 0;
                            let harga_loop =  $(this).closest('tr').find('td:eq(2) input').val() ?  parseFloat(replaceCurrency($(this).closest('tr').find('td:eq(2) input').val())) : 0;
                            let total_loop = qty_loop * harga_loop;
                            total_harga += total_loop;
                        });
                        $('#total_harga').val(accounting.formatMoney(total_harga, '', 0, ",", "."));
                    }
                }
            });


        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\absensi\resources\views/pengajuan-keuangan/tambah.blade.php ENDPATH**/ ?>