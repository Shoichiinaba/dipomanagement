<?php $__env->startSection('isi'); ?>
    <div class="container-fluid">
        <div class="card col-lg-12">
            <div class="mt-4">
                <form method="post" action="<?php echo e(url('/data-absen/'.$data_absen->id.'/proses-edit-masuk')); ?>" enctype="multipart/form-data">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="col">
                            <label for="jam_absen">Jam Absen</label>
                            <input type="datetime-local" class="form-control <?php $__errorArgs = ['jam_absen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jam_absen" name="jam_absen" value="<?php echo e(old('jam_absen', $data_absen->jam_absen)); ?>">
                            <?php $__errorArgs = ['jam_absen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col">
                            <label for="foto_jam_absen">Foto Absen Masuk</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['foto_jam_absen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="foto_jam_absen" id="foto_jam_absen">
                            <?php $__errorArgs = ['foto_jam_absen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="hidden" name="foto_jam_absen_lama" value="<?php echo e($data_absen->foto_jam_absen); ?>">
                        </div>
                        <input type="hidden" name="lat_absen" value="<?php echo e($lokasi_kantor->lat_kantor); ?>">
                        <input type="hidden" name="long_absen" value="<?php echo e($lokasi_kantor->long_kantor); ?>">
                        <input type="hidden" name="telat">
                        <input type="hidden" name="jarak_masuk">
                        <input type="hidden" name="status_absen" value="Masuk">
                    </div>
                    <br>
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </form>
                  <br>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gpiclick\resources\views/absen/editmasuk.blade.php ENDPATH**/ ?>