<?php $__env->startSection('isi'); ?>
    <div class="container-fluid">
        <div class="card col-lg-12">
            <div class="mt-4">
                <form method="post" action="<?php echo e(url('/data-absen/'.$data_absen->id.'/proses-edit-pulang')); ?>" enctype="multipart/form-data">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="col">
                            <label for="jam_pulang">Jam Pulang</label>
                            <input type="datetime-local" class="form-control <?php $__errorArgs = ['jam_pulang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jam_pulang" id="jam_pulang" value="<?php echo e(old('jam_pulang', $data_absen->jam_pulang)); ?>">
                            <?php $__errorArgs = ['jam_pulang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col">
                            <label for="foto_jam_pulang">Foto Absen Pulang</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['foto_jam_pulang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="foto_jam_pulang" name="foto_jam_pulang">
                            <?php $__errorArgs = ['foto_jam_pulang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="hidden" name="foto_jam_pulang_lama" value="<?php echo e($data_absen->foto_jam_pulang); ?>">
                        </div>
                        <input type="hidden" name="lat_pulang" value="-6.3707314">
                        <input type="hidden" name="long_pulang" value="106.8138057">
                        <input type="hidden" name="pulang_cepat">
                    </div>
                    <br>
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </form>
                  <br>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/t46813/gpiclick.grhapermataibu.com/laravel/resources/views/absen/editpulang.blade.php ENDPATH**/ ?>