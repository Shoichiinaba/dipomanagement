<?php $__env->startSection('isi'); ?>
    <div class="container-fluid">
        <div class="card col-lg-12 p-4">
            <div class="mt-4">
                <form method="post" action="<?php echo e(url('/rekap-data/result')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="col-4">
                            <label for="user_id">Nama karyawan</label>
                            <select name="user_id" id="user_id" class="form-control selectpicker" data-live-search="true">
                                <option value="">Pilih karyawan</option>
                                <?php $__currentLoopData = $data_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $du): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($du->id); ?>"><?php echo e($du->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-4">
                            <label for="tanggal_mulai">Tanggal Mulai</label>
                            <input type="datetime" class="form-control" id="tanggal_mulai" name="tanggal_mulai">
                        </div>
                        <div class="col-4">
                            <label for="tanggal_akhir">Tanggal Akhir</label>
                            <input type="datetime" class="form-control" id="tanggal_akhir" name="tanggal_akhir">
                        </div>
                    </div>
                    <br>
                    <button type="submit" class="btn btn-primary">Cari Data</button>
                  </form>
            </div>
        </div>
        <br>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ricky\resources\views/rekapdata/index.blade.php ENDPATH**/ ?>