<?php $__env->startSection('isi'); ?>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <center>
                    <a href="<?php echo e(url('/shift/create')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Data Shift</a>
                </center>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="tableprint" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Nama Shift</th>
                            <th>Jam Masuk</th>
                            <th>Jam Keluar</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($s->nama_shift); ?></td>
                                <td><?php echo e($s->jam_masuk); ?></td>
                                <td><?php echo e($s->jam_keluar); ?></td>
                                <td>
                                    <?php if($s->nama_shift == 'Libur'): ?>
                                        <span class="badge badge-success">Default Shift</span>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('/shift/'.$s->id.'/edit')); ?>" class="btn btn-sm btn-warning"><i class="fa fa-solid fa-edit"></i></a>
                                        <form action="<?php echo e(url('/shift/'.$s->id)); ?>" method="post" class="d-inline">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-danger btn-sm btn-circle" onClick="return confirm('Are You Sure')"><i class="fa fa-solid fa-trash"></i></button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ricky\resources\views/shift/index.blade.php ENDPATH**/ ?>