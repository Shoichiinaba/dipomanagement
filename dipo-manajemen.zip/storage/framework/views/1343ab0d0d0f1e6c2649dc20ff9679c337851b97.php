
<?php $__env->startSection('isi'); ?>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <a href="#" onclick="tambahUser()" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Data User</a>
            </div>
            <!-- /.card-header -->
            <div id="data-users" class="card-body">
                
            </div>
            <!-- /.card-body -->
          </div>
    </div>
    
    <script>
        //menampilkan data users
        function getDataUsers(){
            $.get("<?php echo e(url('/users/get-data-users')); ?>", {}, function(data, status){
            $("#data-users").html(data);
            })
        }

        //menampilkan halaman tambah user
        function tambahUser(){
            $.get("<?php echo e(url('/users/tambah-user')); ?>", {}, function(data, status){
            $("#formModalLabel").html('Tambah Data User');
            $("#form-modal").html(data);
            $("#formModal").modal('show');
            })
        }

        //proses menambahkan data user
        function prosesTambahUser(){
            var name = $("#name").val();
            var foto_user = $("#foto_user").val();
            var email = $("#email").val();
            var username = $("#username").val();
            var password = $("#password").val();

            $.ajax({
            type: "post",
            url : "<?php echo e(url('/users/tambah-user-proses')); ?>",
            data: "name=" + name + "&foto_user=" + foto_user + "&email=" + email + "&username=" + username + "&password=" + password,
            success:function(data){
                $("#btnclose").click();
                getDataUsers();
            }
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Byson\Documents\laravel\ricky\resources\views/users/index.blade.php ENDPATH**/ ?>