
<?php $__env->startSection('container'); ?>
    <div class="card-secton transfer-section">
        <div class="tf-container">
            <div class="tf-balance-box">
                <div class="tf-spacing-16"></div>

                <div class="bill-content">
                    <form action="<?php echo e(url('/pengajuan-absensi')); ?>">
                        <div class="row">
                            <div class="col-10">
                                <div class="input-field">
                                    <span class="icon-search"></span>
                                    <input required class="search-field value_input" placeholder="Search" name="search" type="text" value="<?php echo e(request('search')); ?>">
                                    <span class="icon-clear"></span>
                                </div>
                            </div>
                            <div class="col-2">

                                <button type="submit" class="btn"><i class="fa fa-search"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="tf-spacing-16"></div>
            </div>
        </div>
    </div>
    <div id="app-wrap">
        <div class="bill-content">
            <div class="tf-container">
                <ul class="mt-3 mb-5">
                    
                    <?php $__currentLoopData = $mapping_shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $tanggal = new DateTime($ms->tanggal);
                        ?>
                        <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                            <div class="user-info">
                                <?php if($ms->User->foto_karyawan == null): ?>
                                    <img src="<?php echo e(url('/assets/img/foto_default.jpg')); ?>" alt="image">
                                <?php else: ?>
                                    <img src="<?php echo e(url('/storage/'.$ms->User->foto_karyawan)); ?>" alt="image">
                                <?php endif; ?>
                            </div>
                            <div class="content-right">
                                <h4><a href="<?php echo e(url('/pengajuan-absensi/edit/'.$ms->id)); ?>"><?php echo e($ms->User->name); ?> <span><?php echo e($ms->status_pengajuan); ?></span></a></h4>
                                <p><a style="color: rgb(141, 141, 141)" href="<?php echo e(url('/pengajuan-absensi/edit/'.$ms->id)); ?>">Attendance Request <span><?php echo e($tanggal->format('d M Y')); ?></span></a></p>
                                <p><a style="color: rgb(141, 141, 141)" href="<?php echo e(url('/pengajuan-absensi/edit/'.$ms->id)); ?>"><?php echo e($ms->deskripsi); ?></a></p>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex justify-content-end me-4 mt-4">
                        <?php echo e($mapping_shift->links()); ?>

                    </div>
                </ul>

            </div>
        </div>
    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\absensi\resources\views/absen/indexPengajuan.blade.php ENDPATH**/ ?>