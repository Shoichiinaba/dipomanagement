
<?php $__env->startSection('isi'); ?>
    <div class="email-wrap">
        <div class="row">
            <div class="col-md-12 project-list">
            <div class="card">
                <div class="row">
                    <div class="col-md-6 mt-2 p-0 d-flex">
                        <h4><?php echo e($title); ?></h4>
                    </div>
                    <div class="col-md-6 p-0">    
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12">
          <div class="email-right-aside">
            <div class="card email-body">
              <div class="email-profile">
                <div>
                  <div class="pe-0 b-r-light"></div>
                  <div class="email-top">
                    <div class="row">
                      <div class="col-12">
                        <div class="d-flex">
                          <div class="flex-grow-1">                                                                       
                            <div class="dropdown">
                              <button class="btn btn-primary dropdown-toggle" id="dropdownMenuButton" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>

                              <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <a class="dropdown-item" href="<?php echo e(url('/notifications/read')); ?>">Read</a>
                                <a class="dropdown-item" href="<?php echo e(url('/notifications/unread')); ?>">Unread</a>
                            </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="inbox">
                    <?php $__currentLoopData = $inboxs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inbox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $user = App\Models\User::find($inbox->data['user_id']);
                        ?>
                        <a href="<?php echo !$inbox->read_at ? url('/notifications/read-message/'.$inbox->id) : url($inbox->data['action']); ?>" class="d-flex" style="<?php echo e(!$inbox->read_at ? 'background-color: rgb(241, 241, 241)' : ''); ?>">
                            <div class="d-flex-size-email">                                       
                                <label class="d-block mb-0">
                                <?php if($user->foto_karyawan == null): ?>
                                    <img class="me-3 rounded-circle" src="<?php echo e(url('assets/img/foto_default.jpg')); ?>" alt="image">
                                <?php else: ?>
                                    <img class="me-3 rounded-circle" src="<?php echo e(url('/storage/'.$user->foto_karyawan)); ?>" alt="">
                                <?php endif; ?>
                            </div>
                            <div class="flex-grow-1">
                                <h6><?php echo e($user->name); ?> </h6>
                                <p><?php echo e($inbox->data['message']); ?></p><span><?php echo e(date('d M Y H:i:s',strtotime($inbox->created_at))); ?></span>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex justify-content-end me-4 mt-4">
                        <?php echo e($inboxs->links()); ?>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/andry/Herd/absensi-laravel/resources/views/notifications/indexAdmin.blade.php ENDPATH**/ ?>