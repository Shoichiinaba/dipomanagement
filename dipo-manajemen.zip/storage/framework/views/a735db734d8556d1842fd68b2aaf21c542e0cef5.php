<?php $__env->startSection('container'); ?>
    <div id="app-wrap" class="style1">
        <div class="tf-container">
            <div class="tf-tab">
                <div class="content-tab pt-tab-space mb-5">
                    <div class="tab-gift-item">
                        <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="food-box">
                                <div class="img-box">
                                    <a href="<?php echo e(url('/berita-user/show/'.$ber->id)); ?>"><img src="<?php echo e(url('/storage/'.$ber->berita_file_path)); ?>" class="img-fluid w-100" style="height: 200px; object-fit: cover;"></a>
                                </div>
                                <div class="content">
                                    <h4><a href="<?php echo e(url('/berita-user/show/'.$ber->id)); ?>"><?php echo e($ber->judul); ?></a></h4>
                                    <div class="rating mt-2">
                                        <?php echo e(Str::limit($ber->isi, 50, '.......')); ?>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>
    <br>
    <br>
    <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Andry Fuzi Lasandry\Herd\Sistem-manajemen-absensi\resources\views/berita/beritaUser.blade.php ENDPATH**/ ?>