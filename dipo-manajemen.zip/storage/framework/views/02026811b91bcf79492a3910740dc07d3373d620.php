
<?php $__env->startSection('isi'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <center>
                <a href="<?php echo e(url('/reset-cuti/master')); ?>" class="btn btn-primary">Edit Master Reset Cuti</a>
            </center>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <table id="tableprint" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nama</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $du): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($du->name); ?></td>
                            <td>
                                <?php if($du->cuti_dadakan == $reset_cuti->cuti_dadakan && $du->cuti_bersama == $reset_cuti->cuti_bersama && $du->cuti_menikah == $reset_cuti->cuti_menikah && $du->cuti_diluar_tanggungan == $reset_cuti->cuti_diluar_tanggungan && $du->cuti_khusus == $reset_cuti->cuti_khusus && $du->cuti_melahirkan == $reset_cuti->cuti_melahirkan && $du->izin_telat == $reset_cuti->izin_telat && $du->izin_pulang_cepat == $reset_cuti->izin_pulang_cepat): ?>
                                    <span class="badge badge-success">Sudah Direset</span>
                                <?php else: ?>
                                    <form action="<?php echo e(url('/reset-cuti/'.$du->id)); ?>" method="post" class="d-inline">
                                        <?php echo method_field('put'); ?>
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="cuti_dadakan" value="<?php echo e($reset_cuti->cuti_dadakan); ?>">
                                        <input type="hidden" name="cuti_bersama" value="<?php echo e($reset_cuti->cuti_bersama); ?>">
                                        <input type="hidden" name="cuti_menikah" value="<?php echo e($reset_cuti->cuti_menikah); ?>">
                                        <input type="hidden" name="cuti_diluar_tanggungan" value="<?php echo e($reset_cuti->cuti_diluar_tanggungan); ?>">
                                        <input type="hidden" name="cuti_khusus" value="<?php echo e($reset_cuti->cuti_khusus); ?>">
                                        <input type="hidden" name="cuti_melahirkan" value="<?php echo e($reset_cuti->cuti_melahirkan); ?>">
                                        <input type="hidden" name="izin_telat" value="<?php echo e($reset_cuti->izin_telat); ?>">
                                        <input type="hidden" name="izin_pulang_cepat" value="<?php echo e($reset_cuti->izin_pulang_cepat); ?>">
                                        <button class="btn btn-warning btn-sm" onClick="return confirm('Reset Cuti Ini?')"><i class="fa fa-sync-alt"></i></button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
        </div>
        <!-- /.card-body -->
      </div>
</div>
<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/t46813/gpiclick.grhapermataibu.com/gpiclick/resources/views/karyawan/resetcuti.blade.php ENDPATH**/ ?>