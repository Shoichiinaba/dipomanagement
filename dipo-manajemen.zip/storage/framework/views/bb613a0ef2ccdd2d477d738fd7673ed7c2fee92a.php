<?php $__env->startComponent('mail::message'); ?>
<?php
    $settings = App\Models\settings::first();
?>

<style>
    .btn-green {
      display: inline-block;
      background-color: #28a745;
      color: #fff;
      padding: 10px 20px;
      text-decoration: none;
      font-size: 16px;
      font-weight: bold;
      border-radius: 5px;
      transition: background-color 0.3s ease;
    }

    .btn-green:hover {
      background-color: #218838;
    }

    .btn-green:active {
      background-color: #1e7e34;
    }
</style>

<center>
    <a href="<?php echo e(url('/forgot-password/reset')); ?>" class="btn-green">LINK RESET PASSWORD</a>
</center>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\absensi\resources\views/auth/forgot.blade.php ENDPATH**/ ?>