
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, viewport-fit=cover">
    <title><?php echo e($title); ?></title>
    <!-- Favicon and Touch Icons  -->
    <link rel="shortcut icon" href="<?php echo e(url('/myhr/images/logo.png')); ?>" />
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(url('/myhr/images/logo.png')); ?>" />
    <!-- Font -->
    <link rel="stylesheet" href="<?php echo e(url('/myhr/fonts/fonts.css')); ?>" />
    <!-- Icons -->
    <link rel="stylesheet" href="<?php echo e(url('/myhr/fonts/icons-alipay.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('/myhr/styles/bootstrap.css')); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/myhr/styles/styles.css')); ?>" />
    <link rel="manifest" href="<?php echo e(url('/myhr/_manifest.json')); ?>" data-pwa-version="set_in_manifest_and_pwa_js">
    <link rel="apple-touch-icon" sizes="192x192" href="<?php echo e(url('/myhr/app/icons/icon-192x192.png')); ?>">
</head>

<body class="bg_surface_color">
     <!-- preloade -->
     <div class="preload preload-container">
        <div class="preload-logo">
          <div class="spinner"></div>
        </div>
      </div>
    <!-- /preload -->
    <div class="header is-fixed">
        <div class="tf-container">
            <div class="tf-statusbar d-flex justify-content-center align-items-center">
                <a href="#" class="back-btn"> <i class="icon-left"></i> </a>
                <h3><?php echo e($title); ?></h3>
            </div>
        </div>
    </div>
    <div id="app-wrap">
        <div class="bill-payment-content">
            <div class="tf-container">

                <div class="wrapper-bill">
                    <div class="archive-bottom ">
                        <h2 class="text-center"><?php echo e($penugasan->nomor_penugasan); ?></h2>
                        <ul>
                            <li class="list-info-bill">
                                Tanggal
                                <span>
                                    <?php if($penugasan->tanggal): ?>
                                        <?php
                                            Carbon\Carbon::setLocale('id');
                                            $tanggal = Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $penugasan->created_at);
                                            $new_tanggal = $tanggal->translatedFormat('d F Y H:i');
                                        ?>
                                        <?php echo e($new_tanggal); ?>

                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </span>
                            </li>
                            <li class="list-info-bill">Nama Pegawai <span><?php echo e($penugasan->user->name ?? '-'); ?></span> </li>
                            <li class="list-info-bill">
                                Status
                                <span class="text-end">
                                    <?php if($penugasan->status == 'PENDING'): ?>
                                        <div class="float-end badge" style="color: rgba(255, 123, 0, 0.889); background-color:rgb(255, 238, 177); border-radius:10px;"><?php echo e($penugasan->status ?? '-'); ?></div>
                                    <?php elseif($penugasan->status == 'PROCESS'): ?>
                                        <div class="float-end badge" style="color: rgb(21, 47, 118); background-color:rgba(192, 218, 254, 0.889); border-radius:10px;"><?php echo e($penugasan->status ?? '-'); ?></div>
                                    <?php else: ?>
                                        <div class="float-end badge" style="color: rgba(20, 78, 7, 0.889); background-color:rgb(186, 238, 162); border-radius:10px;"><?php echo e($penugasan->status ?? '-'); ?></div>
                                    <?php endif; ?>
                                </span>
                            </li>
                        </ul>
                    </div>
                    <div class="line"></div>
                    <div class="archive-bottom mb-4">
                        <ul>
                            <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                <?php echo e($penugasan->judul); ?>

                            </li>
                            <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                <?php echo $penugasan->rincian ? nl2br(e($penugasan->rincian)) : '-'; ?>

                            </li>
                        </ul>
                    </div>
                    <div class="archive-bottom app-wrap">
                        <div class="bill-content">
                            <div class="tf-container">
                                <ul>
                                    <?php $__currentLoopData = $penugasan->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                            <div class="user-info">
                                                <?php if($item->user): ?>
                                                    <?php if($item->user->foto_karyawan): ?>
                                                        <img src="<?php echo e(url('/storage/'.$item->user->foto_karyawan)); ?>" alt="image">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(url('/assets/img/foto_default.jpg')); ?>" alt="image">
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <img src="<?php echo e(url('/assets/img/foto_default.jpg')); ?>" alt="image">
                                                <?php endif; ?>
                                            </div>
                                            <div class="content-right">
                                                <h4>
                                                    <a href="#">
                                                        <?php echo e($item->user->name ?? '-'); ?>

                                                        <?php if($item->flow == 'PENDING'): ?>
                                                            <div class="float-end badge" style="color: rgba(255, 123, 0, 0.889); background-color:rgb(255, 238, 177); border-radius:10px;"><?php echo e($item->flow ?? '-'); ?></div>
                                                        <?php elseif($item->flow == 'PROCESS'): ?>
                                                            <div class="float-end badge" style="color: rgb(21, 47, 118); background-color:rgba(192, 218, 254, 0.889); border-radius:10px;"><?php echo e($item->flow ?? '-'); ?></div>
                                                        <?php else: ?>
                                                            <div class="float-end badge" style="color: rgba(20, 78, 7, 0.889); background-color:rgb(186, 238, 162); border-radius:10px;"><?php echo e($item->flow ?? '-'); ?></div>
                                                        <?php endif; ?>
                                                    </a>
                                                </h4>
                                                <p style="color: rgb(173, 173, 173); font-size:10px;">
                                                    <?php if($item->created_at): ?>
                                                        <?php
                                                            Carbon\Carbon::setLocale('id');
                                                            $created_at = Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->created_at);
                                                            $new_created_at = $created_at->translatedFormat('l, d F Y H:i:s');
                                                        ?>
                                                        <?php echo e($new_created_at); ?>

                                                    <?php else: ?>
                                                        -
                                                    <?php endif; ?>
                                                </p>
                                                <p style="color: rgb(173, 173, 173); font-size:10px;">
                                                    <?php if($item->flow == 'PENDING'): ?>
                                                        Tugas <?php echo e($penugasan->nomor_penugasan); ?> ditugaskan kepada <?php echo e($penugasan->user->name ?? '-'); ?> oleh <?php echo e($item->user->name ?? '-'); ?>

                                                    <?php elseif($item->flow == 'PROCESS'): ?>
                                                        Tugas <?php echo e($penugasan->nomor_penugasan); ?> diproses oleh <?php echo e($item->user->name ?? '-'); ?>

                                                    <?php else: ?>
                                                        Tugas <?php echo e($penugasan->nomor_penugasan); ?> diselesaikan oleh <?php echo e($item->user->name ?? '-'); ?>

                                                    <?php endif; ?>
                                                </p>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                 </div>


            </div>

         </div>
    </div>

    <div class="bottom-navigation-bar st1 bottom-btn-fixed">
        <div class="tf-container">
            <?php if($penugasan->status == 'PENDING'): ?>
                <a href="<?php echo e(url('/penugasan-kerja/process/'.$penugasan->id)); ?>" class="tf-btn accent large" onclick="return confirm('Ingin Proses Pekerjaan Ini?')">Proses Pekerjaan</a>
            <?php elseif($penugasan->status == 'PROCESS'): ?>
                <a href="<?php echo e(url('/penugasan-kerja/finish/'.$penugasan->id)); ?>" class="tf-btn accent large" onclick="return confirm('Ingin Selesaikan Pekerjaan Ini?')">Selesaikan Pekerjaan</a>
            <?php else: ?>
                <a href="<?php echo e(url('/penugasan-kerja')); ?>" class="tf-btn accent large">Back</a>
            <?php endif; ?>
        </div>
    </div>













    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/count-down.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/main.js')); ?>"></script>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\laragon\www\absensi\resources\views/penugasan/penugasanKerjaShow.blade.php ENDPATH**/ ?>