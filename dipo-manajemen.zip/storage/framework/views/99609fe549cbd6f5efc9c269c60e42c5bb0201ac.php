<?php $__env->startSection('isi'); ?>
    <div class="container-fluid">
        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">Tambah Cuti</h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-minus"></i>
                    </button>
                  </div>
            </div>
            <div class="card-body mt-4 p-3">
                <form method="post" action="<?php echo e(url('/cuti/tambah')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="col">
                            <label for="user_id">Nama Pegawai</label>
                            <select id="user_id" name="user_id" class="form-control selectpicker" id="">
                                <option value="<?php echo e($data_user->id); ?>"><?php echo e($data_user->name); ?></option>
                            </select>
                        </div>
                        <div class="col">
                            <?php
                                $izin_cuti = $data_user->izin_cuti;
                                $izin_lainnya = $data_user->izin_lainnya;
                                $izin_telat = $data_user->izin_telat;
                                $izin_pulang_cepat = $data_user->izin_pulang_cepat;

                                $data_cuti = array(
                                    [
                                        'nama' => 'Cuti',
                                        'nama_cuti' => 'Cuti ('.$izin_cuti.')'
                                    ],
                                    [
                                        'nama' => 'Izin Masuk',
                                        'nama_cuti' => 'Izin Masuk ('.$izin_lainnya.')'
                                    ],
                                    [
                                        'nama' => 'Izin Telat',
                                        'nama_cuti' => 'Izin Telat ('.$izin_telat.')'
                                    ],
                                    [
                                        'nama' => 'Izin Pulang Cepat',
                                        'nama_cuti' => 'Izin Pulang Cepat ('.$izin_pulang_cepat.')'
                                    ]
                                );
                            ?>
                            <label for="nama_cuti">Jenis Cuti / Izin</label>
                            <select class="form-control selectpicker <?php $__errorArgs = ['nama_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_cuti" name="nama_cuti" data-live-search="true">
                                <option value="">Pilih Cuti</option>
                                <?php $__currentLoopData = $data_cuti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(old('nama_cuti') == $dc["nama"]): ?>
                                <option value="<?php echo e($dc["nama"]); ?>" selected><?php echo e($dc["nama_cuti"]); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($dc["nama"]); ?>"><?php echo e($dc["nama_cuti"]); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['nama_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <br>
                    <div class="form-row">
                        <div class="col">
                            <label for="tanggal_mulai">Tanggal Mulai</label>
                            <input type="datetime" class="form-control <?php $__errorArgs = ['tanggal_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tanggal_mulai" id="tanggal_mulai" value="<?php echo e(old('tanggal_mulai')); ?>">
                            <?php $__errorArgs = ['tanggal_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col">
                            <label for="tanggal_akhir">Tanggal Akhir</label>
                            <input type="datetime" class="form-control <?php $__errorArgs = ['tanggal_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tanggal_akhir" id="tanggal_akhir" value="<?php echo e(old('tanggal_akhir')); ?>">
                            <?php $__errorArgs = ['tanggal_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <input type="hidden" name="tanggal">
                    </div>
                    <br>
                    <div class="form-row">
                        <div class="col">
                            <label for="foto_cuti">Unggah Foto</label>
                            <input type="file" name="foto_cuti" id="foto_cuti" class="form-control <?php $__errorArgs = ['foto_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['foto_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col">
                            <label for="alasan_cuti">Alasan Cuti</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['alasan_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alasan_cuti" name="alasan_cuti" value="<?php echo e(old('alasan_cuti')); ?>">
                            <?php $__errorArgs = ['alasan_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <input type="hidden" name="status_cuti">
                    </div>
                    <br>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
                  <br>
            </div>
        </div>

        <br><br>

        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h1 class="h3 mb-2 text-gray-800">My Cuti</h1>
           </div>
            <div class="card-body">
                <form action="<?php echo e(url('/cuti')); ?>">
                        <div class="form-row">
                        <div class="col-3">
                            <input type="datetime" class="form-control" name="mulai" placeholder="Tanggal Mulai" id="mulai" value="<?php echo e(request('mulai')); ?>">
                        </div>
                        <div class="col-3">
                            <input type="datetime" class="form-control" name="akhir" placeholder="Tanggal Akhir" id="akhir" value="<?php echo e(request('akhir')); ?>">
                        </div>
                        <div>
                            <button type="submit" id="search" class="form-control btn btn-secondary"><i class="fas fa-search"></i></button>
                        </div>
                    </div>
                </form>
                <table class="table table-striped" id="tablePayroll">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Nama Pegawai</th>
                            <th>Nama Cuti</th>
                            <th>Tanggal</th>
                            <th>Alasan Cuti</th>
                            <th>Foto Cuti</th>
                            <th>Status Cuti</th>
                            <th>Catatan</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                       <?php $__currentLoopData = $data_cuti_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dcu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                           <td><?php echo e(($data_cuti_user->currentpage() - 1) * $data_cuti_user->perpage() + $key + 1); ?>.</td>
                           <td><?php echo e($dcu->User->name); ?></td>
                           <td><?php echo e($dcu->nama_cuti); ?></td>
                           <td><?php echo e($dcu->tanggal); ?></td>
                           <td><?php echo e($dcu->alasan_cuti); ?></td>
                           <td>
                                <img src="<?php echo e(url('storage/'.$dcu->foto_cuti)); ?>" style="width:150px" alt="">
                           </td>
                           <td>
                                <?php if($dcu->status_cuti == "Diterima"): ?>
                                    <span class="badge badge-success"><?php echo e($dcu->status_cuti); ?></span>
                                <?php elseif($dcu->status_cuti == "Ditolak"): ?>
                                    <span class="badge badge-danger"><?php echo e($dcu->status_cuti); ?></span>
                                <?php else: ?>
                                    <span class="badge badge-warning"><?php echo e($dcu->status_cuti); ?></span>
                                <?php endif; ?>
                           </td>
                           <td><?php echo e($dcu->catatan); ?></td>
                           <td>
                            <?php if($dcu->status_cuti == "Diterima"): ?>
                                <span class="badge badge-success">Sudah Approve</span>
                            <?php else: ?>
                                <a href="<?php echo e(url('/cuti/edit/'.$dcu->id)); ?>" class="btn btn-sm btn-warning btn-circle"><i class="fa fa-solid fa-edit"></i></a>
                            <?php endif; ?>

                            <?php if($dcu->status_cuti == "Diterima"): ?>
                                <span class="badge badge-success">Sudah Approve</span>
                            <?php else: ?>
                                <form action="<?php echo e(url('/cuti/delete/'.$dcu->id)); ?>" method="post" class="d-inline">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-sm btn-danger btn-circle" onClick="return confirm('Are You Sure')"><i class="fas fa-trash"></i></button>
                                </form>
                            <?php endif; ?>
                           </td>
                       </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-end mr-4">
                <?php echo e($data_cuti_user->links()); ?>

            </div>
        </div>
    </div>
    <br>
    <?php $__env->startPush('script'); ?>
        <script>
            $(document).ready(function() {
                $('#mulai').change(function(){
                    var mulai = $(this).val();
                $('#akhir').val(mulai);
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\absensi\resources\views/cuti/index.blade.php ENDPATH**/ ?>