
<?php $__env->startSection('isi'); ?>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <center>
                    <a href="<?php echo e(url('/lokasi-kantor/tambah')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Data Lokasi</a>
                </center>
                <a href="<?php echo e(url('/lokasi-kantor/pending-location')); ?>" class="btn btn-warning float-right btn-sm"><i class="fa fa-hourglass-start mr-2"></i> Pending Location</a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="tableprint" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Nama Lokasi</th>
                            <th>Latitude</th>
                            <th>Longitude</th>
                            <th>Radius (Meter)</th>
                            <th>Created By</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data_lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($dl->nama_lokasi); ?></td>
                                <td><?php echo e($dl->lat_kantor); ?></td>
                                <td><?php echo e($dl->long_kantor); ?></td>
                                <td><?php echo e($dl->radius); ?></td>
                                <td><?php echo e($dl->CreatedBy->name); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/lokasi-kantor/edit/'.$dl->id)); ?>" class="btn btn-sm btn-warning"><i class="fa fa-solid fa-edit"></i></a>
                                    <form action="<?php echo e(url('/lokasi-kantor/delete/'.$dl->id)); ?>" method="post" class="d-inline">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-danger btn-sm btn-circle" onClick="return confirm('Are You Sure')"><i class="fa fa-solid fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
    </div>
    <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\absensi_payroll\resources\views/lokasi/index.blade.php ENDPATH**/ ?>