<?php $__env->startSection('isi'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-6">
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3><?php echo e($jumlah_user); ?></h3>

                        <p>Total Karyawan</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person-add"></i>
                    </div>
                    <a href="<?php echo e(url('/karyawan')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-success">
                  <div class="inner">
                    <h3><?php echo e($jumlah_masuk + $jumlah_izin_telat + $jumlah_izin_pulang_cepat); ?></h3>

                    <p>Jumlah Karyawan Masuk</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                  <a href="<?php echo e(url('/data-absen')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-danger">
                  <div class="inner">
                    <h3><?php echo e($jumlah_tidak_masuk); ?></h3>

                    <p>Jumlah Karyawan Alfa</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-pie-graph"></i>
                  </div>
                  <a href="<?php echo e(url('/data-absen')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-info">
                  <div class="inner">
                    <h3><?php echo e($jumlah_libur); ?></h3>

                    <p>Jumlah Karyawan Libur</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-calendar"></i>
                  </div>
                  <a href="<?php echo e(url('/data-absen')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>

        </div>
        
        <div class="row">
            <div class="col-lg-4 col-6">
                <div class="small-box bg-info">
                  <div class="inner">
                    <h3><?php echo e($jumlah_izin_telat); ?></h3>

                    <p>Jumlah Karyawan Izin Telat</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-calendar"></i>
                  </div>
                  <a href="<?php echo e(url('/data-absen')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-6">
              <div class="small-box bg-warning">
                <div class="inner">
                    <h3><?php echo e($jumlah_cuti); ?></h3>

                    <p>Jumlah Karyawan Cuti</p>
                </div>
                <div class="icon">
                    <i class="ion ion-clock"></i>
                </div>
                <a href="<?php echo e(url('/data-cuti')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
            </div>
            <div class="col-lg-4">
                <div class="small-box bg-danger">
                  <div class="inner">
                    <h3><?php echo e($jumlah_izin_pulang_cepat); ?></h3>

                    <p>Jumlah Karyawan Izin Pulang Cepat</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                  <a href="<?php echo e(url('/data-absen')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
        </div>
        
        
        <div class="row">
            <!-- Calendar -->
            <div class="col">
                <div class="card bg-gradient-success">
                    <div class="card-header border-0">

                      <h3 class="card-title">
                        <i class="far fa-calendar-alt"></i>
                        Calendar
                      </h3>
                      <!-- tools card -->
                      <div class="card-tools">
                        <button type="button" class="btn btn-success btn-sm" data-card-widget="collapse">
                          <i class="fas fa-minus"></i>
                        </button>
                      </div>
                      <!-- /. tools -->
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body pt-0">
                      <!--The calendar -->
                      <div id="calendar" style="width: 100%"></div>
                    </div>
                    <!-- /.card-body -->
                 </div>
            </div>
        </div>

    </div>
    <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/t46813/gpiclick.grhapermataibu.com/laravel/resources/views/dashboard/index.blade.php ENDPATH**/ ?>