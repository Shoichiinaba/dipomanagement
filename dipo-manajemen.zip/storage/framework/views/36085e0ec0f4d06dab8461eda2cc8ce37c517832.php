
<?php $__env->startSection('container'); ?>
    <div class="card-secton transfer-section">
        <div class="tf-container">
            <div class="tf-balance-box">
                <div class="tf-spacing-16"></div>

                <div class="bill-content">
                    <form action="<?php echo e(url('/pegawai')); ?>">
                        <div class="row">
                            <div class="col-10">
                                <div class="input-field">
                                    <span class="icon-search"></span>
                                    <input required class="search-field value_input" placeholder="Search" name="search" type="text" value="<?php echo e(request('search')); ?>">
                                    <span class="icon-clear"></span>
                                </div>
                            </div>
                            <div class="col-2">

                                <button type="submit" class="btn"><i class="fa fa-search"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="tf-spacing-16"></div>
            </div>
        </div>
    </div>
    <?php if(request('search') !== null): ?>
        <div id="app-wrap">
            <div class="bill-content">
                <div class="tf-container">
                    <h3 class="fw_6 d-flex justify-content-between mt-3"><?php echo e($title); ?></h3>
                    <ul class="mt-3 mb-5">
                        
                        <?php $__currentLoopData = $data_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $du): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                <div class="user-info">
                                    <?php if($du->foto_karyawan == null): ?>
                                        <img src="<?php echo e(url('/assets/img/foto_default.jpg')); ?>" alt="image">
                                    <?php else: ?>
                                        <img src="<?php echo e(url('/storage/'.$du->foto_karyawan)); ?>" alt="image">
                                    <?php endif; ?>
                                </div>
                                <div class="content-right">
                                    <h4><a href="<?php echo e(url('/pegawai/show/'.$du->id)); ?><?php echo e($_GET?'?'.$_SERVER['QUERY_STRING']: ''); ?>"><?php echo e($du->name); ?> <span class="primary_color">View</span></a></h4>
                                    <p>
                                        <?php echo e($du->Jabatan->nama_jabatan ?? '-'); ?> <br> <a href="https://wa.me/<?php echo e($du->whatsapp($du->telepon)); ?>"><?php echo e($du->telepon); ?></a>
                                    </p>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-end me-4 mt-4">
                            <?php echo e($data_user->links()); ?>

                        </div>
                    </ul>

                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\absensi\resources\views/karyawan/indexUser.blade.php ENDPATH**/ ?>