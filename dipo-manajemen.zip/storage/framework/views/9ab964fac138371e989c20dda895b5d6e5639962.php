
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, viewport-fit=cover">
    <title><?php echo e($title); ?></title>
    <!-- Favicon and Touch Icons  -->
    <link rel="shortcut icon" href="<?php echo e(url('/myhr/images/logo.png')); ?>" />
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(url('/myhr/images/logo.png')); ?>" />
    <!-- Font -->
    <link rel="stylesheet" href="<?php echo e(url('/myhr/fonts/fonts.css')); ?>" />
    <!-- Icons -->
    <link rel="stylesheet" href="<?php echo e(url('/myhr/fonts/icons-alipay.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('/myhr/styles/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('/myhr/styles/swiper-bundle.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/myhr/styles/styles.css')); ?>" />
    <link rel="manifest" href="<?php echo e(url('/myhr/_manifest.json')); ?>" data-pwa-version="set_in_manifest_and_pwa_js">
    <link rel="apple-touch-icon" sizes="192x192" href="<?php echo e(url('/myhr/app/icons/icon-192x192.png')); ?>">
</head>

<body>
       <!-- preloade -->
       <div class="preload preload-container">
        <div class="preload-logo">
          <div class="spinner"></div>
        </div>
      </div>
    <!-- /preload -->
    <div class="header is-fixed">
        <div class="tf-container">
            <div class="tf-statusbar d-flex justify-content-center align-items-center">
                <a href="#" class="back-btn"> <i class="icon-left"></i> </a>
                <h3><?php echo e($title); ?></h3>
            </div>
        </div>
    </div>
    <div id="app-wrap" class="style1">
        <div class="tf-container">
            <div class="repicient-content mt-8">
                <div class="tf-container">
                 <div class="box-user mt-5 text-center">
                     <div class="box-avatar">
                         <?php if(auth()->user()->foto_karyawan == null): ?>
                             <img src="<?php echo e(url('/assets/img/foto_default.jpg')); ?>" alt="image">
                         <?php else: ?>
                             <img src="<?php echo e(url('/storage/'.auth()->user()->foto_karyawan)); ?>" alt="image">
                         <?php endif; ?>
                     </div>
                     <h3 class="fw_8 mt-3"><?php echo e(strtoupper(auth()->user()->name)); ?></h3>
                     <h4 style="color: rgb(196, 196, 101)">SKOR : <?php echo e($skor_akhir->penilaian_berjalan ?? 0); ?></h4>
                 </div>
                </div>
            </div>
            <div class="tf-tab">
                <ul class="menu-tabs tabs-food">
                    <li class="nav-tab active">List Penilaian</li>
                    <li class="nav-tab">Data Penilaian</li>
                </ul>
                <div class="content-tab pt-tab-space mb-5">
                    <div id="tab-gift-item app-wrap">
                        <div class="bill-content">
                            <div class="tf-container">
                                <ul class="mt-3 mb-5">
                                    <?php $__currentLoopData = $list_penilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                            <div class="content-right">
                                                <h4><a href="#"><?php echo e($lp->jenis->nama ?? '-'); ?> <span class="btn btn-<?php echo e($lp->nilai <= 0 ? 'danger' : 'primary'); ?>"><?php echo e($lp->nilai ?? '-'); ?></span></a></h4>
                                                <p>
                                                    <?php if($lp->tanggal): ?>
                                                        <?php
                                                            Carbon\Carbon::setLocale('id');
                                                            $tanggal = Carbon\Carbon::createFromFormat('Y-m-d', $lp->tanggal);
                                                            $new_tanggal = $tanggal->translatedFormat('l, d F Y');
                                                        ?>
                                                        <?php echo e($new_tanggal); ?>

                                                    <?php else: ?>
                                                        -
                                                    <?php endif; ?>
                                                </p>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-flex justify-content-end me-4 mt-4">
                                        <?php echo e($list_penilaian->links()); ?>

                                    </div>
                                </ul>

                            </div>
                        </div>
                    </div>

                    <div id="tab-gift-item-2 app-wrap">
                        <div class="bill-content">
                            <div class="tf-container">
                                <ul class="mt-3 mb-5">
                                    <?php $__currentLoopData = $data_penilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-card-invoice tf-topbar d-flex justify-content-between align-items-center">
                                            <div class="content-right">
                                                <h4><a href="#"><?php echo e($dp->nama ?? '-'); ?> <span class="btn btn-<?php echo e($dp->total_penilaian <= 0 ? 'danger' : 'primary'); ?>"><?php echo e($dp->total_penilaian ?? '-'); ?></span></a></h4>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>

                            </div>
                        </div>
                    </div>

                </div>
            </div>


        </div>
    </div>

    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/swiper-bundle.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/swiper.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('/myhr/javascript/main.js')); ?>"></script>

    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\absensi\resources\views/kinerja-pegawai/indexUser.blade.php ENDPATH**/ ?>