<?php $__env->startSection('isi'); ?>
    <div class="row">
        <div class="col-md-12 project-list">
            <div class="card">
                <div class="row">
                    <div class="col-md-6 mt-2 p-0 d-flex">
                        <h4><?php echo e($title); ?></h4>
                    </div>
                    <div class="col-md-6 p-0">
                        <a href="<?php echo e(url('/list-pengajuan-keuangan/excel')); ?><?php echo e($_GET?'?'.$_SERVER['QUERY_STRING']: ''); ?>" class="btn btn-success">Export</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <form action="<?php echo e(url('/list-pengajuan-keuangan')); ?>">
                        <?php
                            $status = array(
                                [
                                    "status" => "PENDING",
                                ],
                                [
                                    "status" => "APPROVED",
                                ],
                                [
                                    "status" => "REJECTED",
                                ],
                                [
                                    "status" => "COMPLETED",
                                ],
                            );
                        ?>
                        <div class="row mb-2">
                            <div class="col-5">
                                <input type="text" class="form-control" name="search" placeholder="Search.." id="search" value="<?php echo e(request('search')); ?>">
                            </div>
                            <div class="col-2">
                                <select name="status" id="status" class="form-control selectpicker" data-live-search="true">
                                    <option value=""selected>Status</option>
                                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(request('status') == $stat['status']): ?>
                                            <option value="<?php echo e($stat['status']); ?>"selected><?php echo e($stat['status']); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($stat['status']); ?>"><?php echo e($stat['status']); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-2">
                                <input type="datetime" class="form-control" name="mulai" placeholder="Tanggal Mulai" id="mulai" value="<?php echo e(request('mulai')); ?>">
                            </div>
                            <div class="col-2">
                                <input type="datetime" class="form-control" name="akhir" placeholder="Tanggal Akhir" id="akhir" value="<?php echo e(request('akhir')); ?>">
                            </div>
                            <div class="col-1">
                                <button type="submit" id="search"class="border-0 mt-3" style="background-color: transparent;"><i class="fas fa-search"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" style="vertical-align: middle">
                            <thead>
                                <tr>
                                    <th class="text-center" style="position: sticky; left: 0; background-color: rgb(215, 215, 215); z-index: 2;border: 1px solid black;">No.</th>
                                    <th style="position: sticky; left: 40px; background-color: rgb(215, 215, 215); z-index: 2; min-width: 230px;border: 1px solid black;" class="text-center">Nomor Pengajuan</th>
                                    <th style="min-width: 300px; background-color:rgb(243, 243, 243);border: 1px solid black;" class="text-center">Nama Pegawai</th>
                                    <th style="min-width: 170px; background-color:rgb(243, 243, 243);border: 1px solid black;" class="text-center">Tanggal</th>
                                    <th style="min-width: 300px; background-color:rgb(243, 243, 243);border: 1px solid black;" class="text-center">Items</th>
                                    <th style="min-width: 230px; background-color:rgb(243, 243, 243);border: 1px solid black;" class="text-center">Total Pengajuan</th>
                                    <th style="min-width: 300px; background-color:rgb(243, 243, 243);border: 1px solid black;" class="text-center">Keterangan</th>
                                    <th style="min-width: 200px; background-color:rgb(243, 243, 243);border: 1px solid black;" class="text-center">File</th>
                                    <th style="min-width: 170px; background-color:rgb(243, 243, 243);border: 1px solid black;" class="text-center">Status</th>
                                    <th style="min-width: 400px; background-color:rgb(243, 243, 243);border: 1px solid black;" class="text-center">User Approval</th>
                                    <th style="min-width: 200px; background-color:rgb(243, 243, 243);border: 1px solid black;" class="text-center">Nota</th>
                                    <th class="text-center" style="background-color:rgb(243, 243, 243);border: 1px solid black;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($pengajuan_keuangans) <= 0): ?>
                                    <tr>
                                        <td colspan="10" class="text-center">Tidak Ada Data</td>
                                    </tr>
                                <?php else: ?>
                                    <?php $__currentLoopData = $pengajuan_keuangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center" style="position: sticky; left: 0; background-color: rgb(235, 235, 235); z-index: 1;border: 1px solid black;"><?php echo e(($pengajuan_keuangans->currentpage() - 1) * $pengajuan_keuangans->perpage() + $key + 1); ?>.</td>
                                            <td class="text-center" style="position: sticky; left: 40px; background-color: rgb(235, 235, 235); z-index: 1;border: 1px solid black;"><?php echo e($pk->nomor ?? '-'); ?></td>
                                            <td class="text-center" style="border: 1px solid black;"><?php echo e($pk->user->name ?? '-'); ?></td>
                                            <td class="text-center" style="border: 1px solid black;">
                                                <?php if($pk->tanggal): ?>
                                                    <?php
                                                        Carbon\Carbon::setLocale('id');
                                                        $tanggal = Carbon\Carbon::createFromFormat('Y-m-d', $pk->tanggal);
                                                        $new_tanggal = $tanggal->translatedFormat('d F Y');
                                                    ?>
                                                    <?php echo e($new_tanggal); ?>

                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td style="border: 1px solid black;">
                                                <?php if(count($pk->items) > 0): ?>
                                                    <?php $__currentLoopData = $pk->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="row">
                                                            <div class="col-3">
                                                                Nama
                                                            </div>
                                                            <div class="col-1">
                                                                :
                                                            </div>
                                                            <div class="col-8">
                                                                <?php echo e($item->nama); ?>

                                                            </div>
                                                            <div class="col-3">
                                                                Qty
                                                            </div>
                                                            <div class="col-1">
                                                                :
                                                            </div>
                                                            <div class="col-8">
                                                                <?php echo e($item->qty); ?>

                                                            </div>
                                                            <div class="col-3">
                                                                Harga
                                                            </div>
                                                            <div class="col-1">
                                                                :
                                                            </div>
                                                            <div class="col-8">
                                                                Rp <?php echo e(number_format($item->harga)); ?>

                                                            </div>
                                                            <div class="col-3">
                                                                Total
                                                            </div>
                                                            <div class="col-1">
                                                                :
                                                            </div>
                                                            <div class="col-8">
                                                                Rp <?php echo e(number_format($item->total)); ?>

                                                            </div>
                                                        </div>
                                                        <?php if($index < count($pk->items) - 1): ?>
                                                            <hr style="background-color: black">
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center" style="border: 1px solid black;">Rp <?php echo e(number_format($pk->total_harga)); ?></td>
                                            <td style="border: 1px solid black;"><?php echo $pk->keterangan ? nl2br(e($pk->keterangan)) : '-'; ?></td>
                                            <td class="text-center" style="border: 1px solid black;">
                                                <?php if($pk->pk_file_path): ?>
                                                    <a href="<?php echo e(url('/storage/'.$pk->pk_file_path)); ?>" style="font-size: 10px"><i class="fa fa-download"></i> <?php echo e($pk->pk_file_name); ?></a>
                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center" style="border: 1px solid black;">
                                                <?php if($pk->status == 'REJECTED'): ?>
                                                    <div class="badge" style="color: rgba(78, 26, 26, 0.889); background-color:rgb(242, 170, 170); border-radius:10px;"><?php echo e($pk->status ?? '-'); ?></div>
                                                <?php elseif($pk->status == 'APPROVED'): ?>
                                                    <div class="badge" style="color: rgba(20, 78, 7, 0.889); background-color:rgb(186, 238, 162); border-radius:10px;"><?php echo e($pk->status ?? '-'); ?></div>
                                                <?php elseif($pk->status == 'PENDING'): ?>
                                                    <div class="badge" style="color: rgba(255, 123, 0, 0.889); background-color:rgb(255, 238, 177); border-radius:10px;"><?php echo e($pk->status ?? '-'); ?></div>
                                                <?php elseif($pk->status == 'ON GOING'): ?>
                                                    <div class="badge" style="color: rgb(21, 47, 118); background-color:rgba(192, 218, 254, 0.889); border-radius:10px;"><?php echo e($pk->status ?? '-'); ?></div>
                                                <?php else: ?>
                                                    <div class="badge" style="color: rgb(45, 45, 45); background-color:rgba(207, 207, 207, 0.889); border-radius:10px;"><?php echo e($pk->status ?? '-'); ?></div>
                                                <?php endif; ?>
                                            </td>
                                            <td style="border: 1px solid black;">
                                                <?php if($pk->ua): ?>
                                                    <div class="float-start badge" style="color: rgba(255, 123, 0, 0.889); background-color:rgb(255, 238, 177); border-radius:10px;">
                                                        <?php echo e($pk->ua->name ?? '-'); ?>

                                                    </div>
                                                    <div class="float-end" style="font-style: italic">
                                                        <?php echo $pk->note_approval ? nl2br(e($pk->note_approval)) : '-'; ?>

                                                    </div>
                                                <?php else: ?>
                                                    <center>
                                                        -
                                                    </center>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center" style="border: 1px solid black;">
                                                <?php if($pk->nota_file_path): ?>
                                                    <a href="<?php echo e(url('/storage/'.$pk->nota_file_path)); ?>" style="font-size: 10px"><i class="fa fa-download"></i> <?php echo e($pk->nota_file_name); ?></a>
                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td style="border: 1px solid black;">
                                                <?php if($pk->status == 'PENDING'): ?>
                                                    <?php if($pk->total_harga <= 1000000): ?>
                                                        <?php if(auth()->user()->hasAnyRole(['admin', 'finance', 'regional_manager', 'general_manager'])): ?>
                                                            <center>
                                                                <button class="border-0" style="background-color: transparent" type="button" data-bs-toggle="modal" data-original-title="test" data-bs-target="#exampleModal"><i style="color:blue" class="fa fa-check-circle me-2"></i></button>
                                                            </center>
                                                            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                                <div class="modal-dialog" role="document">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title" id="exampleModalLabel">Approval Pengajuan Keuangan</h5>
                                                                            <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                        </div>
                                                                        <form action="<?php echo e(url('/list-pengajuan-keuangan/approval/'.$pk->id)); ?>" method="POST">
                                                                            <?php echo csrf_field(); ?>
                                                                            <div class="modal-body">
                                                                                <div class="form-group">
                                                                                    <?php
                                                                                        $status = array(
                                                                                            [
                                                                                                "status" => "APPROVED",
                                                                                                "status_name" => "APPROVE"
                                                                                            ],
                                                                                            [
                                                                                                "status" => "REJECTED",
                                                                                                "status_name" => "REJECT"
                                                                                            ]
                                                                                        );
                                                                                    ?>
                                                                                    <label for="status">Status</label>
                                                                                    <select name="status" id="status" class="form-control selectpicker" data-live-search="true">
                                                                                        <option value="">Pilih Status</option>
                                                                                        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                            <?php if(old('status', $pk->status) == $s["status"]): ?>
                                                                                                <option value="<?php echo e($s["status"]); ?>" selected><?php echo e($s["status_name"]); ?></option>
                                                                                            <?php else: ?>
                                                                                                <option value="<?php echo e($s["status"]); ?>"><?php echo e($s["status_name"]); ?></option>
                                                                                            <?php endif; ?>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    </select>
                                                                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                        <div class="invalid-feedback">
                                                                                            <?php echo e($message); ?>

                                                                                        </div>
                                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                                </div>
                                                                                <div class="form-group">
                                                                                    <label for="note_approval" class="col-form-label">Note:</label>
                                                                                    <textarea class="form-control" id="note_approval" name="note_approval"><?php echo e(old('note_approval')); ?></textarea>
                                                                                    <?php $__errorArgs = ['note_approval'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                        <div class="invalid-feedback">
                                                                                            <?php echo e($message); ?>

                                                                                        </div>
                                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                                </div>
                                                                            </div>
                                                                            <div class="modal-footer">
                                                                                <button class="btn btn-primary" type="button" data-bs-dismiss="modal">Close</button>
                                                                                <button class="btn btn-secondary" type="submit">Save changes</button>
                                                                            </div>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <?php if(auth()->user()->hasAnyRole(['admin', 'regional_manager', 'general_manager'])): ?>
                                                            <center>
                                                                <button class="border-0" style="background-color: transparent" type="button" data-bs-toggle="modal" data-original-title="test" data-bs-target="#exampleModal"><i style="color:blue" class="fa fa-check-circle me-2"></i></button>
                                                            </center>
                                                            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                                <div class="modal-dialog" role="document">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title" id="exampleModalLabel">Approval Pengajuan Keuangan</h5>
                                                                            <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                        </div>
                                                                        <form action="<?php echo e(url('/list-pengajuan-keuangan/approval/'.$pk->id)); ?>" method="POST">
                                                                            <?php echo csrf_field(); ?>
                                                                            <div class="modal-body">
                                                                                <div class="form-group">
                                                                                    <?php
                                                                                        $status = array(
                                                                                            [
                                                                                                "status" => "APPROVED",
                                                                                                "status_name" => "APPROVE"
                                                                                            ],
                                                                                            [
                                                                                                "status" => "REJECTED",
                                                                                                "status_name" => "REJECT"
                                                                                            ]
                                                                                        );
                                                                                    ?>
                                                                                    <label for="status">Status</label>
                                                                                    <select name="status" id="status" class="form-control selectpicker" data-live-search="true">
                                                                                        <option value="">Pilih Status</option>
                                                                                        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                            <?php if(old('status', $pk->status) == $s["status"]): ?>
                                                                                                <option value="<?php echo e($s["status"]); ?>" selected><?php echo e($s["status_name"]); ?></option>
                                                                                            <?php else: ?>
                                                                                                <option value="<?php echo e($s["status"]); ?>"><?php echo e($s["status_name"]); ?></option>
                                                                                            <?php endif; ?>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    </select>
                                                                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                        <div class="invalid-feedback">
                                                                                            <?php echo e($message); ?>

                                                                                        </div>
                                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                                </div>
                                                                                <div class="form-group">
                                                                                    <label for="note_approval" class="col-form-label">Note:</label>
                                                                                    <textarea class="form-control" id="note_approval" name="note_approval"><?php echo e(old('note_approval')); ?></textarea>
                                                                                    <?php $__errorArgs = ['note_approval'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                        <div class="invalid-feedback">
                                                                                            <?php echo e($message); ?>

                                                                                        </div>
                                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                                </div>
                                                                            </div>
                                                                            <div class="modal-footer">
                                                                                <button class="btn btn-primary" type="button" data-bs-dismiss="modal">Close</button>
                                                                                <button class="btn btn-secondary" type="submit">Save changes</button>
                                                                            </div>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php endif; ?>

                                                <?php if($pk->status == 'ON GOING' && $pk->nota_file_path): ?>
                                                    <a class="btn btn-info" onclick="return confirm('Are You Sure?')" href="<?php echo e(url('/list-pengajuan-keuangan/close/'.$pk->id)); ?>">COMPLETE</a>
                                                <?php endif; ?>

                                                <center>
                                                    <a class="badge badge-info" target="_blank" href="<?php echo e(url('/list-pengajuan-keuangan/pdf/'.$pk->id)); ?>"><i class="fa fa-file-pdf"></i> Pdf</a>
                                                </center>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-end mt-4">
                        <?php echo e($pengajuan_keuangans->links()); ?>

                    </div>

                </div>
            </div>
        </div>
    </div>
    <br>

    <?php $__env->startPush('script'); ?>
        <script>
            $(document).ready(function() {
                $('#mulai').change(function(){
                    var mulai = $(this).val();
                $('#akhir').val(mulai);
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\absensi\resources\views/pengajuan-keuangan/list.blade.php ENDPATH**/ ?>