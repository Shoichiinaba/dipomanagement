<?php $__env->startSection('isi'); ?>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <form action="<?php echo e(url('/data-lembur')); ?>">
                    <span>Filter Nama dan Rentang Tanggal</span><br><br>
                    <div class="form-row">
                        <div class="col-3">
                            <select name="user_id" id="user_id" class="form-control selectpicker" data-live-search="true">
                                <option value=""selected>Pilih Karyawan</option>
                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(request('user_id') == $u->id): ?>
                                        <option value="<?php echo e($u->id); ?>"selected><?php echo e($u->name); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($u->id); ?>"><?php echo e($u->name); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-3">
                            <input type="datetime" class="form-control" name="mulai" placeholder="Tanggal Mulai" id="mulai" value="<?php echo e(request('mulai')); ?>">
                        </div>
                        <div class="col-3">
                            <input type="datetime" class="form-control" name="akhir" placeholder="Tanggal Akhir" id="akhir" value="<?php echo e(request('akhir')); ?>">
                        </div>
                        <div>
                            <button type="submit" id="search" class="form-control btn btn-primary"><i class="fas fa-search"></i></button>
                        </div>
                    </div>
        </form>
            </div>
            <div class="card-body">
                <table id="tableprint" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Nama Karyawan</th>
                            <th>Tanggal</th>
                            <th>Jam Masuk</th>
                            <th>Lokasi Masuk</th>
                            <th>Foto Masuk</th>
                            <th>Jam Pulang</th>
                            <th>Lokasi Pulang</th>
                            <th>Foto Pulang</th>
                            <th>Total Lembur</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data_lembur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($dl->User->name); ?></td>
                            <td><?php echo e($dl->tanggal); ?></td>
                            <td>
                                <?php
                                    $jam_masuk = explode(" ", $dl->jam_masuk);
                                ?>
                                <span class="badge badge-success"><?php echo e($jam_masuk[1]); ?></span>
                            </td>
                            <td>
                                <a href="<?php echo e(url('/maps/'.$dl->lat_masuk.'/'.$dl->long_masuk)); ?>" class="btn btn-sm btn-secondary" target="_blank">lihat</a>
                            </td>
                            <td>
                                <img src="<?php echo e(url('storage/' . $dl->foto_jam_masuk)); ?>" style="width: 60px">
                            </td>
                            <td>
                                <?php if($dl->jam_keluar == null): ?>
                                    <span class="badge badge-warning">Belum Pulang Lembur</span>
                                <?php else: ?>
                                    <?php
                                        $jam_keluar = explode(" ", $dl->jam_keluar);
                                    ?>
                                    <span class="badge badge-success"><?php echo e($jam_keluar[1]); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($dl->jam_keluar == null): ?>
                                    <span class="badge badge-warning">Belum Pulang Lembur</span>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/maps/'.$dl->lat_keluar.'/'.$dl->long_keluar)); ?>" class="btn btn-sm btn-secondary" target="_blank">lihat</a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($dl->jam_keluar == null): ?>
                                    <span class="badge badge-warning">Belum Pulang Lembur</span>
                                <?php else: ?>
                                    <img src="<?php echo e(url('storage/' . $dl->foto_jam_keluar)); ?>" style="width: 60px">
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($dl->jam_keluar == null): ?>
                                    <span class="badge badge-warning">Belum Pulang Lembur</span>
                                <?php else: ?>
                                    <?php
                                        $total_lembur = $dl->total_lembur;
                                        $jam   = floor($total_lembur / (60 * 60));
                                        $menit = $total_lembur - ( $jam * (60 * 60) );
                                        $menit2 = floor( $menit / 60 );
                                    ?>
                                    <span class="badge badge-success"><?php echo e($jam." Jam ".$menit2." Menit"); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ricky\resources\views/lembur/datalembur.blade.php ENDPATH**/ ?>