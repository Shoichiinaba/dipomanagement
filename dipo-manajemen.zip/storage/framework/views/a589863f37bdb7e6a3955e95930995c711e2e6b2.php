<?php $__env->startSection('auth'); ?>
<div class="login-logo">
    <img src="<?php echo e(url('assets/img/logowebgpi.png')); ?>" style="width: 50px" alt="" srcset="">
    <br>
    <a href="<?php echo e(url('/')); ?>" style="color: green">GPI<sup>Click</sup></a>
</div>
<!-- /.login-logo -->
<div class="card">
                            <?php if(session()->has('success')): ?>
                              <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(session('success')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                            <?php endif; ?>
                            <?php if(session()->has('loginError')): ?>
                              <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo e(session('loginError')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                            <?php endif; ?>
    <div class="card-body login-card-body">
        <p class="login-box-msg"><i class="fa fa-solid fa-key"></i> Sign In</p>

        <form action="<?php echo e(url('/login-proses')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="input-group mb-3">
                <input type="text" class="form-control" placeholder="Username" name="username">
                <div class="input-group-append">
                    <div class="input-group-text">
                        <span class="fa fa-solid fa-user"></span>
                    </div>
                </div>
            </div>
            <div class="input-group mb-3">
                <input type="password" class="form-control" placeholder="Password" name="password">
                <div class="input-group-append">
                    <div class="input-group-text">
                        <span class="fas fa-lock"></span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-8">
                    <div class="icheck-primary">
                    <input type="checkbox" id="remember">
                    <label for="remember">
                        Remember Me
                    </label>
                    </div>
                </div>
                <!-- /.col -->
                <div class="col-4">
                    <button type="submit" class="btn btn-primary btn-block">Sign In</button>
                </div>
                <!-- /.col -->
            </div>
        </form>
        <br>
        
    </div>
    <!-- /.login-card-body -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gpiclick\resources\views/auth/login.blade.php ENDPATH**/ ?>