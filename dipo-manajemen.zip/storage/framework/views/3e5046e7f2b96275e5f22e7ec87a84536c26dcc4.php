<?php $__env->startSection('isi'); ?>
    <div class="row">
        <div class="col-md-12 project-list">
            <div class="card">
                <div class="row">
                    <div class="col-md-6 mt-2 p-0 d-flex">
                        <h4><?php echo e($title); ?></h4>
                    </div>
                    <div class="col-md-6 p-0">
                        <a href="<?php echo e(url('/kontrak/tambah')); ?>" class="btn btn-primary ms-2">+ Tambah</a>
                        <a href="<?php echo e(url('/kontrak/export')); ?><?php echo e($_GET?'?'.$_SERVER['QUERY_STRING']: ''); ?>" class="btn btn-success">Export</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <form action="<?php echo e(url('/kontrak')); ?>">
                        <div class="row mb-2">
                            <div class="col-5">
                                <input type="text" class="form-control" name="nama" placeholder="Nama Pegawai" id="nama" value="<?php echo e(request('nama')); ?>">
                            </div>
                            <div class="col-3">
                                <input type="datetime" class="form-control" name="mulai" placeholder="Tanggal Mulai" id="mulai" value="<?php echo e(request('mulai')); ?>">
                            </div>
                            <div class="col-3">
                                <input type="datetime" class="form-control" name="akhir" placeholder="Tanggal Akhir" id="akhir" value="<?php echo e(request('akhir')); ?>">
                            </div>
                            <div class="col-1">
                                <button type="submit" id="search"class="border-0 mt-3" style="background-color: transparent;"><i class="fas fa-search"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="card-body">
                    <div class="table-responsive" style="border-radius: 10px">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th class="text-center" style="position: sticky; left: 0; background-color: rgb(215, 215, 215); z-index: 2;">No.</th>
                                    <th style="position: sticky; left: 40px; background-color: rgb(215, 215, 215); z-index: 2; min-width: 230px;" class="text-center">Nama Pegawai</th>
                                    <th style="min-width: 170px; background-color:rgb(243, 243, 243);" class="text-center">Tanggal</centh>
                                    <th style="min-width: 350px; background-color:rgb(243, 243, 243);" class="text-center">Jenis Kontrak</th>
                                    <th style="min-width: 170px; background-color:rgb(243, 243, 243);" class="text-center">Tanggal Mulai</th>
                                    <th style="min-width: 170px; background-color:rgb(243, 243, 243);" class="text-center">Tanggal Selesai</th>
                                    <th style="min-width: 400px; background-color:rgb(243, 243, 243);" class="text-center">Keterangan</th>
                                    <th style="min-width: 230px; background-color:rgb(243, 243, 243);" class="text-center">File</th>
                                    <th class="text-center" style="position: sticky; right: 0; background-color: rgb(215, 215, 215); z-index: 2;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($kontraks) <= 0): ?>
                                    <tr>
                                        <td colspan="10" class="text-center">Tidak Ada Data</td>
                                    </tr>
                                <?php else: ?>
                                    <?php $__currentLoopData = $kontraks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $kontrak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center" style="position: sticky; left: 0; background-color: rgb(235, 235, 235); z-index: 1;"><?php echo e(($kontraks->currentpage() - 1) * $kontraks->perpage() + $key + 1); ?>.</td>
                                            <td style="position: sticky; left: 40px; background-color: rgb(235, 235, 235); z-index: 1;"><?php echo e($kontrak->user->name ?? '-'); ?></td>
                                            <td class="text-center">
                                                <?php if($kontrak->tanggal): ?>
                                                    <?php
                                                        Carbon\Carbon::setLocale('id');
                                                        $tanggal = Carbon\Carbon::createFromFormat('Y-m-d', $kontrak->tanggal);
                                                        $new_tanggal = $tanggal->translatedFormat('d F Y');
                                                    ?>
                                                    <?php echo e($new_tanggal); ?>

                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($kontrak->jenis_kontrak ?? '-'); ?></td>
                                            <td class="text-center">
                                                <?php if($kontrak->tanggal_mulai): ?>
                                                    <?php
                                                        Carbon\Carbon::setLocale('id');
                                                        $tanggal_mulai = Carbon\Carbon::createFromFormat('Y-m-d', $kontrak->tanggal_mulai);
                                                        $new_tanggal_mulai = $tanggal_mulai->translatedFormat('d F Y');
                                                    ?>
                                                    <?php echo e($new_tanggal_mulai); ?>

                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <?php if($kontrak->tanggal_selesai): ?>
                                                    <?php
                                                        Carbon\Carbon::setLocale('id');
                                                        $tanggal_selesai = Carbon\Carbon::createFromFormat('Y-m-d', $kontrak->tanggal_selesai);
                                                        $new_tanggal_selesai = $tanggal_selesai->translatedFormat('d F Y');
                                                    ?>
                                                    <?php echo e($new_tanggal_selesai); ?>

                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo $kontrak->keterangan ? nl2br(e($kontrak->keterangan)) : '-'; ?></td>
                                            <td>
                                                <?php if($kontrak->kontrak_file_path): ?>
                                                    <a href="<?php echo e(url('/storage/'.$kontrak->kontrak_file_path)); ?>" style="font-size: 10px"><i class="fa fa-download"></i> <?php echo e($kontrak->kontrak_file_name); ?></a>
                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td style="position: sticky; right: 0; background-color: rgb(235, 235, 235); z-index: 1;">
                                                <ul class="action">
                                                    <li class="edit">
                                                        <a href="<?php echo e(url('/kontrak/edit/'.$kontrak->id)); ?>"><i class="fa fa-solid fa-edit"></i></a>
                                                    </li>
                                                    <li class="delete">
                                                        <form action="<?php echo e(url('/kontrak/delete/'.$kontrak->id)); ?>" method="post" class="d-inline">
                                                            <?php echo method_field('delete'); ?>
                                                            <?php echo csrf_field(); ?>
                                                            <button class="border-0" style="background-color: transparent;" onClick="return confirm('Are You Sure')"><i class="fa fa-solid fa-trash"></i></button>
                                                        </form>
                                                    </li>
                                                </ul>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-end mt-4">
                        <?php echo e($kontraks->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>

    <?php $__env->startPush('script'); ?>
        <script>
            $(document).ready(function() {
                $('#mulai').change(function(){
                    var mulai = $(this).val();
                $('#akhir').val(mulai);
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/andry/Herd/absensi-laravel/resources/views/kontrak/index.blade.php ENDPATH**/ ?>